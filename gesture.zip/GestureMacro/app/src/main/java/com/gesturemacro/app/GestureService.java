package com.gesturemacro.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The heart of the app. It lives as an Android Accessibility Service, which is the only
 * official way on Android for an app to draw above other apps without extra permissions
 * and to perform taps / swipes in other apps (the same idea as iPhone's AssistiveTouch).
 */
public class GestureService extends AccessibilityService {
    public static volatile GestureService instance;

    private static final int MAX_STROKES = 10; // Android limit per dispatched gesture

    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private SharedPreferences.OnSharedPreferenceChangeListener prefListener;

    // floating button
    private AtButtonView button;
    private WindowManager.LayoutParams btnLp;
    private int btnSize;
    private float downRawX, downRawY;
    private int startX, startY;
    private boolean dragging, longFired;
    private long lastTapTime;
    private Runnable pendingSingle;

    // overlays
    private FrameLayout menuRoot;
    private PickerView picker;

    // red trigger + live assist (see the "live assist" section below)
    private RedTriggerView trigger;
    private WindowManager.LayoutParams trigLp;
    private boolean trigAttached;
    private boolean trigGate = true;   // false only while an assisted touch is running
    private int trigSize;
    private TriggerPlacerView placer;
    private TouchIndicatorView circles;
    private boolean circlesFading;
    private LiveSession session;
    private GestureDescription.StrokeDescription relayStroke;
    private final Map<String, Integer> counts = new HashMap<>();

    private static class MenuItem {
        final String label;
        final int icon;
        final Runnable action;

        MenuItem(String label, int icon, Runnable action) {
            this.label = label;
            this.icon = icon;
            this.action = action;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = Store.prefs(this);
        prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences p, String key) {
                if (key != null && key.startsWith("diag_")) return; // counters change often; nothing to refresh
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshButton();
                        refreshTrigger();
                    }
                });
            }
        };
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
        refreshButton();
        refreshTrigger();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        instance = null;
        closeMenu();
        closePicker();
        endPlacement();
        removeTrigger();
        removeCircles();
        removeButton();
        if (prefs != null && prefListener != null) {
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        h.post(new Runnable() {
            @Override
            public void run() {
                closeMenu();
                closePicker();
                endPlacement();
                placeButton();
                onRotation();
            }
        });
    }

    // ------------------------------------------------------------------ helpers

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private DisplayMetrics realMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    private WindowManager.LayoutParams overlayParams(int w, int hh, int flags) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return p;
    }

    private static final int FULL_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void feedback() {
        if (button == null) return;
        if (Store.b(this, "vibration", true)) {
            button.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        }
        if (Store.b(this, "sound_on_click", false)) {
            button.playSoundEffect(SoundEffectConstants.CLICK);
        }
    }

    // ------------------------------------------------------------------ floating button

    private float idleAlpha() {
        return Store.i(this, "idle_opacity", 37) / 100f;
    }

    private final Runnable idleFade = new Runnable() {
        @Override
        public void run() {
            if (button != null) button.animate().alpha(idleAlpha()).setDuration(250).start();
        }
    };

    private void refreshButton() {
        if (wm == null) return;
        if (!Store.b(this, "at_enabled", true)) {
            closeMenu();
            removeButton();
            return;
        }
        if (button == null) {
            addButton();
        } else {
            h.removeCallbacks(idleFade);
            h.postDelayed(idleFade, 600);
        }
    }

    private void addButton() {
        btnSize = dp(54);
        button = new AtButtonView(this);
        btnLp = overlayParams(btnSize, btnSize, FULL_FLAGS);
        placeButtonFromPrefs();
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                return handleButtonTouch(e);
            }
        });
        try {
            wm.addView(button, btnLp);
        } catch (Exception ex) {
            button = null;
            return;
        }
        button.setAlpha(1f);
        h.postDelayed(idleFade, 2500);
    }

    private void removeButton() {
        h.removeCallbacks(idleFade);
        if (button != null) {
            try {
                wm.removeView(button);
            } catch (Exception ignored) {
            }
            button = null;
        }
    }

    private void placeButtonFromPrefs() {
        DisplayMetrics dm = realMetrics();
        float fx = Store.f(this, "btn_fx", 1f);
        float fy = Store.f(this, "btn_fy", 0.45f);
        int margin = dp(4);
        btnLp.x = margin + Math.round(fx * Math.max(0, dm.widthPixels - btnSize - 2 * margin));
        btnLp.y = Math.round(fy * Math.max(0, dm.heightPixels - btnSize));
    }

    private void placeButton() {
        if (button == null) return;
        placeButtonFromPrefs();
        try {
            wm.updateViewLayout(button, btnLp);
        } catch (Exception ignored) {
        }
    }

    private boolean handleButtonTouch(MotionEvent e) {
        final int slop = dp(8);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = e.getRawX();
                downRawY = e.getRawY();
                startX = btnLp.x;
                startY = btnLp.y;
                dragging = false;
                longFired = false;
                h.removeCallbacks(idleFade);
                button.animate().cancel();
                button.setAlpha(1f);
                h.postDelayed(longPressRun, 550);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getRawX() - downRawX;
                float dy = e.getRawY() - downRawY;
                if (!dragging && Math.hypot(dx, dy) > slop) {
                    dragging = true;
                    h.removeCallbacks(longPressRun);
                }
                if (dragging) {
                    DisplayMetrics dm = realMetrics();
                    btnLp.x = Math.max(0, Math.min(dm.widthPixels - btnSize, Math.round(startX + dx)));
                    btnLp.y = Math.max(0, Math.min(dm.heightPixels - btnSize, Math.round(startY + dy)));
                    try {
                        wm.updateViewLayout(button, btnLp);
                    } catch (Exception ignored) {
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                h.removeCallbacks(longPressRun);
                if (dragging) {
                    snapToEdge();
                } else if (!longFired) {
                    onButtonTap();
                }
                h.postDelayed(idleFade, 3000);
                return true;
            case MotionEvent.ACTION_CANCEL:
                h.removeCallbacks(longPressRun);
                h.postDelayed(idleFade, 3000);
                return true;
            default:
                return true;
        }
    }

    private final Runnable longPressRun = new Runnable() {
        @Override
        public void run() {
            longFired = true;
            feedback();
            runAction(Store.s(GestureService.this, "long_press", "none"));
        }
    };

    private void snapToEdge() {
        DisplayMetrics dm = realMetrics();
        int margin = dp(4);
        boolean left = btnLp.x + btnSize / 2 < dm.widthPixels / 2;
        btnLp.x = left ? margin : dm.widthPixels - btnSize - margin;
        try {
            wm.updateViewLayout(button, btnLp);
        } catch (Exception ignored) {
        }
        float freeW = Math.max(1, dm.widthPixels - btnSize - 2 * margin);
        float freeH = Math.max(1, dm.heightPixels - btnSize);
        Store.setF(this, "btn_fx", Math.max(0f, Math.min(1f, (btnLp.x - margin) / freeW)));
        Store.setF(this, "btn_fy", Math.max(0f, Math.min(1f, btnLp.y / freeH)));
    }

    private void onButtonTap() {
        feedback();
        long now = SystemClock.uptimeMillis();
        if (pendingSingle != null && now - lastTapTime < 320) {
            h.removeCallbacks(pendingSingle);
            pendingSingle = null;
            runAction(Store.s(this, "double_tap", "menu"));
            return;
        }
        lastTapTime = now;
        final String single = Store.s(this, "single_tap", "none");
        if ("none".equals(Store.s(this, "double_tap", "menu"))) {
            runAction(single);
            return;
        }
        pendingSingle = new Runnable() {
            @Override
            public void run() {
                pendingSingle = null;
                runAction(single);
            }
        };
        h.postDelayed(pendingSingle, 300);
    }

    // ------------------------------------------------------------------ actions

    private void runAction(String a) {
        if (a == null || a.equals("none")) return;
        if (a.equals("menu")) {
            if (menuRoot != null) closeMenu(); else openMenu();
            return;
        }
        if (a.startsWith("macro:")) {
            // A saved gesture is never played by an action. Choosing it only selects it as the
            // gesture that live assist follows while YOU drag on the red trigger.
            Macro m = Store.findMacro(this, a.substring(6));
            if (m != null) selectAssist(m);
            return;
        }
        closeMenu();
        switch (a) {
            case "home": performGlobalAction(GLOBAL_ACTION_HOME); break;
            case "back": performGlobalAction(GLOBAL_ACTION_BACK); break;
            case "recents": performGlobalAction(GLOBAL_ACTION_RECENTS); break;
            case "notifications": performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); break;
            case "quick_settings": performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); break;
            case "power": performGlobalAction(GLOBAL_ACTION_POWER_DIALOG); break;
            case "lock":
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
                else toast("Lock Screen needs Android 9 or newer");
                break;
            case "screenshot":
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
                else toast("Screenshot needs Android 9 or newer");
                break;
            case "vol_up": volume(AudioManager.ADJUST_RAISE); break;
            case "vol_down": volume(AudioManager.ADJUST_LOWER); break;
            case "mute": volume(AudioManager.ADJUST_TOGGLE_MUTE); break;
            default: break;
        }
    }

    private void volume(int dir) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am != null) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
    }

    // ------------------------------------------------------------------ menu

    private void openMenu() {
        closeMenu();
        menuRoot = new FrameLayout(this);
        menuRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeMenu();
            }
        });
        try {
            wm.addView(menuRoot, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, FULL_FLAGS));
        } catch (Exception ex) {
            menuRoot = null;
            return;
        }
        showMenuPage("top");
    }

    private void closeMenu() {
        if (menuRoot != null) {
            try {
                wm.removeView(menuRoot);
            } catch (Exception ignored) {
            }
            menuRoot = null;
        }
    }

    private MenuItem item(String label, int icon, Runnable r) {
        return new MenuItem(label, icon, r);
    }

    private Runnable page(final String name) {
        return new Runnable() {
            @Override
            public void run() {
                showMenuPage(name);
            }
        };
    }

    private Runnable action(final String id) {
        return new Runnable() {
            @Override
            public void run() {
                runAction(id);
            }
        };
    }

    private Runnable picker(final String mode) {
        return new Runnable() {
            @Override
            public void run() {
                startPicker(mode);
            }
        };
    }

    private List<MenuItem> itemsFor(String pageName) {
        List<MenuItem> l = new ArrayList<>();
        if (pageName.equals("top")) {
            for (String k : Store.menuItems(this)) {
                switch (k) {
                    case "custom": l.add(item("Custom", IconView.STAR, page("custom"))); break;
                    case "notifications": l.add(item("Notification Center", IconView.BELL, action("notifications"))); break;
                    case "device": l.add(item("Device", IconView.DEVICE, page("device"))); break;
                    case "gestures": l.add(item("Gestures", IconView.GESTURES, page("gestures"))); break;
                    case "home": l.add(item("Home", IconView.HOME, action("home"))); break;
                    case "control": l.add(item("Control Center", IconView.TOGGLES, action("quick_settings"))); break;
                    default: break;
                }
            }
        } else if (pageName.equals("custom")) {
            l.add(item("Pinch and Rotate", IconView.PINCH, picker(PickerView.PINCH)));
            l.add(item("Long Press", IconView.LONGPRESS, picker(PickerView.LONGPRESS)));
            l.add(item("Double Tap", IconView.DOUBLETAP, picker(PickerView.DOUBLETAP)));
            l.add(item("Hold and Drag", IconView.HOLDDRAG, picker(PickerView.HOLDDRAG)));
            for (final Macro m : Store.loadMacros(this)) {
                l.add(item(m.name, IconView.STAR, new Runnable() {
                    @Override
                    public void run() {
                        selectAssist(m);
                    }
                }));
            }
            Runnable openApp = new Runnable() {
                @Override
                public void run() {
                    closeMenu();
                    Intent i = new Intent(GestureService.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                }
            };
            // The centre cell of a sub page is the Back arrow, so one page holds 8 icons.
            // Empty slots show the dashed "+" (it opens the app so you can record a new gesture).
            if (l.size() < 8) {
                while (l.size() < 8) l.add(item("", IconView.PLUS, openApp));
            } else {
                l.add(item("", IconView.PLUS, openApp));
            }
        } else if (pageName.equals("device")) {
            l.add(item("Lock Screen", IconView.LOCK, action("lock")));
            l.add(item("Screenshot", IconView.SCREENSHOT, action("screenshot")));
            l.add(item("Recent Apps", IconView.RECENTS, action("recents")));
            l.add(item("Volume Up", IconView.VOLUP, action("vol_up")));
            l.add(item("Volume Down", IconView.VOLDOWN, action("vol_down")));
            l.add(item("Mute", IconView.MUTE, action("mute")));
            l.add(item("Power Menu", IconView.POWER, action("power")));
        } else if (pageName.equals("gestures")) {
            l.add(item("Swipe Up", IconView.UP, swipe(0)));
            l.add(item("Swipe Down", IconView.DOWN, swipe(1)));
            l.add(item("Swipe Left", IconView.LEFT, swipe(2)));
            l.add(item("Swipe Right", IconView.RIGHT, swipe(3)));
            l.add(item("Zoom In", IconView.ZOOMIN, zoom(true)));
            l.add(item("Zoom Out", IconView.ZOOMOUT, zoom(false)));
            l.add(item("Back", IconView.BACK, action("back")));
        }
        return l;
    }

    private void showMenuPage(String pageName) {
        if (menuRoot == null) return;
        menuRoot.removeAllViews();
        List<MenuItem> items = itemsFor(pageName);
        List<MenuItem> cells = new ArrayList<>();
        if (pageName.equals("top")) {
            cells.addAll(items);
        } else {
            MenuItem back = item("", IconView.BACK, page("top"));
            for (MenuItem it : items) {
                if (cells.size() == 4) cells.add(back);
                cells.add(it);
            }
            while (cells.size() < 4) cells.add(null);
            if (cells.size() == 4) cells.add(back);
        }
        while (cells.size() % 3 != 0) cells.add(null);

        final int cellW = dp(96);
        final int cellH = dp(88);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < cells.size() / 3; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 3; c++) {
                row.addView(cellView(cells.get(r * 3 + c)), new LinearLayout.LayoutParams(cellW, cellH));
            }
            grid.addView(row);
        }

        DisplayMetrics dm = realMetrics();
        int padding = dp(10);
        int gridH = (cells.size() / 3) * cellH;
        int maxH = Math.round(dm.heightPixels * 0.80f) - 2 * padding;

        FrameLayout panel = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF01F1D1B);
        bg.setCornerRadius(dp(26));
        panel.setBackground(bg);
        panel.setPadding(padding, padding, padding, padding);
        panel.setClickable(true); // taps on the panel itself must not close the menu
        if (gridH > maxH) {
            ScrollView sv = new ScrollView(this);
            sv.addView(grid);
            panel.addView(sv, new FrameLayout.LayoutParams(cellW * 3, maxH));
        } else {
            panel.addView(grid, new FrameLayout.LayoutParams(cellW * 3, gridH));
        }
        menuRoot.addView(panel, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        panel.setAlpha(0f);
        panel.setScaleX(0.8f);
        panel.setScaleY(0.8f);
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).start();
    }

    private View cellView(final MenuItem it) {
        if (it == null) return new View(this);
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(0, dp(8), 0, 0);
        cell.addView(new IconView(this, it.icon), new LinearLayout.LayoutParams(dp(46), dp(46)));
        TextView label = new TextView(this);
        label.setText(it.label);
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setPadding(dp(2), dp(4), dp(2), 0);
        cell.addView(label, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                feedback();
                it.action.run();
            }
        });
        return cell;
    }

    // ------------------------------------------------------------------ live assist (red trigger + red touch circles)
    //
    // What this does, and what it does not:
    //  * The red trigger is a small window that stays where you put it. Its x/y are written in ONE place only
    //    (applyTriggerPosition) and that place only reads the saved setting, never a finger position.
    //  * When your finger goes down ON the trigger, the app reads it live (direction, distance, speed, time),
    //    optionally corrects it (LiveAssist) and re-sends that single finger to the game as a continued stroke.
    //  * Nothing is ever played by itself: with no finger on the trigger, nothing is dispatched. There are no
    //    saved paths being replayed, no timers that tap or drag.
    //  * Android does not let one app edit another app's real touches, so this is a relay, not an interception.
    //    It is experimental; the diagnostics page shows whether it works on your phone.

    private static final long GATE_WATCH_MS = 500;
    private int gateStuckTicks;

    private boolean assistOn() {
        return Store.b(this, "live_assist", true)
                && Build.VERSION.SDK_INT >= 26
                && !Store.b(this, "assist_paused", false);
    }

    private int trigSizePx() {
        return dp(72);
    }

    private boolean isLandscape() {
        DisplayMetrics dm = realMetrics();
        return dm.widthPixels > dm.heightPixels;
    }

    private void ensureSession() {
        if (session != null) return;
        session = new LiveSession(liveHost, relaySink, new StrokeRelay.Clock() {
            @Override
            public long now() {
                return SystemClock.uptimeMillis();
            }
        }, dp(10));
        refreshAssistConfig();
    }

    private int triggerFlags() {
        boolean touchable = assistOn() && trigGate;
        return FULL_FLAGS | (touchable ? 0 : WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    private void refreshTrigger() {
        if (wm == null) return;
        if (!Store.b(this, "show_touches", true)) removeCircles();
        if (!Store.b(this, "trig_enabled", true)) {
            endPlacement();
            removeTrigger();
            removeCircles();
            return;
        }
        ensureSession();
        if (!trigAttached) addTrigger();
        else applyTriggerFlags(); // flags only: the position is never touched here
        refreshAssistConfig();
    }

    private void addTrigger() {
        trigSize = trigSizePx();
        trigger = new RedTriggerView(this);
        trigLp = overlayParams(trigSize, trigSize, triggerFlags());
        applyTriggerPosition(false);
        trigger.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                return handleTriggerTouch(e);
            }
        });
        try {
            wm.addView(trigger, trigLp);
            trigAttached = true;
        } catch (Exception ex) {
            trigger = null;
            trigAttached = false;
            return;
        }
        trigger.setAlpha(assistOn() ? 1f : 0.55f);
        // keep the white AT button above the trigger so it can always be grabbed
        if (button != null) {
            removeButton();
            refreshButton();
        }
    }

    private void removeTrigger() {
        h.removeCallbacks(gateWatch);
        if (session != null) session.reset();
        if (trigger != null) {
            try {
                wm.removeView(trigger);
            } catch (Exception ignored) {
            }
        }
        trigger = null;
        trigAttached = false;
        trigGate = true;
        flushCounts();
    }

    private void applyTriggerFlags() {
        if (!trigAttached || trigger == null) return;
        int f = triggerFlags();
        trigger.setAlpha(assistOn() ? 1f : 0.55f);
        if (trigLp.flags != f) {
            trigLp.flags = f;
            try {
                wm.updateViewLayout(trigger, trigLp);
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * The ONLY place that writes the trigger's x/y. It reads the saved setting for the current
     * orientation. It runs when the trigger is created, when the screen rotates and when you save a
     * new place in "Position Red Trigger". Finger movement can never reach it.
     */
    private void applyTriggerPosition(boolean update) {
        DisplayMetrics dm = realMetrics();
        boolean land = dm.widthPixels > dm.heightPixels;
        float fx = Store.f(this, TriggerPlacement.keyFx(land), TriggerPlacement.defaultFx(land));
        float fy = Store.f(this, TriggerPlacement.keyFy(land), TriggerPlacement.defaultFy(land));
        int[] xy = TriggerPlacement.toPx(fx, fy, dm.widthPixels, dm.heightPixels, trigSizePx());
        trigLp.x = xy[0];
        trigLp.y = xy[1];
        if (update && trigAttached && trigger != null) {
            try {
                wm.updateViewLayout(trigger, trigLp);
            } catch (Exception ignored) {
            }
        }
    }

    private void onRotation() {
        trigGate = true;
        if (session != null) session.reset();
        if (trigAttached) {
            applyTriggerPosition(true);
            applyTriggerFlags();
        }
        refreshAssistConfig();
        String id = Store.s(this, "assist_gesture", "");
        if (id.length() > 0 && Store.b(this, "live_assist", true)) {
            Macro m = Store.findMacro(this, id);
            if (m != null && (m.screenW > m.screenH) != isLandscape()) {
                toast("Assist gesture \"" + m.name + "\" was recorded in "
                        + (m.screenW > m.screenH ? "landscape" : "portrait") + ", so it is off in this orientation");
            }
        }
    }

    private boolean handleTriggerTouch(MotionEvent e) {
        if (session == null) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                trigger.setPressedLook(true);
                ensureCircles();
                session.onDown(e.getRawX(), e.getRawY(), e.getEventTime());
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (!session.isDown()) return true;
                float ox = e.getRawX() - e.getX();
                float oy = e.getRawY() - e.getY();
                int n = e.getHistorySize();
                for (int i = 0; i < n; i++) {
                    session.onMove(e.getHistoricalX(i) + ox, e.getHistoricalY(i) + oy, e.getHistoricalEventTime(i));
                }
                session.onMove(e.getRawX(), e.getRawY(), e.getEventTime());
                return true;
            }
            case MotionEvent.ACTION_UP:
                trigger.setPressedLook(false);
                session.onUp(e.getRawX(), e.getRawY(), e.getEventTime());
                return true;
            case MotionEvent.ACTION_CANCEL:
                trigger.setPressedLook(false);
                session.onCancel(e.getEventTime());
                return true;
            default:
                return true; // extra fingers are ignored
        }
    }

    // ---- the saved gesture that live assist follows

    private void selectAssist(Macro m) {
        Store.setS(this, "assist_gesture", m.id);
        refreshAssistConfig();
        closeMenu();
        String extra = assistOn() ? "" : " (Live Assist is off or paused in the app)";
        toast("Assist gesture: " + m.name + extra);
    }

    private void refreshAssistConfig() {
        if (session == null) return;
        session.assist.setStrength(Store.i(this, "assist_strength", 60) / 100f);
        String id = Store.s(this, "assist_gesture", "");
        Macro m = id.length() == 0 ? null : Store.findMacro(this, id);
        if (m == null || m.strokes.isEmpty() || m.screenW <= 0 || m.screenH <= 0) {
            session.assist.clearReference();
            return;
        }
        DisplayMetrics dm = realMetrics();
        if ((m.screenW > m.screenH) != (dm.widthPixels > dm.heightPixels)) {
            session.assist.clearReference();
            return;
        }
        Macro.Stroke best = null;
        double bestLen = -1;
        for (Macro.Stroke s : m.strokes) {
            double len = 0;
            for (int i = 1; i < s.pts.size(); i++) {
                len += Math.hypot(s.pts.get(i)[0] - s.pts.get(i - 1)[0], s.pts.get(i)[1] - s.pts.get(i - 1)[1]);
            }
            if (len > bestLen) {
                bestLen = len;
                best = s;
            }
        }
        if (best == null) {
            session.assist.clearReference();
            return;
        }
        float kx = dm.widthPixels / (float) m.screenW;
        float ky = dm.heightPixels / (float) m.screenH;
        List<float[]> scaled = new ArrayList<>();
        for (float[] p : best.pts) scaled.add(new float[]{p[0] * kx, p[1] * ky});
        session.assist.setReferenceFromPoints(scaled);
    }

    // ---- bridge between the relay and Android's gesture dispatch

    private float clampTo(float v, int max) {
        return Math.max(0f, Math.min(v, Math.max(0, max - 1)));
    }

    private final StrokeRelay.Sink relaySink = new StrokeRelay.Sink() {
        @Override
        public boolean send(final float x0, final float y0, final float x1, final float y1, final long durMs,
                            final boolean first, final boolean willContinue, final StrokeRelay.Done done) {
            if (Build.VERSION.SDK_INT < 26 || wm == null) return false;
            if (first) {
                // a short pause so the trigger window has already turned pass-through
                // when the injected finger lands (otherwise it would land on the trigger itself)
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!dispatchPiece(x0, y0, x1, y1, durMs, true, willContinue, done)) done.cancelled();
                    }
                }, 35);
                return true;
            }
            return dispatchPiece(x0, y0, x1, y1, durMs, false, willContinue, done);
        }
    };

    private float relayEndX, relayEndY;

    private boolean dispatchPiece(float x0, float y0, float x1, float y1, long durMs,
                                  boolean first, boolean willContinue, final StrokeRelay.Done done) {
        if (Build.VERSION.SDK_INT < 26 || wm == null) return false;
        if (!first && relayStroke == null) return false; // never start a new touch in the middle of a drag
        try {
            DisplayMetrics dm = realMetrics();
            // A continued stroke has to start exactly where the previous piece ended, so the start is
            // taken from there and only the new end point is clamped to the screen.
            float fx = first ? clampTo(x0, dm.widthPixels) : relayEndX;
            float fy = first ? clampTo(y0, dm.heightPixels) : relayEndY;
            float tx = clampTo(x1, dm.widthPixels);
            float ty = clampTo(y1, dm.heightPixels);
            Path p = line(fx, fy, tx, ty);
            long dur = Math.max(1, durMs);
            final GestureDescription.StrokeDescription sd = first
                    ? new GestureDescription.StrokeDescription(p, 0, dur, willContinue)
                    : relayStroke.continueStroke(p, 0, dur, willContinue);
            GestureDescription g = new GestureDescription.Builder().addStroke(sd).build();
            boolean ok = dispatchGesture(g, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gd) {
                    done.completed();
                }

                @Override
                public void onCancelled(GestureDescription gd) {
                    if (relayStroke == sd) relayStroke = null;
                    done.cancelled();
                }
            }, h);
            if (ok) {
                relayStroke = willContinue ? sd : null;
                relayEndX = tx;
                relayEndY = ty;
            } else {
                endDangling();
            }
            return ok;
        } catch (Exception ex) {
            endDangling();
            return false;
        }
    }

    /**
     * A piece could not be sent while the previous one is still held down by Android. Lift that
     * finger at its last position with a minimal piece, so no touch is ever left stuck on the game.
     */
    private void endDangling() {
        GestureDescription.StrokeDescription open = relayStroke;
        relayStroke = null;
        if (open == null || Build.VERSION.SDK_INT < 26) return;
        try {
            GestureDescription.StrokeDescription end = open.continueStroke(
                    line(relayEndX, relayEndY, relayEndX, relayEndY), 0, 1, false);
            dispatchGesture(new GestureDescription.Builder().addStroke(end).build(), null, null);
        } catch (Exception ignored) {
        }
    }

    // ---- what the LiveSession asks the screen to do

    private final LiveSession.Host liveHost = new LiveSession.Host() {
        @Override
        public void showCircles(float[] xy) {
            if (circles != null) {
                circlesFading = false;
                circles.update(xy, SystemClock.uptimeMillis());
            }
        }

        @Override
        public void endCircles() {
            fadeCircles();
        }

        @Override
        public void setTriggerTouchable(boolean touchable) {
            trigGate = touchable;
            applyTriggerFlags();
            h.removeCallbacks(gateWatch);
            if (!touchable) {
                gateStuckTicks = 0;
                h.postDelayed(gateWatch, GATE_WATCH_MS);
            }
        }

        @Override
        public void pauseAssist(String reason) {
            Store.setB(GestureService.this, "assist_paused", true);
            trigGate = true;
            applyTriggerFlags();
            flushCounts();
            toast("Live Assist paused: " + reason + ". The red trigger now lets touches through. "
                    + "Turn Live Assist off and on in the app to try again.");
        }

        @Override
        public void count(String key) {
            Integer v = counts.get(key);
            counts.put(key, v == null ? 1 : v + 1);
        }

        @Override
        public void flushCounts() {
            GestureService.this.flushCounts();
        }
    };

    private void flushCounts() {
        if (counts.isEmpty()) return;
        SharedPreferences.Editor ed = Store.prefs(this).edit();
        for (Map.Entry<String, Integer> en : counts.entrySet()) {
            String k = "diag_" + en.getKey();
            ed.putInt(k, Store.i(this, k, 0) + en.getValue());
        }
        ed.apply();
        counts.clear();
    }

    /** Safety net: if the injected finger never reports back, give the touch back to the trigger/game. */
    private final Runnable gateWatch = new Runnable() {
        @Override
        public void run() {
            if (trigGate || session == null) return;
            if (!session.isDown() && session.isRelaying()) {
                gateStuckTicks++;
                if (gateStuckTicks >= 6) {
                    session.reset();
                    return;
                }
            } else if (!session.isDown()) {
                trigGate = true;
                applyTriggerFlags();
                return;
            } else {
                gateStuckTicks = 0;
            }
            h.postDelayed(this, GATE_WATCH_MS);
        }
    };

    // ---- red touch circles (full-screen, not touchable, only while a drag on the trigger is happening)

    private void ensureCircles() {
        if (circles != null || wm == null) return;
        if (!Store.b(this, "show_touches", true)) return;
        circles = new TouchIndicatorView(this);
        try {
            wm.addView(circles, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                    FULL_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE));
        } catch (Exception ex) {
            circles = null;
        }
    }

    private final Runnable fadeRun = new Runnable() {
        @Override
        public void run() {
            if (circles == null || !circlesFading) return;
            long now = SystemClock.uptimeMillis();
            circles.update(new float[0], now);
            if (now - fadeStart > 520) {
                removeCircles();
            } else {
                h.postDelayed(this, 40);
            }
        }
    };
    private long fadeStart;

    private void fadeCircles() {
        if (circles == null) return;
        circlesFading = true;
        fadeStart = SystemClock.uptimeMillis();
        h.removeCallbacks(fadeRun);
        h.postDelayed(fadeRun, 40);
    }

    private void removeCircles() {
        h.removeCallbacks(fadeRun);
        circlesFading = false;
        if (circles != null) {
            try {
                wm.removeView(circles);
            } catch (Exception ignored) {
            }
            circles = null;
        }
    }

    // ---- "Position Red Trigger": the only way to move the trigger

    /** Called from the app's settings. Shows a full-screen layer over whatever is on screen; drag the ring, tap Save. */
    public void beginTriggerPlacement() {
        h.post(new Runnable() {
            @Override
            public void run() {
                if (wm == null) return;
                closeMenu();
                closePicker();
                endPlacement();
                DisplayMetrics dm = realMetrics();
                boolean land = dm.widthPixels > dm.heightPixels;
                float fx = Store.f(GestureService.this, TriggerPlacement.keyFx(land), TriggerPlacement.defaultFx(land));
                float fy = Store.f(GestureService.this, TriggerPlacement.keyFy(land), TriggerPlacement.defaultFy(land));
                int size = trigSizePx();
                int[] xy = TriggerPlacement.toPx(fx, fy, dm.widthPixels, dm.heightPixels, size);
                placer = new TriggerPlacerView(GestureService.this, xy[0] + size / 2f, xy[1] + size / 2f,
                        new TriggerPlacerView.Callback() {
                            @Override
                            public void onSave(float cx, float cy) {
                                saveTriggerCentre(cx, cy);
                                endPlacement();
                                toast("Red trigger saved");
                            }

                            @Override
                            public void onCancel() {
                                endPlacement();
                            }
                        });
                try {
                    wm.addView(placer, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT, FULL_FLAGS));
                    if (trigger != null) trigger.setVisibility(View.INVISIBLE);
                } catch (Exception ex) {
                    placer = null;
                    toast("Couldn't open the placement screen");
                }
            }
        });
    }

    private void saveTriggerCentre(float cx, float cy) {
        DisplayMetrics dm = realMetrics();
        boolean land = dm.widthPixels > dm.heightPixels;
        int size = trigSizePx();
        int x = Math.round(cx - size / 2f);
        int y = Math.round(cy - size / 2f);
        float[] f = TriggerPlacement.toFrac(x, y, dm.widthPixels, dm.heightPixels, size);
        Store.setF(this, TriggerPlacement.keyFx(land), f[0]);
        Store.setF(this, TriggerPlacement.keyFy(land), f[1]);
        if (trigAttached) applyTriggerPosition(true);
    }

    private void endPlacement() {
        if (placer != null) {
            try {
                wm.removeView(placer);
            } catch (Exception ignored) {
            }
            placer = null;
        }
        if (trigger != null) trigger.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ built-in gestures (Custom / Gestures pages)

    private void send(GestureDescription.StrokeDescription... strokes) {
        try {
            GestureDescription.Builder b = new GestureDescription.Builder();
            for (GestureDescription.StrokeDescription s : strokes) b.addStroke(s);
            dispatchGesture(b.build(), null, null);
        } catch (Exception ex) {
            toast("Couldn't perform that gesture");
        }
    }

    private Path line(float x1, float y1, float x2, float y2) {
        Path p = new Path();
        p.moveTo(x1, y1);
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2);
        return p;
    }

    private Runnable swipe(final int dir) {
        return new Runnable() {
            @Override
            public void run() {
                closeMenu();
                DisplayMetrics dm = realMetrics();
                final float w = dm.widthPixels;
                final float hgt = dm.heightPixels;
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        float cx = w / 2f, cy = hgt / 2f;
                        float dx = 0, dy = 0;
                        if (dir == 0) dy = -hgt * 0.30f;
                        if (dir == 1) dy = hgt * 0.30f;
                        if (dir == 2) dx = -w * 0.30f;
                        if (dir == 3) dx = w * 0.30f;
                        send(new GestureDescription.StrokeDescription(line(cx - dx / 2f, cy - dy / 2f, cx + dx / 2f, cy + dy / 2f), 0, 350));
                    }
                }, 250);
            }
        };
    }

    private Runnable zoom(final boolean in) {
        return new Runnable() {
            @Override
            public void run() {
                closeMenu();
                DisplayMetrics dm = realMetrics();
                final float cx = dm.widthPixels / 2f;
                final float cy = dm.heightPixels / 2f;
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        float near = dp(50);
                        float far = dp(150);
                        float from = in ? near : far;
                        float to = in ? far : near;
                        send(new GestureDescription.StrokeDescription(line(cx - from, cy, cx - to, cy), 0, 450),
                                new GestureDescription.StrokeDescription(line(cx + from, cy, cx + to, cy), 0, 450));
                    }
                }, 250);
            }
        };
    }

    private void startPicker(final String mode) {
        closeMenu();
        closePicker();
        picker = new PickerView(this, mode, new PickerView.Callback() {
            @Override
            public void onDone(final float[] data) {
                closePicker();
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        performPicked(mode, data);
                    }
                }, 200);
            }

            @Override
            public void onCancel() {
                closePicker();
            }
        });
        try {
            wm.addView(picker, overlayParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, FULL_FLAGS));
        } catch (Exception ex) {
            picker = null;
        }
    }

    private void closePicker() {
        if (picker != null) {
            try {
                wm.removeView(picker);
            } catch (Exception ignored) {
            }
            picker = null;
        }
    }

    private void performPicked(String mode, float[] d) {
        if (mode.equals(PickerView.LONGPRESS)) {
            Path p = new Path();
            p.moveTo(d[0], d[1]);
            send(new GestureDescription.StrokeDescription(p, 0, 900));
        } else if (mode.equals(PickerView.DOUBLETAP)) {
            Path p1 = new Path();
            p1.moveTo(d[0], d[1]);
            Path p2 = new Path();
            p2.moveTo(d[0], d[1]);
            send(new GestureDescription.StrokeDescription(p1, 0, 40),
                    new GestureDescription.StrokeDescription(p2, 140, 40));
        } else if (mode.equals(PickerView.PINCH)) {
            send(new GestureDescription.StrokeDescription(line(d[0], d[1], d[4], d[5]), 0, 500),
                    new GestureDescription.StrokeDescription(line(d[2], d[3], d[6], d[7]), 0, 500));
        } else if (mode.equals(PickerView.HOLDDRAG)) {
            holdAndDrag(d);
        }
    }

    /** Press and hold at the start point for half a second, then drag along the path you drew. */
    private void holdAndDrag(float[] d) {
        int n = d.length / 3;
        final float x0 = d[0];
        final float y0 = d[1];
        final Path drag = new Path();
        drag.moveTo(x0 + 0.5f, y0);
        for (int i = 1; i < n; i++) drag.lineTo(d[i * 3], d[i * 3 + 1]);
        final long dragMs = Math.max(200, (long) d[(n - 1) * 3 + 2]);
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Path hold = new Path();
                hold.moveTo(x0, y0);
                hold.lineTo(x0 + 0.5f, y0);
                final GestureDescription.StrokeDescription first =
                        new GestureDescription.StrokeDescription(hold, 0, 500, true);
                GestureDescription.Builder b = new GestureDescription.Builder();
                b.addStroke(first);
                dispatchGesture(b.build(), new GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        GestureDescription.StrokeDescription second = first.continueStroke(drag, 0, dragMs, false);
                        GestureDescription.Builder b2 = new GestureDescription.Builder();
                        b2.addStroke(second);
                        dispatchGesture(b2.build(), null, null);
                    }
                }, null);
            } catch (Exception ex) {
                toast("Couldn't perform that gesture");
            }
        } else {
            Path p = new Path();
            p.moveTo(x0, y0);
            for (int i = 1; i < n; i++) p.lineTo(d[i * 3], d[i * 3 + 1]);
            send(new GestureDescription.StrokeDescription(p, 0, dragMs + 500));
        }
    }
}
