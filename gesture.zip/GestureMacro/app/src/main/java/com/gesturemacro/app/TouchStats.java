package com.gesturemacro.app;

/**
 * Reads one live drag: where it started, where it is now, how far it went, how fast and for how long,
 * and in which direction. Plain Java (no Android classes) so it can be tested on any computer.
 */
public final class TouchStats {
    public boolean active;
    public float startX, startY, curX, curY;
    public long startMs, lastMs;
    /** Total length of the path the finger has travelled, in pixels. */
    public float pathLength;
    /** Smoothed speed in pixels per second. */
    public float speed;
    public int samples;

    public void begin(float x, float y, long t) {
        active = true;
        startX = curX = x;
        startY = curY = y;
        startMs = lastMs = t;
        pathLength = 0f;
        speed = 0f;
        samples = 1;
    }

    public void move(float x, float y, long t) {
        if (!active) return;
        float seg = (float) Math.hypot(x - curX, y - curY);
        long dt = t - lastMs;
        pathLength += seg;
        if (dt > 0) {
            float inst = seg * 1000f / dt;
            speed = samples <= 1 ? inst : speed + 0.3f * (inst - speed);
        }
        curX = x;
        curY = y;
        if (t > lastMs) lastMs = t;
        samples++;
    }

    public void end() {
        active = false;
    }

    /** Straight-line distance from where the finger went down. */
    public float distance() {
        return (float) Math.hypot(curX - startX, curY - startY);
    }

    /** Direction of the drag in degrees: 0 = right, 90 = up, 180 = left, 270 = down (screen y points down). */
    public float angleDeg() {
        double a = Math.toDegrees(Math.atan2(-(curY - startY), curX - startX));
        return (float) (a < 0 ? a + 360.0 : a);
    }

    public long durationMs() {
        return lastMs - startMs;
    }
}
