package com.gesturemacro.app;

/**
 * Where the red trigger sits. The position is stored as fractions of the free screen area, separately for
 * portrait and landscape. It only changes when you save a new place in settings. Plain Java.
 */
public final class TriggerPlacement {
    private TriggerPlacement() {}

    public static String keyFx(boolean landscape) {
        return landscape ? "trig_l_fx" : "trig_p_fx";
    }

    public static String keyFy(boolean landscape) {
        return landscape ? "trig_l_fy" : "trig_p_fy";
    }

    public static float defaultFx(boolean landscape) {
        return landscape ? 0.86f : 0.80f;
    }

    public static float defaultFy(boolean landscape) {
        return landscape ? 0.62f : 0.70f;
    }

    /** Top-left corner in pixels for a trigger of the given size. */
    public static int[] toPx(float fx, float fy, int screenW, int screenH, int size) {
        int x = Math.round(Math.max(0f, Math.min(1f, fx)) * Math.max(0, screenW - size));
        int y = Math.round(Math.max(0f, Math.min(1f, fy)) * Math.max(0, screenH - size));
        return new int[]{x, y};
    }

    public static float[] toFrac(int x, int y, int screenW, int screenH, int size) {
        float fw = Math.max(1, screenW - size);
        float fh = Math.max(1, screenH - size);
        return new float[]{Math.max(0f, Math.min(1f, x / fw)), Math.max(0f, Math.min(1f, y / fh))};
    }
}
