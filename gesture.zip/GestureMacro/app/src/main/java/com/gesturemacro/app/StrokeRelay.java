package com.gesturemacro.app;

/**
 * Re-sends ONE live finger, piece by piece, as a continued Android stroke.
 *
 * It is a state machine and it only ever acts because of down()/move()/up(): if no finger is down,
 * nothing is sent, ever. Pieces are sent one at a time; while one is in flight, newer finger positions
 * are merged into a single pending target. Plain Java: the Android part is the Sink.
 */
public final class StrokeRelay {
    public interface Done {
        void completed();

        void cancelled();
    }

    public interface Sink {
        /** Returns false if the piece could not even be sent. */
        boolean send(float x0, float y0, float x1, float y1, long durMs,
                     boolean first, boolean willContinue, Done done);
    }

    public interface Clock {
        long now();
    }

    public interface Listener {
        void onSend();

        void onSendFailed();

        /** Android cancelled the injected finger. */
        void onLost(boolean fingerStillDown, int completedPieces);

        /** The finger lifted and the last piece was delivered. */
        void onFinished(int completedPieces);
    }

    public static final long FIRST_MS = 10;
    public static final long MIN_MS = 16;
    public static final long MAX_MS = 100;

    private enum State { IDLE, STARTING, HOLD, FLYING, ENDING }

    private final Sink sink;
    private final Clock clock;
    private final Listener listener;

    private State state = State.IDLE;
    private float lastX, lastY, pendX, pendY;
    private boolean hasPend, upRequested;
    private long lastSendMs;
    private int completed;
    private int token;

    public StrokeRelay(Sink sink, Clock clock, Listener listener) {
        this.sink = sink;
        this.clock = clock;
        this.listener = listener;
    }

    public boolean isActive() {
        return state != State.IDLE;
    }

    /** The finger went down at (x, y). Returns false if nothing could be started. */
    public boolean down(float x, float y) {
        if (state != State.IDLE) return false;
        token++;
        lastX = x;
        lastY = y;
        hasPend = false;
        upRequested = false;
        completed = 0;
        state = State.STARTING;
        return transmit(x, y, x, y, FIRST_MS, true, true);
    }

    public void move(float x, float y) {
        if (state == State.IDLE || state == State.ENDING || upRequested) return;
        pendX = x;
        pendY = y;
        hasPend = true;
        if (state == State.HOLD) pump();
    }

    public void up(float x, float y) {
        if (state == State.IDLE || state == State.ENDING) return;
        pendX = x;
        pendY = y;
        hasPend = true;
        upRequested = true;
        if (state == State.HOLD) pump();
    }

    /** Lifts the injected finger where it is (used when the real touch was cancelled or the service stops). */
    public void abort() {
        if (state == State.IDLE) return;
        up(lastX, lastY);
    }

    private long pieceMs() {
        long dt = clock.now() - lastSendMs;
        return Math.max(MIN_MS, Math.min(MAX_MS, dt));
    }

    private void pump() {
        if (state != State.HOLD) return;
        if (upRequested) {
            float tx = hasPend ? pendX : lastX;
            float ty = hasPend ? pendY : lastY;
            float fx = lastX, fy = lastY;
            long dur = pieceMs();
            hasPend = false;
            lastX = tx;
            lastY = ty;
            state = State.ENDING;
            transmit(fx, fy, tx, ty, dur, false, false);
            return;
        }
        if (hasPend && (pendX != lastX || pendY != lastY)) {
            float fx = lastX, fy = lastY;
            float tx = pendX, ty = pendY;
            long dur = pieceMs();
            hasPend = false;
            lastX = tx;
            lastY = ty;
            state = State.FLYING;
            transmit(fx, fy, tx, ty, dur, false, true);
        } else {
            hasPend = false;
        }
    }

    private boolean transmit(float x0, float y0, float x1, float y1, long dur, boolean first, boolean willContinue) {
        final int mine = token;
        lastSendMs = clock.now();
        boolean ok = sink.send(x0, y0, x1, y1, dur, first, willContinue, new Done() {
            @Override
            public void completed() {
                if (mine == token) onCompleted();
            }

            @Override
            public void cancelled() {
                if (mine == token) onCancelled();
            }
        });
        if (ok) {
            listener.onSend();
            return true;
        }
        if (mine == token) {
            boolean down = !upRequested && state != State.ENDING;
            state = State.IDLE;
            hasPend = false;
            token++;
            listener.onSendFailed();
            if (!first) listener.onLost(down, completed);
        }
        return false;
    }

    private void onCompleted() {
        completed++;
        if (state == State.ENDING) {
            state = State.IDLE;
            listener.onFinished(completed);
        } else if (state == State.STARTING || state == State.FLYING) {
            state = State.HOLD;
            pump();
        }
    }

    private void onCancelled() {
        boolean down = !upRequested && state != State.ENDING;
        state = State.IDLE;
        hasPend = false;
        token++;
        listener.onLost(down, completed);
    }
}
