package com.gesturemacro.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** The floating button: dark rounded square with a grey ring and a white disc (like the one in the recordings). */
public class AtButtonView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AtButtonView(Context c) {
        super(c);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float s = Math.min(w, h);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xD92C2C2E);
        c.drawRoundRect(0, 0, w, h, s * 0.28f, s * 0.28f, p);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s * 0.07f);
        p.setColor(0xFF9A9AA0);
        c.drawCircle(w / 2f, h / 2f, s * 0.34f, p);

        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(w / 2f, h / 2f, s * 0.23f, p);
    }
}
