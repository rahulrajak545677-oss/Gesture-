package com.gesturemacro.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/**
 * The red trigger: a red ring with a dot, like the one in the recordings. It only draws itself.
 * It has no code that could move it: its position is set by the service from the saved setting.
 */
public class RedTriggerView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean pressedLook;

    public RedTriggerView(Context c) {
        super(c);
    }

    public void setPressedLook(boolean pressed) {
        if (pressedLook != pressed) {
            pressedLook = pressed;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float s = Math.min(w, h);
        float cx = w / 2f;
        float cy = h / 2f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFF2D2D);
        p.setAlpha(pressedLook ? 110 : 45);
        c.drawCircle(cx, cy, s * 0.46f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s * 0.07f);
        p.setColor(0xFFFF2D2D);
        p.setAlpha(255);
        c.drawCircle(cx, cy, s * 0.43f, p);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, s * 0.07f, p);
    }
}
