package com.gesturemacro.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.ArrayList;

/**
 * Red touch circles drawn while you drag on the red trigger
 * (the red circles you can see in the game recording). Not touchable: it never blocks the app below.
 */
public class TouchIndicatorView extends View {
    private static final long TRAIL_MS = 450;

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<float[]> trail = new ArrayList<>(); // x, y, timestamp
    private float[] active = new float[0];
    private long now;
    private final float radius;

    public TouchIndicatorView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        radius = 26f * d;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(3f * d);
        fill.setStyle(Paint.Style.FILL);
    }

    /** activeXY holds x,y pairs of every finger currently down. */
    public void update(float[] activeXY, long nowMs) {
        for (int i = 0; i + 1 < activeXY.length; i += 2) {
            trail.add(new float[]{activeXY[i], activeXY[i + 1], nowMs});
        }
        while (!trail.isEmpty() && nowMs - trail.get(0)[2] > TRAIL_MS) {
            trail.remove(0);
        }
        active = activeXY;
        now = nowMs;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        for (float[] t : trail) {
            float k = 1f - (now - t[2]) / (float) TRAIL_MS;
            if (k <= 0f) continue;
            ring.setColor(0xFFFF3B30);
            ring.setAlpha((int) (200 * k));
            fill.setColor(0xFFFF3B30);
            fill.setAlpha((int) (60 * k));
            c.drawCircle(t[0], t[1], radius, fill);
            c.drawCircle(t[0], t[1], radius, ring);
        }
        for (int i = 0; i + 1 < active.length; i += 2) {
            ring.setColor(0xFFFF3B30);
            ring.setAlpha(255);
            fill.setColor(0xFFFF3B30);
            fill.setAlpha(90);
            c.drawCircle(active[i], active[i + 1], radius, fill);
            c.drawCircle(active[i], active[i + 1], radius, ring);
            fill.setAlpha(255);
            c.drawCircle(active[i], active[i + 1], radius * 0.16f, fill);
        }
    }
}
