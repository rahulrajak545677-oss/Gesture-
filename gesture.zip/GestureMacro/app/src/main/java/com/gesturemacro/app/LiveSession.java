package com.gesturemacro.app;

/**
 * Glue for one live drag that starts on the red trigger: reads the finger (TouchStats), lets LiveAssist
 * correct it, re-sends it (StrokeRelay) and tells the screen where to draw the red touch circles.
 *
 * Nothing here moves the red trigger (it has no way to: it never sees the trigger's position) and nothing
 * here starts by itself: every action is a reaction to onDown / onMove / onUp / onCancel.
 */
public final class LiveSession implements StrokeRelay.Listener {
    public interface Host {
        /** x,y pairs to draw as red circles: the real finger, and the assisted point when it differs. */
        void showCircles(float[] xy);

        void endCircles();

        /** false while the injected touch is running, so it lands on the game and not on the trigger itself. */
        void setTriggerTouchable(boolean touchable);

        /** Called after repeated early failures, so a dead trigger cannot block the game's own button. */
        void pauseAssist(String reason);

        void count(String key);

        void flushCounts();
    }

    /** Two failed touches in a row switch live assist off (the trigger then lets touches through). */
    public static final int MAX_EARLY_LOSSES = 2;

    public final TouchStats stats = new TouchStats();
    public final LiveAssist assist;
    private final StrokeRelay relay;
    private final Host host;

    private boolean down;
    private boolean realCancelled; // Android took the real finger away during this touch
    private int earlyLosses;
    private float lastAx, lastAy;

    public LiveSession(Host host, StrokeRelay.Sink sink, StrokeRelay.Clock clock, float slopPx) {
        this.host = host;
        this.assist = new LiveAssist(slopPx);
        this.relay = new StrokeRelay(sink, clock, this);
    }

    public boolean isDown() {
        return down;
    }

    public boolean isRelaying() {
        return relay.isActive();
    }

    public float[] lastAssisted() {
        return new float[]{lastAx, lastAy};
    }

    private void circles(float x, float y, float ax, float ay) {
        if (Math.hypot(ax - x, ay - y) < 1.5) host.showCircles(new float[]{x, y});
        else host.showCircles(new float[]{x, y, ax, ay});
    }

    public void onDown(float x, float y, long now) {
        if (down) {
            // an "up" was missed: finish the old drag before starting a new one
            relay.abort();
            stats.end();
        }
        down = true;
        realCancelled = false;
        stats.begin(x, y, now);
        assist.begin(x, y);
        lastAx = x;
        lastAy = y;
        host.count("down");
        host.setTriggerTouchable(false);
        if (!relay.down(x, y)) host.setTriggerTouchable(true);
        circles(x, y, x, y);
    }

    public void onMove(float x, float y, long now) {
        if (!down) return;
        stats.move(x, y, now);
        float[] a = assist.apply(x, y);
        lastAx = a[0];
        lastAy = a[1];
        relay.move(a[0], a[1]);
        circles(x, y, a[0], a[1]);
    }

    public void onUp(float x, float y, long now) {
        if (!down) return;
        stats.move(x, y, now);
        stats.end();
        float[] f = assist.finish(x, y);
        lastAx = f[0];
        lastAy = f[1];
        down = false;
        relay.up(f[0], f[1]);
        host.endCircles();
    }

    /** Android cancelled the real finger (it usually happens when the injected touch starts). */
    public void onCancel(long now) {
        if (!down) return;
        host.count("real_cancel");
        realCancelled = true;
        stats.end();
        down = false;
        relay.abort();
        host.endCircles();
        host.setTriggerTouchable(true);
        earlyLoss("Android cancelled your finger when the assisted touch started");
    }

    /** Called when the service stops or the screen rotates. */
    public void reset() {
        if (down) {
            down = false;
            stats.end();
        }
        relay.abort();
        host.endCircles();
        host.setTriggerTouchable(true);
    }

    private void earlyLoss(String why) {
        earlyLosses++;
        if (earlyLosses >= MAX_EARLY_LOSSES) {
            earlyLosses = 0;
            host.pauseAssist(why);
        }
    }

    // ---- StrokeRelay.Listener

    @Override
    public void onSend() {
        host.count("pieces_sent");
    }

    @Override
    public void onSendFailed() {
        host.count("send_failed");
        host.setTriggerTouchable(true);
        earlyLoss("Android refused the assisted touch");
    }

    @Override
    public void onLost(boolean fingerStillDown, int completedPieces) {
        host.count("relay_lost");
        host.setTriggerTouchable(true);
        if (completedPieces < 2) earlyLoss("Android cancelled the assisted touch right away");
    }

    @Override
    public void onFinished(int completedPieces) {
        host.count("relay_ok");
        if (!realCancelled) earlyLosses = 0; // a touch Android cancelled does not count as a success
        host.setTriggerTouchable(true);
        host.flushCounts();
    }
}
