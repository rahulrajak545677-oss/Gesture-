package com.gesturemacro.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * "Position Red Trigger" mode: a full-screen layer over whatever app is open (your game).
 * Drag the red ring to the place you want, then tap Save. This is the only way to move the trigger.
 */
public class TriggerPlacerView extends View {
    public interface Callback {
        /** Centre of the ring in screen pixels. */
        void onSave(float cx, float cy);

        void onCancel();
    }

    private final Callback cb;
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF saveRect = new RectF();
    private final RectF cancelRect = new RectF();
    private float cx, cy;
    private final float radius;
    private boolean dragging;
    private boolean placed;

    public TriggerPlacerView(Context c, float startCx, float startCy, Callback cb) {
        super(c);
        this.cb = cb;
        d = c.getResources().getDisplayMetrics().density;
        radius = 38f * d;
        cx = startCx;
        cy = startCy;
    }

    @Override
    protected void onDraw(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x40000000);
        c.drawRect(0, 0, getWidth(), getHeight(), p);

        // red ring (same look as the real trigger)
        p.setColor(0xFFFF2D2D);
        p.setAlpha(80);
        c.drawCircle(cx, cy, radius * 1.05f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(radius * 0.16f);
        p.setColor(0xFFFF2D2D);
        c.drawCircle(cx, cy, radius, p);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, radius * 0.16f, p);

        // hint
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(15f * d);
        c.drawText("Drag the red ring to where you want it, then tap Save", getWidth() / 2f, 108f * d, p);

        float bw = 110f * d, bh = 42f * d, gap = 16f * d, top = 28f * d;
        float mid = getWidth() / 2f;
        cancelRect.set(mid - gap / 2f - bw, top, mid - gap / 2f, top + bh);
        saveRect.set(mid + gap / 2f, top, mid + gap / 2f + bw, top + bh);
        p.setColor(0xDD1C1C1E);
        c.drawRoundRect(cancelRect, bh / 2f, bh / 2f, p);
        c.drawRoundRect(saveRect, bh / 2f, bh / 2f, p);
        p.setTextSize(17f * d);
        p.setColor(0xFF0A84FF);
        c.drawText("Cancel", cancelRect.centerX(), cancelRect.centerY() + 6f * d, p);
        p.setColor(placed ? 0xFF30D158 : 0xFF8E8E93);
        c.drawText("Save", saveRect.centerX(), saveRect.centerY() + 6f * d, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX();
        float y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (cancelRect.contains(x, y)) {
                    cb.onCancel();
                    return true;
                }
                if (saveRect.contains(x, y)) {
                    cb.onSave(cx + offsetX(), cy + offsetY());
                    return true;
                }
                dragging = true;
                cx = x;
                cy = y;
                placed = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) {
                    cx = x;
                    cy = y;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    /** View coordinates to screen coordinates (the layer normally starts at 0,0, but cut-outs can shift it). */
    private float offsetX() {
        int[] l = new int[2];
        getLocationOnScreen(l);
        return l[0];
    }

    private float offsetY() {
        int[] l = new int[2];
        getLocationOnScreen(l);
        return l[1];
    }
}
