package com.gesturemacro.app;

import java.util.List;

/**
 * Live assistance for ONE drag. It never plays anything by itself: it only turns the finger position
 * you give it (every time you move) into a slightly corrected position.
 *
 * The saved gesture only contributes its DIRECTION (first point to last point of its longest stroke).
 * While your drag points roughly the same way (within 60 degrees), the sideways wobble is reduced and
 * the path is smoothed. If you drag some other way, or have not moved far enough yet, your own
 * position is returned untouched. Strength 0 = always untouched. Plain Java, no Android classes.
 */
public final class LiveAssist {
    /** cos(60 degrees): drags further off the saved direction than this are left alone. */
    public static final float MATCH_COS = 0.5f;

    private final float slopPx;
    private boolean hasRef;
    private float rx, ry;
    private float strength;
    private float x0, y0, sx, sy;
    private boolean engaged;

    public LiveAssist(float slopPx) {
        this.slopPx = slopPx;
    }

    public void setStrength(float s) {
        strength = Math.max(0f, Math.min(1f, s));
    }

    public float getStrength() {
        return strength;
    }

    public void clearReference() {
        hasRef = false;
    }

    /** Uses the direction from the first to the last point; returns false (no reference) if they are the same spot. */
    public boolean setReferenceFromPoints(List<float[]> pts) {
        hasRef = false;
        if (pts == null || pts.size() < 2) return false;
        float[] a = pts.get(0);
        float[] b = pts.get(pts.size() - 1);
        float dx = b[0] - a[0];
        float dy = b[1] - a[1];
        float len = (float) Math.hypot(dx, dy);
        if (len < 1f) return false;
        rx = dx / len;
        ry = dy / len;
        hasRef = true;
        return true;
    }

    public boolean hasReference() {
        return hasRef;
    }

    public float[] referenceDirection() {
        return new float[]{rx, ry};
    }

    public void begin(float x, float y) {
        x0 = sx = x;
        y0 = sy = y;
        engaged = false;
    }

    /** The corrected position for the finger position (x, y), or (x, y) itself when no help applies. */
    private float[] target(float x, float y) {
        if (!hasRef || strength <= 0f) return null;
        float dx = x - x0;
        float dy = y - y0;
        float dist = (float) Math.hypot(dx, dy);
        if (dist < slopPx) return null;
        float along = dx * rx + dy * ry;
        if (along / dist < MATCH_COS) return null;
        float cx = dx - along * rx;
        float cy = dy - along * ry;
        float keep = 1f - strength; // share of the sideways wobble that is kept
        return new float[]{x0 + along * rx + keep * cx, y0 + along * ry + keep * cy};
    }

    /** Call for every finger movement. */
    public float[] apply(float x, float y) {
        float[] t = target(x, y);
        if (t == null) {
            engaged = false;
            sx = x;
            sy = y;
            return new float[]{x, y};
        }
        if (!engaged) {
            engaged = true;
            sx = x;
            sy = y;
        }
        float k = 1f - 0.6f * strength;
        sx += (t[0] - sx) * k;
        sy += (t[1] - sy) * k;
        return new float[]{sx, sy};
    }

    /** Call when the finger lifts: the final point, without smoothing lag. */
    public float[] finish(float x, float y) {
        float[] t = target(x, y);
        return t != null ? t : new float[]{x, y};
    }
}
