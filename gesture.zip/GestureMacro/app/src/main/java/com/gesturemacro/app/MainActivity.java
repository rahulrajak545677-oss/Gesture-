package com.gesturemacro.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Settings screens that follow the iPhone layout shown in the recordings:
 * Touch  >  AssistiveTouch  >  (Customize Top Level Menu, Custom Actions, Custom Gestures,
 * Idle Opacity, Pointer Devices ...). Every page is built in code; there are no layout files.
 */
public class MainActivity extends Activity {

    private interface PageBuilder {
        Ui.Page build();
    }

    private FrameLayout container;
    private final ArrayList<PageBuilder> stack = new ArrayList<>();
    private Ui.Page curPage;

    private boolean editing;          // "Edit" mode of the Custom Gestures list
    private String pendingDelete;     // gesture whose red minus was tapped

    private final Runnable popRun = new Runnable() {
        @Override
        public void run() {
            pop();
        }
    };

    // ------------------------------------------------------------------ navigation

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        container = new FrameLayout(this);
        container.setBackgroundColor(Ui.BG);
        setContentView(container);
        stack.add(new PageBuilder() {
            @Override
            public Ui.Page build() {
                return pageTouch();
            }
        });
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    public void onBackPressed() {
        pop();
    }

    private void push(PageBuilder pb) {
        stack.add(pb);
        render();
    }

    private void pop() {
        if (stack.size() > 1) {
            stack.remove(stack.size() - 1);
            editing = false;
            pendingDelete = null;
            render();
        } else {
            finish();
        }
    }

    private void render() {
        container.removeAllViews();
        curPage = stack.get(stack.size() - 1).build();
        container.addView(curPage.root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void refresh() {
        final int y = curPage != null ? curPage.scroll.getScrollY() : 0;
        render();
        final ScrollView sv = curPage.scroll;
        sv.post(new Runnable() {
            @Override
            public void run() {
                sv.scrollTo(0, y);
            }
        });
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    // ------------------------------------------------------------------ small helpers

    private boolean serviceOn() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName me = new ComponentName(this, GestureService.class);
        for (String s : enabled.split(":")) {
            ComponentName c = ComponentName.unflattenFromString(s);
            if (c != null && c.equals(me)) return true;
        }
        return false;
    }

    private View sw(String title, final String key, boolean def) {
        return Ui.switchRow(this, title, Store.b(this, key, def), new Ui.OnBool() {
            @Override
            public void on(boolean v) {
                Store.setB(MainActivity.this, key, v);
            }
        });
    }

    private void addBanner(Ui.Page p) {
        if (serviceOn()) return;
        p.body.addView(Ui.banner(this,
                "Gesture Macro is not switched on in Android Accessibility yet. Tap here to set it up (30 seconds).",
                new Runnable() {
                    @Override
                    public void run() {
                        showSetup();
                    }
                }));
    }

    private LinearLayout addGroup(Ui.Page p) {
        LinearLayout g = Ui.group(this);
        p.body.addView(g);
        return g;
    }

    private String labelOf(String[] ids, String[] labels, String id) {
        for (int i = 0; i < ids.length; i++) {
            if (ids[i].equals(id)) return labels[i];
        }
        return "";
    }

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
    }

    private void showSetup() {
        dialog().setTitle("Turn on Gesture Macro")
                .setMessage("1. Tap \"Open Accessibility Settings\".\n"
                        + "2. Find \"Gesture Macro\" (it can be under Installed apps or Downloaded apps) and switch it ON.\n"
                        + "3. Tap Allow.\n\n"
                        + "If the switch is greyed out or says \"Restricted setting\": tap \"Open App Info\", "
                        + "tap the three dots at the top right, choose \"Allow restricted settings\", then repeat step 1.\n\n"
                        + "Android needs this permission so the floating button can appear over other apps and "
                        + "tap or swipe for you.")
                .setPositiveButton("Open Accessibility Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    }
                })
                .setNeutralButton("Open App Info", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showHelp() {
        dialog().setTitle("How to use")
                .setMessage("RECORD A GESTURE\n"
                        + "Custom Gestures > Create New Gesture. Tap or swipe on the black screen (rotate your phone first "
                        + "if you will use it in a landscape game). Press Stop, then Play to preview, then Save and give it a name.\n\n"
                        + "USE IT LIVE\n"
                        + "Nothing is played automatically. Choose a gesture in Live Gesture Assist (or tap it in the menu under Custom) "
                        + "to make it the Assist Gesture. In your game, put your own finger on the red trigger and drag. "
                        + "The app reads your movement live and, when you drag roughly the way the gesture goes, smooths it. "
                        + "Red circles show where your finger and the assisted touch are.\n\n"
                        + "RED TRIGGER\n"
                        + "It stays where it is. Move it only with Position Red Trigger.\n\n"
                        + "FLOATING BUTTON\n"
                        + "Drag it anywhere. It fades to the Idle Opacity when you are not using it. "
                        + "Single-Tap, Double-Tap and Long Press can each run an action.\n\n"
                        + "Hold your phone the same way (portrait or landscape) as when you recorded the Assist Gesture.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showNote(String title, String msg) {
        dialog().setTitle(title).setMessage(msg).setPositiveButton("OK", null).show();
    }

    private static final String ANDROID_NOTE =
            "These switches copy the iPhone screens so everything is where you expect it. "
                    + "Android does not let an app control the system pointer, Reachability, Tap to Wake and similar "
                    + "system features, so those options are saved but do not change anything yet. "
                    + "The floating button, menu, Custom Actions, Custom Gestures, Idle Opacity, Sound on Click and "
                    + "Vibration all work.";

    // ------------------------------------------------------------------ page: Touch

    private Ui.Page pageTouch() {
        Ui.Page p = Ui.page(this, "Accessibility", "Touch", null, new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, null);
        addBanner(p);

        String state = (serviceOn() && Store.b(this, "at_enabled", true)) ? "On" : "Off";
        LinearLayout g = addGroup(p);
        Ui.addRow(g, Ui.navRow(this, "AssistiveTouch", state, new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageAT();
                    }
                });
            }
        }));
        p.body.addView(Ui.footer(this, "AssistiveTouch allows you to use your phone if you have difficulty touching the screen or if you require an adaptive accessory."));

        g = addGroup(p);
        Ui.addRow(g, sw("Reachability", "reachability", true));
        p.body.addView(Ui.footer(this, "Swipe down on the bottom edge of the screen to bring the top into reach."));

        g = addGroup(p);
        String[] hid = {"fast", "slow"};
        String[] hl = {"Fast", "Slow"};
        Ui.addRow(g, Ui.navRow(this, "Haptic Touch", "", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return choice("Touch", "Haptic Touch", "haptic_touch", "fast",
                                new String[]{"fast", "slow"}, new String[]{"Fast", "Slow"},
                                "Touch Duration. Press on the display using a different length of time to reveal content previews, actions and contextual menus.");
                    }
                });
            }
        }));
        p.body.addView(Ui.footer(this, "Press on the display using a different length of time to reveal content previews, actions and contextual menus."));

        g = addGroup(p);
        boolean taOn = Store.b(this, "ta_hold", false) || Store.b(this, "ta_ignore", false) || Store.b(this, "ta_assist", false);
        Ui.addRow(g, Ui.navRow(this, "Touch Accommodations", taOn ? "On" : "Off", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageAccommodations();
                    }
                });
            }
        }));
        p.body.addView(Ui.footer(this, "If you have trouble using the touch screen, adjust the following settings to change how the screen will respond to touches."));

        g = addGroup(p);
        Ui.addRow(g, sw("Tap to Wake", "tap_to_wake", true));
        p.body.addView(Ui.footer(this, "Wake the screen when you tap on the display."));

        g = addGroup(p);
        Ui.addRow(g, sw("Shake to Undo", "shake_undo", true));
        p.body.addView(Ui.footer(this, "If you tend to shake your phone by accident, you can disable Shake to Undo to prevent the Undo alert from appearing."));

        g = addGroup(p);
        Ui.addRow(g, sw("Vibration", "vibration", true));
        p.body.addView(Ui.footer(this, "When this switch is off, the vibration feedback of the floating button is disabled."));

        g = addGroup(p);
        Ui.addRow(g, sw("Prevent Lock to End Call", "prevent_lock", false));
        p.body.addView(Ui.footer(this, "Prevent the side button from ending the current call."));

        g = addGroup(p);
        Ui.addRow(g, Ui.navRow(this, "Call Audio Routing",
                labelOf(new String[]{"automatic", "bluetooth", "speaker"}, new String[]{"Automatic", "Bluetooth Headset", "Speaker"},
                        Store.s(this, "call_audio", "automatic")),
                new Runnable() {
                    @Override
                    public void run() {
                        push(new PageBuilder() {
                            @Override
                            public Ui.Page build() {
                                return choice("Touch", "Call Audio Routing", "call_audio", "automatic",
                                        new String[]{"automatic", "bluetooth", "speaker"},
                                        new String[]{"Automatic", "Bluetooth Headset", "Speaker"},
                                        "Call audio routing determines where audio will be heard during a phone call.");
                            }
                        });
                    }
                }));
        p.body.addView(Ui.footer(this, "Call audio routing determines where audio will be heard during a phone call."));
        p.body.addView(Ui.footer(this, ANDROID_NOTE));
        return p;
    }

    private Ui.Page pageAccommodations() {
        Ui.Page p = Ui.page(this, "Touch", "Touch Accommodations", null, popRun, null);
        LinearLayout g = addGroup(p);
        Ui.addRow(g, sw("Hold Duration", "ta_hold", false));
        Ui.addRow(g, sw("Ignore Repeat", "ta_ignore", false));
        Ui.addRow(g, sw("Tap Assistance", "ta_assist", false));
        p.body.addView(Ui.footer(this, "If you have trouble using the touch screen, adjust these settings to change how the screen will respond to touches."));
        p.body.addView(Ui.footer(this, ANDROID_NOTE));
        return p;
    }

    // ------------------------------------------------------------------ generic choice page

    private Ui.Page choice(String back, String title, final String key, String def,
                           final String[] ids, final String[] labels, String footerText) {
        Ui.Page p = Ui.page(this, back, title, null, popRun, null);
        String cur = Store.s(this, key, def);
        LinearLayout g = addGroup(p);
        for (int n = 0; n < ids.length; n++) {
            final String id = ids[n];
            Ui.addRow(g, Ui.checkRow(this, labels[n], id.equals(cur), new Runnable() {
                @Override
                public void run() {
                    Store.setS(MainActivity.this, key, id);
                    refresh();
                }
            }));
        }
        if (footerText != null) p.body.addView(Ui.footer(this, footerText));
        return p;
    }

    // ------------------------------------------------------------------ page: AssistiveTouch

    private Ui.Page pageAT() {
        Runnable toggleEdit = new Runnable() {
            @Override
            public void run() {
                editing = !editing;
                pendingDelete = null;
                refresh();
            }
        };
        Ui.Page p = Ui.page(this, "Touch", "AssistiveTouch", editing ? "Done" : "Edit", popRun, toggleEdit);
        addBanner(p);

        LinearLayout g = addGroup(p);
        Ui.addRow(g, Ui.switchRow(this, "AssistiveTouch", Store.b(this, "at_enabled", true), new Ui.OnBool() {
            @Override
            public void on(boolean v) {
                Store.setB(MainActivity.this, "at_enabled", v);
                if (v && !serviceOn()) showSetup();
            }
        }));
        p.body.addView(Ui.footer(this, "AssistiveTouch allows you to use your phone if you have difficulty touching the screen or if you require an adaptive accessory."));
        p.body.addView(Ui.link(this, "How to use AssistiveTouch…", new Runnable() {
            @Override
            public void run() {
                showHelp();
            }
        }));

        g = addGroup(p);
        Ui.addRow(g, Ui.navRow(this, "Customize Top Level Menu", "", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageMenuCustomize();
                    }
                });
            }
        }));

        // CUSTOM ACTIONS
        p.body.addView(Ui.header(this, "Custom Actions"));
        g = addGroup(p);
        Ui.addRow(g, actionRow("Single-Tap", "single_tap", "none"));
        Ui.addRow(g, actionRow("Double-Tap", "double_tap", "menu"));
        Ui.addRow(g, actionRow("Long Press", "long_press", "none"));
        p.body.addView(Ui.footer(this, "Custom actions allow you to interact directly with the AssistiveTouch icon without opening the menu."));

        // CUSTOM GESTURES
        p.body.addView(Ui.header(this, "Custom Gestures"));
        g = addGroup(p);
        final List<Macro> list = Store.loadMacros(this);
        for (int n = 0; n < list.size(); n++) {
            final Macro m = list.get(n);
            if (editing) {
                Ui.addRow(g, editRow(m, n, list));
            } else {
                Ui.addRow(g, Ui.textRow(this, m.name, new Runnable() {
                    @Override
                    public void run() {
                        renameDialog(m);
                    }
                }));
            }
        }
        Ui.addRow(g, Ui.navRow(this, "Create New Gesture…", "", new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(MainActivity.this, RecorderActivity.class));
            }
        }, !editing));
        p.body.addView(Ui.footer(this, "Custom gestures allow you to record gestures. Choosing one from Custom in the Menu (or from a Custom Action) selects it as the Assist Gesture. It is never played by itself."));

        g = addGroup(p);
        Ui.addRow(g, Ui.navRow(this, "Idle Opacity", Store.i(this, "idle_opacity", 37) + "%", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageOpacity();
                    }
                });
            }
        }));

        // LIVE GESTURE ASSIST (Android additions)
        p.body.addView(Ui.header(this, "Live Gesture Assist"));
        g = addGroup(p);
        Ui.addRow(g, sw("Red Trigger", "trig_enabled", true));
        Ui.addRow(g, Ui.switchRow(this, "Live Assist", Store.b(this, "live_assist", true), new Ui.OnBool() {
            @Override
            public void on(boolean v) {
                Store.setB(MainActivity.this, "live_assist", v);
                if (v) Store.setB(MainActivity.this, "assist_paused", false);
                refresh();
            }
        }));
        p.body.addView(Ui.footer(this, assistStatus()));
        g = addGroup(p);
        Ui.addRow(g, Ui.navRow(this, "Assist Gesture", assistName(), new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageAssistGesture();
                    }
                });
            }
        }));
        p.body.addView(Ui.header(this, "Assist Strength"));
        g = addGroup(p);
        Ui.addRow(g, Ui.sliderRow(this, 0, 100, Store.i(this, "assist_strength", 60), new Ui.OnInt() {
            @Override
            public void on(int v) {
                Store.setI(MainActivity.this, "assist_strength", v);
            }
        }));
        p.body.addView(Ui.footer(this, "0 leaves your finger exactly as it is. Higher values smooth your drag and reduce sideways wobble when you drag roughly the way the Assist Gesture goes."));
        g = addGroup(p);
        Ui.addRow(g, Ui.navRow(this, "Position Red Trigger…", "", new Runnable() {
            @Override
            public void run() {
                positionTrigger();
            }
        }));
        Ui.addRow(g, Ui.navRow(this, "Live Assist Diagnostics", "", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageDiagnostics();
                    }
                });
            }
        }));
        p.body.addView(Ui.footer(this, "The red trigger stays exactly where you put it. It never follows your finger. Put your finger on it and drag to use Live Assist."));
        g = addGroup(p);
        Ui.addRow(g, sw("Show Red Touch Circles", "show_touches", true));
        p.body.addView(Ui.footer(this, "Draws red circles over the screen while you drag on the red trigger: one at your real finger and, when it differs, one at the assisted touch. They are separate from the trigger and do not block touches."));

        // POINTER DEVICES
        p.body.addView(Ui.header(this, "Pointer Devices"));
        g = addGroup(p);
        Ui.addRow(g, Ui.navRow(this, "Devices", "", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageDevices();
                    }
                });
            }
        }));
        Ui.addRow(g, Ui.navRow(this, "Mouse Keys", "", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageMouseKeys();
                    }
                });
            }
        }));
        Ui.addRow(g, sw("Show Onscreen Keyboard", "show_kb", false));
        Ui.addRow(g, sw("Sound on Click", "sound_on_click", false));
        Ui.addRow(g, sw("Always Show Menu", "always_show_menu", true));
        p.body.addView(Ui.footer(this, "Show the AssistiveTouch menu when a pointer device is connected."));

        g = addGroup(p);
        Ui.addRow(g, sw("Perform Touch Gestures", "perform_touch", true));
        p.body.addView(Ui.footer(this, "Simulate a finger when performing gestures with a pointer device. When enabled, apps may recognize some gestures differently. For example, scrolling may be preferred over text selection."));

        g = addGroup(p);
        Ui.addRow(g, sw("Use Game Controller", "game_ctrl", false));
        p.body.addView(Ui.footer(this, "Allow AssistiveTouch to be controlled by Game Controllers."));
        p.body.addView(Ui.link(this, "Learn more…", new Runnable() {
            @Override
            public void run() {
                showNote("Game Controller", "On the iPhone this lets a game controller move the AssistiveTouch pointer. Android does not offer this to apps, so the switch is only saved.");
            }
        }));

        p.body.addView(Ui.header(this, "Tracking Sensitivity"));
        g = addGroup(p);
        Ui.addRow(g, Ui.sliderRow(this, 0, 100, Store.i(this, "tracking", 80), new Ui.OnInt() {
            @Override
            public void on(int v) {
                Store.setI(MainActivity.this, "tracking", v);
            }
        }));

        g = addGroup(p);
        ((LinearLayout.LayoutParams) g.getLayoutParams()).topMargin = dp(24);
        Ui.addRow(g, sw("Dwell Control", "dwell", false));
        final String[] fbIds = {"tap", "double_tap", "long_press", "scroll", "pinch"};
        final String[] fbLabels = {"Tap", "Double Tap", "Long Press", "Scroll", "Pinch"};
        Ui.addRow(g, Ui.navRow(this, "Fallback Action", labelOf(fbIds, fbLabels, Store.s(this, "fallback", "tap")), new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return choice("AssistiveTouch", "Fallback Action", "fallback", "tap", fbIds, fbLabels,
                                "The action that is performed when the cursor stays still.");
                    }
                });
            }
        }));
        Ui.addRow(g, Ui.navRow(this, "Movement Tolerance", "", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageTolerance();
                    }
                });
            }
        }));
        Ui.addRow(g, Ui.navRow(this, "Hot Corners", "", new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageHotCorners();
                    }
                });
            }
        }));
        Ui.addRow(g, sw("Extended Predictions", "ext_pred", false));
        Ui.addRow(g, dwellRow());
        p.body.addView(Ui.footer(this, "When Dwell Control is enabled, holding the cursor still for the specified amount of time will perform the selected dwell action."));
        p.body.addView(Ui.footer(this, ANDROID_NOTE));
        return p;
    }

    private View actionRow(final String title, final String key, final String def) {
        String cur = Store.s(this, key, def);
        return Ui.navRow(this, title, Store.actionLabel(this, cur), new Runnable() {
            @Override
            public void run() {
                push(new PageBuilder() {
                    @Override
                    public Ui.Page build() {
                        return pageAction(key, def, title);
                    }
                });
            }
        });
    }

    private Ui.Page pageAction(final String key, String def, String title) {
        Ui.Page p = Ui.page(this, "AssistiveTouch", title, null, popRun, null);
        String cur = Store.s(this, key, def);
        LinearLayout g = addGroup(p);
        for (int n = 0; n < Store.ACTION_IDS.length; n++) {
            final String id = Store.ACTION_IDS[n];
            Ui.addRow(g, Ui.checkRow(this, Store.ACTION_LABELS[n], id.equals(cur), new Runnable() {
                @Override
                public void run() {
                    Store.setS(MainActivity.this, key, id);
                    pop();
                }
            }));
        }
        List<Macro> ms = Store.loadMacros(this);
        if (!ms.isEmpty()) {
            p.body.addView(Ui.header(this, "Custom Gestures"));
            g = addGroup(p);
            for (Macro m : ms) {
                final String id = "macro:" + m.id;
                Ui.addRow(g, Ui.checkRow(this, m.name, id.equals(cur), new Runnable() {
                    @Override
                    public void run() {
                        Store.setS(MainActivity.this, key, id);
                        pop();
                    }
                }));
            }
        }
        return p;
    }

    // ------------------------------------------------------------------ live assist helpers and pages

    private String assistName() {
        String id = Store.s(this, "assist_gesture", "");
        if (id.length() == 0) return "None";
        Macro m = Store.findMacro(this, id);
        return m == null ? "None" : m.name;
    }

    private String assistStatus() {
        if (android.os.Build.VERSION.SDK_INT < 26) {
            return "Live Assist needs Android 8.0 or newer. The red trigger is shown but lets every touch through.";
        }
        if (!Store.b(this, "live_assist", true)) {
            return "Live Assist is off. The red trigger is only a marker and lets every touch through.";
        }
        if (Store.b(this, "assist_paused", false)) {
            return "Live Assist paused itself because Android rejected the assisted touch. The red trigger lets touches through. Switch Live Assist off and on to try again, and see Diagnostics.";
        }
        return "Live Assist is on. Put your finger on the red trigger and drag. This is experimental: Android does not let an app edit another app's real touches, so check Diagnostics to see if it works on your phone.";
    }

    private void positionTrigger() {
        final GestureService s = GestureService.instance;
        if (s == null) {
            showNote("Turn the service on first", "Switch on GestureMacro under Settings > Accessibility, then try again.");
            return;
        }
        dialog().setTitle("Position Red Trigger")
                .setMessage("This app will step aside and a placement layer will appear over whatever is behind it. "
                        + "Drag the red ring where you want it, then tap Save. "
                        + "Tip: open your game first, then bring GestureMacro back and start this, if you want to line the ring up with the game.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Start", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        s.beginTriggerPlacement();
                        moveTaskToBack(true);
                    }
                })
                .show();
    }

    private Ui.Page pageAssistGesture() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Assist Gesture", null, popRun, null);
        String cur = Store.s(this, "assist_gesture", "");
        LinearLayout g = addGroup(p);
        Ui.addRow(g, Ui.checkRow(this, "None", cur.length() == 0, new Runnable() {
            @Override
            public void run() {
                Store.setS(MainActivity.this, "assist_gesture", "");
                pop();
            }
        }));
        for (final Macro m : Store.loadMacros(this)) {
            Ui.addRow(g, Ui.checkRow(this, m.name, m.id.equals(cur), new Runnable() {
                @Override
                public void run() {
                    Store.setS(MainActivity.this, "assist_gesture", m.id);
                    pop();
                }
            }));
        }
        p.body.addView(Ui.footer(this, "Live Assist uses only the direction of the chosen gesture (from its first point to its last point). "
                + "While you drag on the red trigger roughly that way, sideways wobble is reduced and your path is smoothed. "
                + "Drag any other way and your finger is passed through untouched. The gesture is never played by itself, "
                + "and it is only used in the orientation (portrait or landscape) it was recorded in."));
        return p;
    }

    private void diagRow(LinearLayout g, final String title, String key, final String meaning) {
        Ui.addRow(g, Ui.navRow(this, title, String.valueOf(Store.i(this, "diag_" + key, 0)), new Runnable() {
            @Override
            public void run() {
                showNote(title, meaning);
            }
        }));
    }

    private Ui.Page pageDiagnostics() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Live Assist Diagnostics", null, popRun, null);
        LinearLayout g = addGroup(p);
        diagRow(g, "Touches on the trigger", "down", "How many times your finger started on the red trigger.");
        diagRow(g, "Assisted pieces sent", "pieces_sent", "How many short pieces of the assisted touch were sent to the screen.");
        diagRow(g, "Assisted touches finished", "relay_ok", "Touches that were relayed to the end without Android cancelling them. If this grows along with the first line, the relay works on your phone.");
        diagRow(g, "Real finger cancelled", "real_cancel", "Android cancelled your own finger. When this grows on every touch, Android is dropping your real touch as soon as the app sends the assisted one. That is the Android limit, and Live Assist pauses itself after two in a row.");
        diagRow(g, "Assisted touch cancelled", "relay_lost", "Android cancelled the injected touch part-way through.");
        diagRow(g, "Assisted touch refused", "send_failed", "Android refused to take the assisted touch at all (for example when the accessibility service is not allowed to perform gestures).");
        g = addGroup(p);
        Ui.addRow(g, Ui.textRow(this, "Reset counters", new Runnable() {
            @Override
            public void run() {
                Store.resetDiag(MainActivity.this);
                refresh();
            }
        }));
        p.body.addView(Ui.footer(this, "These numbers are the only way to know whether live assist works on your phone and your game. They are updated when a touch ends. Tap a line to see what it means."));
        return p;
    }

    // ------------------------------------------------------------------ custom gesture rows

    private void renameDialog(final Macro m) {
        final EditText et = new EditText(this);
        et.setText(m.name);
        et.setSingleLine(true);
        et.setSelection(m.name.length());
        dialog().setTitle("Gesture name")
                .setView(et)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String name = et.getText().toString().trim();
                        if (name.isEmpty()) return;
                        List<Macro> all = Store.loadMacros(MainActivity.this);
                        for (Macro x : all) {
                            if (x.id.equals(m.id)) x.name = name;
                        }
                        Store.saveMacros(MainActivity.this, all);
                        refresh();
                    }
                })
                .show();
    }

    private void deleteMacro(Macro m) {
        List<Macro> all = Store.loadMacros(this);
        for (int i = all.size() - 1; i >= 0; i--) {
            if (all.get(i).id.equals(m.id)) all.remove(i);
        }
        Store.saveMacros(this, all);
        String ref = "macro:" + m.id;
        String[] keys = {"single_tap", "double_tap", "long_press"};
        String[] defs = {"none", "menu", "none"};
        for (int i = 0; i < keys.length; i++) {
            if (ref.equals(Store.s(this, keys[i], defs[i]))) Store.setS(this, keys[i], "none");
        }
        pendingDelete = null;
        refresh();
    }

    /** Edit mode row: red minus, name, reorder handle. Tapping the minus reveals "Delete". */
    private View editRow(final Macro m, final int index, final List<Macro> list) {
        final int delW = dp(88);
        final FrameLayout wrap = new FrameLayout(this);
        wrap.setBackgroundColor(Ui.CARD);

        TextView del = Ui.tv(this, "Delete", 17, Color.WHITE);
        del.setGravity(Gravity.CENTER);
        del.setBackgroundColor(Ui.RED);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteMacro(m);
            }
        });
        wrap.addView(del, new FrameLayout.LayoutParams(delW, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));

        final LinearLayout fg = new LinearLayout(this);
        fg.setOrientation(LinearLayout.HORIZONTAL);
        fg.setGravity(Gravity.CENTER_VERTICAL);
        fg.setBackgroundColor(Ui.CARD);
        fg.setPadding(dp(12), dp(11), dp(12), dp(11));
        fg.setMinimumHeight(dp(46));

        final boolean pend = m.id.equals(pendingDelete);
        TextView minus = Ui.tv(this, "−", 18, Color.WHITE);
        minus.setGravity(Gravity.CENTER);
        minus.setBackground(Ui.round(Ui.RED, dp(12)));
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pendingDelete = pend ? null : m.id;
                refresh();
            }
        });
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(24), dp(24));
        mlp.setMargins(0, 0, dp(12), 0);
        fg.addView(minus, mlp);

        TextView title = Ui.tv(this, m.name, 17, Ui.TEXT);
        fg.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView handle = Ui.tv(this, "≡", 26, Ui.SUB);
        handle.setPadding(dp(12), 0, dp(4), 0);
        fg.addView(handle);

        wrap.addView(fg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (pend) {
            fg.setTranslationX(-delW);
            minus.setRotation(90f);
        }

        handle.setOnTouchListener(new View.OnTouchListener() {
            private float startY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startY = e.getRawY();
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        wrap.setTranslationZ(dp(8));
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        wrap.setTranslationY(e.getRawY() - startY);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        float dy = e.getRawY() - startY;
                        int rowH = Math.max(1, wrap.getHeight());
                        int target = Math.max(0, Math.min(list.size() - 1, index + Math.round(dy / rowH)));
                        wrap.setTranslationY(0);
                        wrap.setTranslationZ(0);
                        if (target != index && e.getActionMasked() == MotionEvent.ACTION_UP) {
                            Macro moved = list.remove(index);
                            list.add(target, moved);
                            Store.saveMacros(MainActivity.this, list);
                        }
                        refresh();
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
        return wrap;
    }

    // ------------------------------------------------------------------ sub pages

    private Ui.Page pageMenuCustomize() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Customize Top Level Menu", null, popRun, null);
        p.body.addView(Ui.header(this, "Icons"));
        LinearLayout g = addGroup(p);
        final List<String> on = Store.menuItems(this);
        for (int i = 0; i < Store.MENU_KEYS.length; i++) {
            final String key = Store.MENU_KEYS[i];
            Ui.addRow(g, Ui.switchRow(this, Store.MENU_LABELS[i], on.contains(key), new Ui.OnBool() {
                @Override
                public void on(boolean v) {
                    if (!v && Store.menuItems(MainActivity.this).size() <= 1) {
                        refresh(); // at least one icon must stay
                        return;
                    }
                    Store.setMenuItem(MainActivity.this, key, v);
                }
            }));
        }
        p.body.addView(Ui.footer(this, "Choose which icons appear when you open the floating menu. At least one must stay on."));
        return p;
    }

    private Ui.Page pageOpacity() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Idle Opacity", null, popRun, null);
        int cur = Store.i(this, "idle_opacity", 37);

        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER_HORIZONTAL);
        preview.setPadding(0, dp(16), 0, dp(16));
        final AtButtonView btn = new AtButtonView(this);
        btn.setAlpha(cur / 100f);
        preview.addView(btn, new LinearLayout.LayoutParams(dp(72), dp(72)));
        final TextView val = Ui.tv(this, cur + "%", 28, Ui.TEXT);
        val.setPadding(0, dp(12), 0, 0);
        preview.addView(val);
        p.body.addView(preview);

        LinearLayout g = addGroup(p);
        LinearLayout r = Ui.plainRow(this);
        r.addView(Ui.tv(this, "15%", 13, Ui.SUB));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(8), 0, dp(8), 0);
        SeekBar sb = Ui.makeSeek(this, 15, 100, cur, new Ui.OnInt() {
            @Override
            public void on(int v) {
                Store.setI(MainActivity.this, "idle_opacity", v);
                val.setText(v + "%");
                btn.setAlpha(v / 100f);
            }
        });
        r.addView(sb, lp);
        r.addView(Ui.tv(this, "100%", 13, Ui.SUB));
        Ui.addRow(g, r);
        p.body.addView(Ui.footer(this, "How visible the floating button is when you are not touching it."));
        return p;
    }

    private Ui.Page pageDevices() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Devices", null, popRun, null);
        LinearLayout g = Ui.group(this);
        int count = 0;
        for (int id : android.view.InputDevice.getDeviceIds()) {
            android.view.InputDevice d = android.view.InputDevice.getDevice(id);
            if (d == null || d.isVirtual()) continue;
            int src = d.getSources();
            boolean pointer = (src & android.view.InputDevice.SOURCE_MOUSE) == android.view.InputDevice.SOURCE_MOUSE
                    || (src & android.view.InputDevice.SOURCE_TOUCHPAD) == android.view.InputDevice.SOURCE_TOUCHPAD
                    || (src & android.view.InputDevice.SOURCE_TRACKBALL) == android.view.InputDevice.SOURCE_TRACKBALL;
            if (!pointer) continue;
            Ui.addRow(g, Ui.textRow(this, d.getName(), null));
            count++;
        }
        if (count > 0) p.body.addView(g);
        p.body.addView(Ui.footer(this, count > 0
                ? "Connected pointer devices."
                : "No pointer devices are connected. Connect a Bluetooth or USB mouse to see it here."));
        return p;
    }

    private Ui.Page pageMouseKeys() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Mouse Keys", null, popRun, null);
        LinearLayout g = addGroup(p);
        Ui.addRow(g, sw("Mouse Keys", "mk_on", false));
        p.body.addView(Ui.footer(this, "Mouse Keys allows AssistiveTouch to control the pointer using:\n• Keyboard keys\n• Numeric keypad"));
        p.body.addView(Ui.link(this, "Learn more…", new Runnable() {
            @Override
            public void run() {
                showNote("Mouse Keys", "On the iPhone this moves the pointer with the keyboard. Android does not let apps move the system pointer, so the switch is only saved.");
            }
        }));

        g = addGroup(p);
        ((LinearLayout.LayoutParams) g.getLayoutParams()).topMargin = dp(16);
        Ui.addRow(g, sw("Option Key Toggle", "mk_option", false));
        p.body.addView(Ui.footer(this, "Tap the option key five times to toggle Mouse Keys."));

        g = addGroup(p);
        Ui.addRow(g, sw("Use Primary Keyboard", "mk_primary", true));
        p.body.addView(Ui.footer(this, "Use keys on connected primary keyboards. Keys on a numeric keypad will always be used."));

        p.body.addView(Ui.header(this, "Initial Delay"));
        g = addGroup(p);
        Ui.addRow(g, Ui.sliderRow(this, 0, 100, Store.i(this, "mk_delay", 75), new Ui.OnInt() {
            @Override
            public void on(int v) {
                Store.setI(MainActivity.this, "mk_delay", v);
            }
        }));
        p.body.addView(Ui.header(this, "Maximum Speed"));
        g = addGroup(p);
        Ui.addRow(g, Ui.sliderRow(this, 0, 100, Store.i(this, "mk_speed", 80), new Ui.OnInt() {
            @Override
            public void on(int v) {
                Store.setI(MainActivity.this, "mk_speed", v);
            }
        }));
        p.body.addView(Ui.footer(this, ANDROID_NOTE));
        return p;
    }

    private Ui.Page pageTolerance() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Movement Tolerance", null, popRun, null);
        LinearLayout g = addGroup(p);
        Ui.addRow(g, Ui.sliderRow(this, 0, 100, Store.i(this, "dwell_tol", 40), new Ui.OnInt() {
            @Override
            public void on(int v) {
                Store.setI(MainActivity.this, "dwell_tol", v);
            }
        }));
        p.body.addView(Ui.footer(this, "How far the cursor can move while still counting as being held still."));
        return p;
    }

    private Ui.Page pageHotCorners() {
        Ui.Page p = Ui.page(this, "AssistiveTouch", "Hot Corners", null, popRun, null);
        LinearLayout g = addGroup(p);
        final String[] keys = {"hot_tl", "hot_tr", "hot_bl", "hot_br"};
        final String[] names = {"Top Left", "Top Right", "Bottom Left", "Bottom Right"};
        for (int i = 0; i < keys.length; i++) {
            final String key = keys[i];
            final String name = names[i];
            Ui.addRow(g, Ui.navRow(this, name, Store.actionLabel(this, Store.s(this, key, "none")), new Runnable() {
                @Override
                public void run() {
                    push(new PageBuilder() {
                        @Override
                        public Ui.Page build() {
                            return choice("Hot Corners", name, key, "none", Store.ACTION_IDS, Store.ACTION_LABELS, null);
                        }
                    });
                }
            }));
        }
        p.body.addView(Ui.footer(this, "Choose an action for each screen corner when a pointer rests there."));
        return p;
    }

    // ------------------------------------------------------------------ dwell seconds ("0.25 Second  - | +")

    private View dwellRow() {
        LinearLayout r = Ui.plainRow(this);
        final EditText et = new EditText(this);
        et.setText(Store.s(this, "dwell_sec", "0.25"));
        et.setTextColor(Ui.TEXT);
        et.setTextSize(17);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        et.setBackground(Ui.round(0xFF2C2C2E, dp(6)));
        et.setPadding(dp(10), dp(6), dp(10), dp(6));
        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) saveDwell(et, 0f);
            }
        });
        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent ev) {
                saveDwell(et, 0f);
                et.clearFocus();
                return false;
            }
        });
        r.addView(et, new LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView unit = Ui.tv(this, "Second", 17, Ui.TEXT);
        unit.setPadding(dp(16), 0, 0, 0);
        r.addView(unit, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setBackground(Ui.round(0xFF3A3A3C, dp(8)));
        TextView minus = Ui.tv(this, "−", 22, Ui.TEXT);
        minus.setGravity(Gravity.CENTER);
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDwell(et, -0.05f);
            }
        });
        TextView plus = Ui.tv(this, "+", 22, Ui.TEXT);
        plus.setGravity(Gravity.CENTER);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDwell(et, 0.05f);
            }
        });
        seg.addView(minus, new LinearLayout.LayoutParams(dp(44), dp(32)));
        View sep = new View(this);
        sep.setBackgroundColor(0xFF636366);
        seg.addView(sep, new LinearLayout.LayoutParams(1, dp(20)));
        seg.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(32)));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.gravity = Gravity.CENTER_VERTICAL;
        r.addView(seg, slp);
        return r;
    }

    private void saveDwell(EditText et, float delta) {
        float v = 0.25f;
        try {
            v = Float.parseFloat(et.getText().toString().trim());
        } catch (Exception ignored) {
        }
        v = Math.max(0.05f, Math.min(10f, v + delta));
        String s = String.format(Locale.US, "%.2f", v);
        et.setText(s);
        Store.setS(this, "dwell_sec", s);
    }
}
