# Gesture Macro (Android)

An Android copy of the iPhone AssistiveTouch "custom gesture" setup shown in your recordings
(floating button, double-tap menu, recorded gestures, red touch circles) **plus Live Gesture Assist**:
a fixed red trigger you put your own finger on and drag. The app reads your movement live and,
when you drag roughly the way a saved gesture goes, helps your finger follow it.

> **Nothing is ever played automatically.** No saved path is replayed, nothing taps or drags on a timer,
> and nothing is sent to the game unless your own finger is on the red trigger.

Everything is plain Android (no third-party libraries): the settings screens (`MainActivity`,
`RecorderActivity`) and an Accessibility Service (`GestureService`) that draws the button, the red trigger
and the red circles over other apps.

> **Honest status.** The logic and the app wiring were tested on a computer (see section 8), but this has
> **never been run on a real phone**, and Android's own touch system is the one thing a computer test cannot
> reproduce. Live Assist is experimental: read section 6 and do the 2-minute test in section 5 first.

## 1. Get the APK (pick one)

**A. GitHub builds it for you (no software to install, works from the phone browser)**
1. Create a free GitHub account and a new repository.
2. Upload the project. Either upload everything in this folder **including the hidden `.github` folder**, or
   upload `gesture.zip` as it is and then add the file `.github/workflows/build.yml`
   (*Add file > Create new file*, type `.github/workflows/build.yml` as the name, paste the contents of the `build.yml` that came with this project).
3. Open the *Actions* tab. The build starts by itself (or run *Build APK*). It takes about 3-5 minutes.
4. Open the repository's **Releases** page and download `app-debug.apk`. (It is also kept under the finished run as `GestureMacro-apk`.)

**B. Android Studio (if you have a PC):** *Open* this folder, wait for the Gradle sync, *Build > Build APK(s)*.
The file is `app/build/outputs/apk/debug/app-debug.apk`.

**C. On the phone itself:** an app such as AndroidIDE can open this folder and build it.

## 2. Install and switch it on (once)

1. Open the APK on your phone and install it (allow "install unknown apps" if asked).
2. Open **Gesture Macro**. The orange banner says it is not switched on. Tap it.
3. Tap *Open Accessibility Settings*, find **Gesture Macro**, switch it **ON**, tap *Allow*.
4. If the switch is greyed out ("Restricted setting"): *Open App Info* > three dots (top right) >
   **Allow restricted settings**, then repeat step 3 (Android 13+ does this for apps installed outside the Play Store).

You now see the white AssistiveTouch button on the right edge and the **red trigger** (a red ring) lower right.

## 3. How Live Gesture Assist works

Settings: **Touch > AssistiveTouch > Live Gesture Assist**.

| Setting | What it does |
|---|---|
| **Red Trigger** | Shows or hides the red ring. |
| **Live Assist** | On: your finger on the ring is relayed to the game with assistance. Off: the ring is only a marker and every touch passes through. |
| **Assist Gesture** | Which saved gesture to follow (or None). Choosing a gesture in the AssistiveTouch menu (Custom page) or from a Custom Action also selects it. **It is only selected, never played.** |
| **Assist Strength** | 0 = your finger exactly as it is. Higher = smoother, less sideways wobble when you drag roughly the saved gesture's direction. |
| **Position Red Trigger...** | The only way to move the ring. A layer opens over the screen: drag the ring, tap Save. Portrait and landscape have separate places. |
| **Show Red Touch Circles** | Draws red circles over the game while you drag on the ring: one at your real finger and, when different, one at the assisted touch. They are separate from the trigger and never block touches. |
| **Live Assist Diagnostics** | Counters that show whether it works on your phone (section 5). |

What the app does with your drag, step by step:
1. Your finger goes down on the red trigger. The app now owns that touch (that is how Android works, section 6).
2. It reads your finger live: direction, distance, speed, duration.
3. If you drag within 60 degrees of the Assist Gesture's direction (its first point to its last point), the sideways wobble is reduced and the path is smoothed. Any other direction is passed through untouched.
4. The app re-sends that one finger to the game as a continuous touch, one short piece at a time. The trigger itself turns pass-through meanwhile so the touch lands on the game, not on the ring.
5. You lift: the final point is sent and the touch ends.

The red trigger never moves by itself: its position is written in exactly one place in the code, from the saved setting.
The white AssistiveTouch button is separate: it still drags, snaps to the edge and opens the menu. Single-tap, double-tap and long-press keep their configured actions.

Safety: if Android cancels your finger or refuses the assisted touch twice in a row, Live Assist pauses itself and the
red ring turns pass-through (you get a message). Switch **Live Assist** off and on to try again.

## 4. The steps from your recordings, one by one

| In the iPhone recordings | In this app |
|---|---|
| Settings > Accessibility > Touch > AssistiveTouch | Open the app: **Touch** page, tap **AssistiveTouch** |
| AssistiveTouch switch, Customize Top Level Menu | Same page: switch + **Customize Top Level Menu** |
| Custom Actions: Single-Tap *None*, Double-Tap *Open Menu*, Long Press *None* | Same rows, same defaults. Each can also select a saved gesture as the Assist Gesture |
| Custom Gestures > Create New Gesture | **Create New Gesture...** opens the black recording canvas |
| Tap or swipe, rotate the phone, timeline, Stop, Play, Save | Same: Cancel / New Gesture / Save on top, timeline + Play / Stop at the bottom (up to 60 s, any number of fingers). Play here is only the preview on the recording canvas |
| Name dialog, Edit (red minus, Delete, drag handles, Done) | Same |
| Idle Opacity 37% | **Idle Opacity** slider (15-100%) |
| Pointer Devices ... Dwell Control, Touch page ... Call Audio Routing | All present, same order and wording |
| Double-tap the button > menu: Custom, Notification Center, Device, Gestures, Home, Control Center | Same 3x2 menu. Custom page: Pinch and Rotate, Long Press, Double Tap, Hold and Drag, your gestures, dashed "+" slots, Back in the centre |
| Red circles over the game | **Show Red Touch Circles**: circles over the game while you drag on the red trigger |
| Red trigger button | The fixed red ring (**Red Trigger**) |

## 5. 2-minute test on your phone (please do this and tell me the result)

1. Open **Live Assist Diagnostics** and tap *Reset counters*.
2. Record a short upward swipe (Create New Gesture), save it as "Up". In *Assist Gesture* choose "Up", Assist Strength 100.
3. Open any app that scrolls (a browser page, not the game first). Put your finger on the red ring, drag **up** with a wobbly line, lift.
4. Check, then report back:
   - Did the page scroll while you dragged? (Yes = the relay reaches the other app.)
   - Did the red ring stay exactly where it was?
   - Did red circles follow your finger?
   - Open Diagnostics: *Touches on the trigger*, *Assisted touches finished*, *Real finger cancelled*, *Assisted touch cancelled/refused* - send me those 6 numbers.
5. Do the same in your game (portrait or landscape the same way as the recording).
6. In a second, normal test confirm the white button still works: single-tap, double-tap menu, long-press.

Reading the numbers: *finished* growing with *touches* = the relay works on your phone. *Real finger cancelled* growing every time =
Android drops your own touch when the app injects the assisted one; Live Assist then pauses itself. That is the limit in section 6, not a bug I can code around.

## 6. What Android does and does not allow (why this is a relay)

* A window that receives a touch **owns** it; the app underneath does not get it. There is no Android API that lets an
  ordinary app watch another app's touches *and* change them on their way (the accessibility `TouchInteractionController`, API 33+,
  needs touch-exploration mode and stops delivering events after it hands the touch back).
* An accessibility service can only add a touch of its own with `dispatchGesture`, and the platform documents that a dispatched
  gesture cancels any gesture already in progress, including the user's. So "watch the real finger in the game and nudge it at the same time" cannot be done from inside an app.
* The closest valid design, which this app uses: the red trigger owns your finger, and the app re-injects it into the game as one continuous stroke (`StrokeDescription` with `willContinue`, API 26+), corrected by the assist. The trigger turns pass-through during the touch so the injected touch reaches the game.
* What this costs: it is experimental and may fail on some phones or games; it uses one finger at a time (a simultaneous second finger, like a joystick, is not relayed and can conflict); it needs Android 8.0+; the game may ignore injected touches or treat them as a macro.
* **If the relay does not work on your phone**, the only real alternative is a different architecture that reads the real touch device and injects at the input layer: Shizuku or `adb`/root (`/dev/input` plus `input`/uinput). That needs a one-time setup from a computer or Shizuku app, and is not implemented here.
* Online games such as Free Fire may forbid macros or assists in their terms of service. Use at your own risk.

## 7. What really works, and what is only a copy of the iPhone screen

Works (compiled and logic-tested; phone behaviour still to be confirmed): floating button (drag, edge snap, idle fade), menu, Single/Double/Long-press actions, recording,
saving, renaming, reordering, deleting, preview on the recording canvas, Pinch and Rotate, Long Press, Double Tap,
Hold and Drag (each runs once when you pick it from the menu, as on the iPhone), Notification Center, Control Center, Home, back, recents, lock screen,
screenshot, volume, power menu, Sound on Click, Vibration, Idle Opacity, Customize Top Level Menu, red trigger, Live Assist, red circles, Position Red Trigger, diagnostics.

Saved but with no effect (Android does not let an app do these): Mouse Keys, Dwell Control and its
sub-settings, Use Game Controller, Show Onscreen Keyboard, Perform Touch Gestures, Always Show Menu,
Tracking Sensitivity, Reachability, Tap to Wake, Shake to Undo, Prevent Lock to End Call,
Call Audio Routing, Haptic Touch, Touch Accommodations.

## 8. How it was tested (and what that does not prove)

Run on a computer with plain Java (no Android SDK needed):

* `tests/com/gesturemacro/app/LiveLogicTests.java` - the pure logic: finger tracking, the assist, the one-piece-at-a-time relay, "nothing is sent without a finger", the pause safeguard, circle points, trigger placement, and a randomized stress run.
* `tests/sim/...` - the real `GestureService` driven by a simulated phone (fake window manager, fake gesture dispatch, virtual clock): trigger fixed at every step, nothing dispatched when idle, assist only on real movement, the AssistiveTouch button/menu actions, saved gestures select-only, circles, placement and rotation, shutdown, and 16,000 random events.

Not proven by any of this: how a real Android phone's touch system and your game react to injected touches.
That is exactly what the test in section 5 measures.

## 9. Known limits

* A gesture can hold at most 10 fingers and 60 seconds (Android limits) when you use the built-in Pinch/Hold-and-Drag actions.
* Some games ignore touches injected by accessibility services. If one does, nothing can be done from inside an app.
