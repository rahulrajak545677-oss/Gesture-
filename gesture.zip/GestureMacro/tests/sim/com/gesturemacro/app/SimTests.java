package com.gesturemacro.app;

import android.accessibilityservice.AccessibilityService;
import android.content.SimEnv;
import android.graphics.Canvas;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Runs the REAL GestureService / LiveSession / StrokeRelay / views against a simulated Android
 * (fake WindowManager, fake gesture dispatch, virtual clock). It checks the wiring of the app.
 * It cannot tell how a real phone's touch system reacts to injected touches.
 */
public class SimTests {
    static int checks, fails;
    static final int W = 1080, H = 2400;
    static GestureService svc;
    static int dispatchWithoutFinger, landedOnTrigger;

    static void ok(boolean c, String m) {
        checks++;
        if (!c) {
            fails++;
            System.out.println("  FAIL: " + m);
        }
    }

    static void section(String s) {
        System.out.println("== " + s);
    }

    static Object field(Object o, String n) throws Exception {
        Field f = o.getClass().getDeclaredField(n);
        f.setAccessible(true);
        return f.get(o);
    }

    // ------------------------------------------------------------ environment helpers

    static void boot(int w, int h) throws Exception {
        SimEnv.reset(w, h);
        dispatchWithoutFinger = 0;
        landedOnTrigger = 0;
        svc = new GestureService();
        svc.onServiceConnected();
        Handler.advance(3000);
        SimEnv.onDispatch = g -> {
            try {
                LiveSession s = (LiveSession) field(svc, "session");
                boolean finger = s != null && (s.isDown() || s.isRelaying());
                if (!finger) dispatchWithoutFinger++;
                float[] st = g.strokes.get(0).startPt();
                View hit = SimEnv.wm.hit(st[0], st[1]);
                if (hit instanceof RedTriggerView && g.strokes.get(0).prev == null) landedOnTrigger++;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        };
    }

    static RedTriggerView trig() {
        return SimEnv.wm.find(RedTriggerView.class);
    }

    static int[] ap(View v) {
        return SimEnv.wm.applied.get(v);
    }

    static boolean touchable(View v) {
        return (ap(v)[2] & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0;
    }

    static boolean fixedAt(int[] p0) throws Exception {
        RedTriggerView t = trig();
        if (t == null) return false;
        WindowManager.LayoutParams lp = (WindowManager.LayoutParams) field(svc, "trigLp");
        int[] a = ap(t);
        return a[0] == p0[0] && a[1] == p0[1] && lp.x == p0[0] && lp.y == p0[1];
    }

    static Macro macro(String id, String name, int sw, int sh, float[][] pts) {
        Macro m = new Macro();
        m.id = id;
        m.name = name;
        m.screenW = sw;
        m.screenH = sh;
        m.durationMs = 400;
        Macro.Stroke s = new Macro.Stroke();
        for (float[] p : pts) s.pts.add(p);
        s.startMs = 0;
        s.endMs = 400;
        m.strokes.add(s);
        return m;
    }

    static Macro upMacro() {
        return macro("m1", "Up", W, H, new float[][]{{500, 1800, 0}, {500, 1300, 200}, {500, 800, 400}});
    }

    static void pref(String k, boolean v) {
        Store.setB(svc, k, v);
        Handler.advance(5);
    }

    // ------------------------------------------------------------ finger on the trigger

    static boolean fingerDown;

    static void settle() {
        Handler.advance(1);
        AccessibilityService.finishInFlight(true);
        Handler.advance(1);
    }

    static void flush() {
        int g = 0;
        while (SimEnv.inFlight != null && g++ < 20) settle();
    }

    static void sendEvent(int action, float x, float y) {
        RedTriggerView tv = trig();
        int[] a = ap(tv);
        tv.simTouch(new MotionEvent(action, x - a[0], y - a[1], a[0], a[1], Handler.now));
    }

    /** returns false when the touch would not have reached the trigger (the game gets it instead) */
    static boolean down(float x, float y) {
        View hit = SimEnv.wm.hit(x, y);
        if (!(hit instanceof RedTriggerView)) return false;
        sendEvent(MotionEvent.ACTION_DOWN, x, y);
        fingerDown = true;
        Handler.advance(40);
        settle();
        return true;
    }

    static void move(float x, float y, int dt) {
        Handler.advance(dt);
        sendEvent(MotionEvent.ACTION_MOVE, x, y);
        settle();
    }

    static void up(float x, float y, int dt) {
        Handler.advance(dt);
        sendEvent(MotionEvent.ACTION_UP, x, y);
        fingerDown = false;
        flush();
    }

    static float[] center() {
        int[] a = ap(trig());
        return new float[]{a[0] + a[3] / 2f, a[1] + a[4] / 2f};
    }

    static float[] endOf(int i) {
        android.accessibilityservice.GestureDescription g = (android.accessibilityservice.GestureDescription) SimEnv.dispatched.get(i)[0];
        return g.strokes.get(0).endPt();
    }

    static void cleanChecks(String where) {
        ok(SimEnv.overlaps == 0, where + ": never two gestures in flight (" + SimEnv.overlaps + ")");
        ok(SimEnv.badChain == 0, where + ": every continued stroke starts where the last ended (" + SimEnv.badChain + ")");
        ok(SimEnv.orphans == 0, where + ": no orphaned strokes (" + SimEnv.orphans + ")");
        ok(SimEnv.negative == 0, where + ": no invalid coordinates/times sent (" + SimEnv.negative + ")");
        ok(dispatchWithoutFinger == 0, where + ": nothing dispatched without a finger (" + dispatchWithoutFinger + ")");
        ok(landedOnTrigger == 0, where + ": injected finger never lands on the trigger window (" + landedOnTrigger + ")");
    }

    // ------------------------------------------------------------ tests

    static void testFixedTrigger() throws Exception {
        section("1. red trigger is fixed and stationary");
        boot(W, H);
        RedTriggerView tv = trig();
        ok(tv != null, "trigger exists after the service connects");
        int[] p0 = ap(tv).clone();
        int[] exp = TriggerPlacement.toPx(0.80f, 0.70f, W, H, 216);
        ok(p0[0] == exp[0] && p0[1] == exp[1], "default portrait position " + p0[0] + "," + p0[1]);
        ok(p0[3] == 216 && p0[4] == 216, "72dp size");
        ok(touchable(tv), "trigger is touchable while Live Assist is on");
        float[] c = center();
        ok(down(c[0], c[1]), "finger starting on the trigger reaches it");
        ok(fixedAt(p0), "fixed right after touch-down");
        ok(!touchable(trig()), "trigger turns pass-through while the assisted touch runs");
        float lastX = c[0], lastY = c[1];
        boolean always = true;
        for (int i = 1; i <= 80; i++) {
            lastX = c[0] + i * 3;
            lastY = c[1] - i * 12;
            move(lastX, lastY, 8);
            always &= fixedAt(p0);
        }
        ok(always, "trigger x/y identical at every one of 80 drag steps, 240px right and 960px up");
        up(lastX, lastY, 8);
        ok(fixedAt(p0), "fixed after lifting");
        ok(touchable(trig()), "trigger touchable again after the touch");
        Handler.advance(2000);
        ok(fixedAt(p0), "fixed 2 s later (fade-outs, timers)");
        ok(SimEnv.dispatched.size() > 5, "relay forwarded the drag (" + SimEnv.dispatched.size() + " pieces)");
        float[] fe = endOf(SimEnv.dispatched.size() - 1);
        ok(Math.abs(fe[0] - lastX) < 1.5f && Math.abs(fe[1] - lastY) < 1.5f, "last piece ends exactly where the finger lifted");
        float[] fs = endOf(0);
        ok(Math.abs(fs[0] - c[0]) < 1.5f && Math.abs(fs[1] - c[1]) < 1.5f, "first piece starts where the finger went down");
        cleanChecks("test1");
        ok(Store.f(svc, "trig_p_fx", -1f) == -1f && Store.f(svc, "trig_p_fy", -1f) == -1f, "dragging never writes a trigger position to settings");
    }

    static void testNoAutomaticMotion() throws Exception {
        section("2. nothing happens without a finger");
        boot(W, H);
        Store.addMacro(svc, upMacro());
        Store.setS(svc, "assist_gesture", "m1");
        Store.setI(svc, "assist_strength", 100);
        Handler.advance(10);
        int logSize = SimEnv.wm.log.size();
        for (int i = 0; i < 600; i++) Handler.advance(100);
        ok(SimEnv.dispatched.isEmpty(), "60 s idle with an Assist Gesture selected: 0 dispatches");
        ok(SimEnv.wm.log.size() == logSize, "no window changes while idle");
        float[] c = center();
        down(c[0], c[1]);
        int n = SimEnv.dispatched.size();
        ok(n == 1, "finger down: just the touch-down piece (" + n + ")");
        for (int i = 0; i < 50; i++) Handler.advance(100);
        ok(SimEnv.dispatched.size() == n, "finger held still for 5 s: nothing more is sent");
        up(c[0], c[1], 10);
        int n2 = SimEnv.dispatched.size();
        for (int i = 0; i < 100; i++) Handler.advance(100);
        ok(SimEnv.dispatched.size() == n2, "after lift: nothing more is sent");
        cleanChecks("test2");
    }

    static double dev(List<float[]> pts, float cx) {
        double m = 0;
        for (int i = pts.size() / 2; i < pts.size(); i++) m = Math.max(m, Math.abs(pts.get(i)[0] - cx));
        return m;
    }

    static void runUpDrag(float cx, float cy, List<float[]> finger, List<float[]> sent) {
        down(cx, cy);
        float x = cx, y = cy;
        for (int i = 1; i <= 60; i++) {
            x = cx + (float) (40 * Math.sin(i * 0.9));
            y = cy - i * 10;
            finger.add(new float[]{x, y});
            move(x, y, 10);
        }
        up(x, y, 10);
        for (int i = 0; i < SimEnv.dispatched.size(); i++) sent.add(endOf(i));
    }

    static void testAssist() throws Exception {
        section("3. assist follows the real finger, only when it moves the saved way");
        boot(W, H);
        Store.addMacro(svc, upMacro());
        Store.setS(svc, "assist_gesture", "m1");
        Store.setI(svc, "assist_strength", 100);
        Handler.advance(10);
        float[] c = center();
        List<float[]> finger = new ArrayList<>(), sent = new ArrayList<>();
        runUpDrag(c[0], c[1], finger, sent);
        double df = dev(finger, c[0]), ds = dev(sent, c[0]);
        ok(df > 30, "finger wobbles sideways by about " + Math.round(df) + " px");
        ok(ds < df * 0.75, "assisted path wobbles less (" + Math.round(ds) + " px vs " + Math.round(df) + " px)");
        float[] fe = sent.get(sent.size() - 1), ff = finger.get(finger.size() - 1);
        ok(Math.abs(fe[1] - ff[1]) < 1.5f, "the final point is where the finger really lifted along the drag direction");
        ok(Math.abs(fe[0] - c[0]) < 1.5f, "at full strength the final point is on the saved gesture's line");
        ok(sent.size() > 5 && sent.get(sent.size() - 1)[1] < c[1] - 500, "the path really moves up with the finger");
        cleanChecks("test3a");

        boot(W, H);
        Store.addMacro(svc, upMacro());
        Store.setS(svc, "assist_gesture", "m1");
        Store.setI(svc, "assist_strength", 100);
        Handler.advance(10);
        c = center();
        down(c[0], c[1]);
        List<float[]> fing2 = new ArrayList<>();
        float x = c[0];
        for (int i = 1; i <= 50; i++) {
            x = c[0] + i * 5;
            float y = c[1] + (float) (8 * Math.sin(i * 0.7));
            fing2.add(new float[]{x, y});
            move(x, y, 10);
        }
        up(x, fing2.get(fing2.size() - 1)[1], 10);
        double worst = 0;
        for (int i = 1; i < SimEnv.dispatched.size(); i++) {
            float[] e = endOf(i);
            double best = 1e9;
            for (float[] f : fing2) best = Math.min(best, Math.hypot(e[0] - f[0], e[1] - f[1]));
            worst = Math.max(worst, best);
        }
        ok(worst < 1.5, "dragging a different way than the saved gesture: untouched (max " + String.format("%.2f", worst) + " px from your finger)");
        cleanChecks("test3b");

        boot(W, H);
        Store.addMacro(svc, upMacro());
        Store.setS(svc, "assist_gesture", "m1");
        Store.setI(svc, "assist_strength", 0);
        Handler.advance(10);
        c = center();
        finger.clear();
        sent.clear();
        runUpDrag(c[0], c[1], finger, sent);
        double d0 = dev(sent, c[0]);
        ok(Math.abs(d0 - df) < 3, "strength 0 leaves the path as the finger made it (" + Math.round(d0) + " vs " + Math.round(df) + " px)");

        boot(W, H);
        Store.addMacro(svc, macro("m2", "Land", H, W, new float[][]{{500, 300, 0}, {900, 300, 400}}));
        Store.setS(svc, "assist_gesture", "m2");
        Store.setI(svc, "assist_strength", 100);
        Handler.advance(10);
        c = center();
        finger.clear();
        sent.clear();
        runUpDrag(c[0], c[1], finger, sent);
        ok(Math.abs(dev(sent, c[0]) - df) < 3, "gesture recorded in landscape is off while the phone is in portrait");
    }

    static void tapButton() {
        AtButtonView b = SimEnv.wm.find(AtButtonView.class);
        int[] a = ap(b);
        float x = a[0] + a[3] / 2f, y = a[1] + a[4] / 2f;
        b.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, a[3] / 2f, a[4] / 2f, a[0], a[1], Handler.now));
        Handler.advance(50);
        b.simTouch(new MotionEvent(MotionEvent.ACTION_UP, a[3] / 2f, a[4] / 2f, a[0], a[1], Handler.now));
    }

    static View clickableWithText(View v, String text, View clickable) {
        View cur = v.clickL != null ? v : clickable;
        if (v instanceof TextView && text.equals(((TextView) v).txt)) return cur;
        if (v instanceof ViewGroup) {
            for (View k : ((ViewGroup) v).kids) {
                View r = clickableWithText(k, text, cur);
                if (r != null) return r;
            }
        }
        return null;
    }

    static boolean toastHas(String s) {
        for (String t : SimEnv.toasts) if (t != null && t.contains(s)) return true;
        return false;
    }

    static void testAssistiveTouch() throws Exception {
        section("4. AssistiveTouch button and menu keep working; saved gestures are select-only");
        // single tap -> system action
        boot(W, H);
        Store.setS(svc, "single_tap", "home");
        Handler.advance(5);
        tapButton();
        Handler.advance(400);
        ok(SimEnv.globals.contains(AccessibilityService.GLOBAL_ACTION_HOME), "single tap runs its configured action (Home)");
        // long press
        boot(W, H);
        Store.setS(svc, "long_press", "back");
        Handler.advance(5);
        AtButtonView b = SimEnv.wm.find(AtButtonView.class);
        int[] a = ap(b);
        b.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, 20, 20, a[0], a[1], Handler.now));
        Handler.advance(700);
        b.simTouch(new MotionEvent(MotionEvent.ACTION_UP, 20, 20, a[0], a[1], Handler.now));
        Handler.advance(400);
        ok(SimEnv.globals.contains(AccessibilityService.GLOBAL_ACTION_BACK), "long press runs its configured action (Back)");
        ok(SimEnv.globals.size() == 1, "long press does not also tap");
        // a saved gesture bound to a tap action does not play
        boot(W, H);
        Store.addMacro(svc, upMacro());
        Store.setS(svc, "double_tap", "none");
        Store.setS(svc, "single_tap", "macro:m1");
        Handler.advance(5);
        tapButton();
        Handler.advance(500);
        ok(SimEnv.dispatched.isEmpty(), "tap action bound to a saved gesture dispatches nothing");
        ok("m1".equals(Store.s(svc, "assist_gesture", "")), "it only selects the gesture as the Assist Gesture");
        ok(toastHas("Assist gesture: Up"), "and tells you so");
        // long press bound to a saved gesture
        boot(W, H);
        Store.addMacro(svc, upMacro());
        Store.setS(svc, "long_press", "macro:m1");
        Handler.advance(5);
        b = SimEnv.wm.find(AtButtonView.class);
        a = ap(b);
        b.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, 20, 20, a[0], a[1], Handler.now));
        Handler.advance(700);
        b.simTouch(new MotionEvent(MotionEvent.ACTION_UP, 20, 20, a[0], a[1], Handler.now));
        Handler.advance(500);
        ok(SimEnv.dispatched.isEmpty() && "m1".equals(Store.s(svc, "assist_gesture", "")), "long press bound to a saved gesture: select only");
        // double tap -> menu -> Custom -> saved gesture
        boot(W, H);
        Store.addMacro(svc, upMacro());
        Handler.advance(5);
        tapButton();
        Handler.advance(100);
        tapButton();
        Handler.advance(50);
        FrameLayout menu = SimEnv.wm.find(FrameLayout.class);
        ok(menu != null, "double tap opens the AssistiveTouch menu");
        View custom = menu == null ? null : clickableWithText(menu, "Custom", null);
        ok(custom != null, "menu shows Custom");
        if (custom != null) {
            custom.simClick();
            Handler.advance(300);
            View up = clickableWithText(SimEnv.wm.find(FrameLayout.class), "Up", null);
            ok(up != null, "Custom page lists the saved gesture");
            if (up != null) up.simClick();
            Handler.advance(500);
            ok(SimEnv.dispatched.isEmpty(), "choosing a saved gesture in the menu dispatches nothing");
            ok("m1".equals(Store.s(svc, "assist_gesture", "")), "it becomes the Assist Gesture");
            ok(SimEnv.wm.find(FrameLayout.class) == null, "menu closes");
        }
        // AT button can be dragged; the trigger cannot follow it
        boot(W, H);
        RedTriggerView tv = trig();
        int[] t0 = ap(tv).clone();
        b = SimEnv.wm.find(AtButtonView.class);
        a = ap(b);
        int bx0 = a[0], by0 = a[1];
        b.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, 20, 20, a[0], a[1], Handler.now));
        for (int i = 1; i <= 20; i++) {
            Handler.advance(10);
            b.simTouch(new MotionEvent(MotionEvent.ACTION_MOVE, 20 - i * 10, 20 + i * 20, a[0], a[1], Handler.now));
        }
        b.simTouch(new MotionEvent(MotionEvent.ACTION_UP, -180, 420, a[0], a[1], Handler.now));
        Handler.advance(400);
        int[] a2 = ap(b);
        ok(a2[0] != bx0 || a2[1] != by0, "the white AT button still drags and snaps");
        ok(fixedAt(t0), "while it moves the red trigger stays put");
        ok(SimEnv.dispatched.isEmpty(), "dragging the AT button dispatches nothing");
        cleanChecks("test4");
    }

    static float[] activeOf(TouchIndicatorView v) throws Exception {
        Field f = TouchIndicatorView.class.getDeclaredField("active");
        f.setAccessible(true);
        return (float[]) f.get(v);
    }

    static void testCircles() throws Exception {
        section("5. red touch circles");
        boot(W, H);
        Store.addMacro(svc, upMacro());
        Store.setS(svc, "assist_gesture", "m1");
        Store.setI(svc, "assist_strength", 100);
        Handler.advance(10);
        ok(SimEnv.wm.count(TouchIndicatorView.class) == 0, "no circles layer before a touch");
        int[] p0 = ap(trig()).clone();
        float[] c = center();
        down(c[0], c[1]);
        TouchIndicatorView tiv = SimEnv.wm.find(TouchIndicatorView.class);
        ok(tiv != null, "circles layer appears on touch");
        ok(tiv != null && !touchable(tiv), "circles layer is not touchable (never blocks the game)");
        ok(tiv != null && ap(tiv)[3] == W && ap(tiv)[4] == H, "circles layer covers the whole screen");
        boolean follows = true, movedAway = false, both = false;
        for (int i = 1; i <= 60; i++) {
            float x = c[0] + (float) (40 * Math.sin(i * 0.9));
            float y = c[1] - i * 10;
            move(x, y, 10);
            float[] act = activeOf(tiv);
            follows &= act.length >= 2 && Math.hypot(act[0] - x, act[1] - y) < 0.5;
            if (act.length == 4) both = true;
            if (Math.hypot(x - (p0[0] + 108), y - (p0[1] + 108)) > 400) movedAway = true;
        }
        ok(follows, "first red circle is exactly on the real finger at every step");
        ok(both, "a second circle shows the assisted point when it differs from the finger");
        ok(movedAway && fixedAt(p0), "circles travel across the screen while the trigger stays fixed");
        up(c[0], c[1] - 600, 10);
        Handler.advance(100);
        ok(SimEnv.wm.count(TouchIndicatorView.class) == 1, "circles fade out after lift (still visible briefly)");
        Handler.advance(800);
        ok(SimEnv.wm.count(TouchIndicatorView.class) == 0, "circles layer removed after the fade");

        boot(W, H);
        pref("show_touches", false);
        c = center();
        down(c[0], c[1]);
        for (int i = 1; i <= 20; i++) move(c[0] + i * 5, c[1] - i * 5, 10);
        ok(SimEnv.wm.count(TouchIndicatorView.class) == 0, "Show Red Touch Circles OFF: nothing is drawn");
        ok(SimEnv.dispatched.size() > 5, "and the touch is still relayed");
        up(c[0] + 100, c[1] - 100, 10);
        cleanChecks("test5");
    }

    static void testCancelAndPause() throws Exception {
        section("6. when Android refuses or cancels, live assist pauses and lets touches through");
        boot(W, H);
        float[] c = center();
        for (int round = 0; round < 2; round++) {
            ok(down(c[0], c[1]), "round " + round + ": finger reaches the trigger");
            sendEvent(MotionEvent.ACTION_CANCEL, c[0], c[1]);
            fingerDown = false;
            for (int i = 0; i < 6; i++) {
                settle();
                Handler.advance(50);
            }
        }
        ok(Store.b(svc, "assist_paused", false), "two cancelled touches in a row pause live assist");
        ok(toastHas("paused"), "you are told why");
        ok(!touchable(trig()), "the trigger now lets touches through");
        ok(SimEnv.wm.hit(c[0], c[1]) == null, "a finger there goes to the game");
        int n = SimEnv.dispatched.size();
        Handler.advance(3000);
        ok(SimEnv.dispatched.size() == n, "nothing else is sent");
        Store.setB(svc, "assist_paused", false);
        Handler.advance(5);
        ok(touchable(trig()), "switching Live Assist off and on re-arms the trigger");
        // rejected dispatch
        boot(W, H);
        c = center();
        SimEnv.rejectDispatch = true;
        for (int round = 0; round < 2; round++) {
            down(c[0], c[1]);
            move(c[0] + 50, c[1] - 50, 10);
            up(c[0] + 60, c[1] - 60, 10);
            Handler.advance(100);
        }
        ok(Store.b(svc, "assist_paused", false), "two refused touches pause live assist");
        ok(!touchable(trig()), "trigger passes touches through afterwards");
        // one piece refused in the middle of a drag: the held finger must be lifted, never left stuck
        boot(W, H);
        c = center();
        down(c[0], c[1]);
        move(c[0] + 20, c[1] - 20, 10);
        move(c[0] + 40, c[1] - 40, 10);
        SimEnv.rejectCount = 1;
        move(c[0] + 60, c[1] - 60, 10);
        flush();
        ok(SimEnv.open == null, "a refused piece mid-drag does not leave a finger held down on the game");
        up(c[0] + 70, c[1] - 70, 10);
        Handler.advance(500);
        ok(SimEnv.open == null && SimEnv.inFlight == null, "still nothing held after the real finger lifts");
        c = center();
        ok(down(c[0], c[1]), "the next touch starts cleanly");
        up(c[0], c[1], 10);
        ok(SimEnv.orphans == 0 && SimEnv.badChain == 0, "no orphaned or broken strokes after the refusal");
        cleanChecks("test6");
    }

    static void testPlacement() throws Exception {
        section("7. the trigger moves only through Position Red Trigger");
        boot(W, H);
        int[] p0 = ap(trig()).clone();
        svc.beginTriggerPlacement();
        Handler.advance(5);
        TriggerPlacerView pl = SimEnv.wm.find(TriggerPlacerView.class);
        ok(pl != null, "placement layer opens");
        ok(trig().visibility == View.INVISIBLE, "the real trigger hides while you place it");
        pl.onDraw(new Canvas());
        pl.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, 300, 500, 0, 0, Handler.now));
        for (int i = 0; i < 10; i++) pl.simTouch(new MotionEvent(MotionEvent.ACTION_MOVE, 300 + i, 500 + i, 0, 0, Handler.now));
        pl.simTouch(new MotionEvent(MotionEvent.ACTION_UP, 309, 509, 0, 0, Handler.now));
        ok(ap(trig())[0] == p0[0] && ap(trig())[1] == p0[1], "dragging the ring does not move the trigger until Save");
        pl.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, 729, 147, 0, 0, Handler.now));
        Handler.advance(5);
        ok(SimEnv.wm.find(TriggerPlacerView.class) == null, "placement layer closes after Save");
        int[] p1 = ap(trig());
        int[] want = TriggerPlacement.toPx(Store.f(svc, "trig_p_fx", -1), Store.f(svc, "trig_p_fy", -1), W, H, 216);
        ok(p1[0] == want[0] && p1[1] == want[1], "trigger now sits at the saved place " + p1[0] + "," + p1[1]);
        ok(Math.abs(p1[0] + 108 - 309) <= 2 && Math.abs(p1[1] + 108 - 509) <= 2, "and that is where the ring was left");
        ok(trig().visibility == View.VISIBLE, "trigger visible again");
        int[] p2 = p1.clone();
        float[] c = center();
        down(c[0], c[1]);
        for (int i = 1; i <= 30; i++) move(c[0] + i * 8, c[1] + i * 8, 10);
        up(c[0] + 240, c[1] + 240, 10);
        ok(fixedAt(p2), "after saving, it stays there through a drag");
        // cancel path
        svc.beginTriggerPlacement();
        Handler.advance(5);
        pl = SimEnv.wm.find(TriggerPlacerView.class);
        pl.onDraw(new Canvas());
        pl.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, 900, 1900, 0, 0, Handler.now));
        pl.simTouch(new MotionEvent(MotionEvent.ACTION_UP, 900, 1900, 0, 0, Handler.now));
        pl.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, 351, 147, 0, 0, Handler.now));
        Handler.advance(5);
        ok(SimEnv.wm.find(TriggerPlacerView.class) == null && fixedAt(p2), "Cancel leaves the trigger where it was");
        // landscape has its own place; rotating re-applies the saved place per orientation
        SimEnv.dm.widthPixels = H;
        SimEnv.dm.heightPixels = W;
        svc.onConfigurationChanged(null);
        Handler.advance(50);
        int[] l = ap(trig());
        int[] lw = TriggerPlacement.toPx(0.86f, 0.62f, H, W, 216);
        ok(l[0] == lw[0] && l[1] == lw[1], "landscape default place " + l[0] + "," + l[1]);
        SimEnv.dm.widthPixels = W;
        SimEnv.dm.heightPixels = H;
        svc.onConfigurationChanged(null);
        Handler.advance(50);
        ok(fixedAt(p2), "rotating back restores the saved portrait place");
        cleanChecks("test7");
    }

    static void testSettingsAndCleanup() throws Exception {
        section("8. switches and shutdown");
        boot(W, H);
        pref("trig_enabled", false);
        ok(trig() == null, "Red Trigger switch OFF removes it");
        pref("trig_enabled", true);
        ok(trig() != null, "ON brings it back");
        int[] p = TriggerPlacement.toPx(0.80f, 0.70f, W, H, 216);
        ok(fixedAt(p), "at the same saved place");
        pref("live_assist", false);
        ok(!touchable(trig()), "Live Assist OFF: trigger is only a marker and lets touches through");
        pref("live_assist", true);
        ok(touchable(trig()), "Live Assist ON again");
        float[] c = center();
        down(c[0], c[1]);
        svc.onUnbind(null);
        Handler.advance(100);
        flush();
        Handler.advance(5000);
        ok(SimEnv.wm.views.isEmpty(), "service shutdown removes every overlay (" + SimEnv.wm.views.size() + " left)");
        ok(SimEnv.inFlight == null, "no touch is left pressed");
        int n = SimEnv.dispatched.size();
        Handler.advance(10000);
        ok(SimEnv.dispatched.size() == n, "nothing is sent after shutdown");
        cleanChecks("test8");
    }

    static void testFuzz() throws Exception {
        section("9. random fuzz: 40 runs x 400 random events");
        int steps = 0;
        for (int seed = 1; seed <= 40; seed++) {
            boot(W, H);
            Random rnd = new Random(seed);
            Store.addMacro(svc, upMacro());
            Store.setS(svc, "assist_gesture", "m1");
            Store.setI(svc, "assist_strength", rnd.nextInt(101));
            Handler.advance(10);
            boolean land = false;
            int[] expPortrait = TriggerPlacement.toPx(0.80f, 0.70f, W, H, 216);
            float fx = 0, fy = 0;
            int savedCount = 0;
            for (int s = 0; s < 400; s++) {
                steps++;
                int r = rnd.nextInt(100);
                Map<String, Object> before = new HashMap<>(SimEnv.prefs.m);
                boolean saved = false;
                RedTriggerView tv = trig();
                if (r < 22) {
                    if (!fingerDown && tv != null) {
                        float[] cc = center();
                        down(cc[0] + rnd.nextInt(120) - 60, cc[1] + rnd.nextInt(120) - 60);
                        if (SimEnv.wm.hit(cc[0], cc[1]) instanceof RedTriggerView) { }
                        fx = cc[0];
                        fy = cc[1];
                    }
                } else if (r < 62) {
                    if (fingerDown && trig() != null) {
                        fx += rnd.nextInt(61) - 30;
                        fy += rnd.nextInt(61) - 35;
                        int dw = land ? H : W, dh = land ? W : H;
                        fx = Math.max(-50, Math.min(dw + 50, fx));
                        fy = Math.max(-50, Math.min(dh + 50, fy));
                        move(fx, fy, rnd.nextInt(30));
                    }
                } else if (r < 72) {
                    if (fingerDown && trig() != null) up(fx, fy, rnd.nextInt(20));
                } else if (r < 76) {
                    if (fingerDown && trig() != null) {
                        sendEvent(MotionEvent.ACTION_CANCEL, fx, fy);
                        fingerDown = false;
                    }
                } else if (r < 80) {
                    if (fingerDown && trig() != null) sendEvent(MotionEvent.ACTION_POINTER_DOWN | (1 << 8), fx + 50, fy);
                } else if (r < 90) {
                    AccessibilityService.finishInFlight(rnd.nextInt(100) < 75);
                    Handler.advance(rnd.nextInt(5));
                } else if (r < 93) {
                    Handler.advance(rnd.nextInt(400));
                } else if (r < 94) {
                    LiveSession q = (LiveSession) field(svc, "session");
                    if (q != null && !q.isDown() && !q.isRelaying()) SimEnv.rejectDispatch = !SimEnv.rejectDispatch; // permission-type refusals are static between touches
                } else if (r < 95) {
                    fingerDown = false;
                    land = !land;
                    SimEnv.dm.widthPixels = land ? H : W;
                    SimEnv.dm.heightPixels = land ? W : H;
                    svc.onConfigurationChanged(null);
                    Handler.advance(20);
                } else if (r < 96) {
                    Store.setB(svc, "assist_paused", false);
                    pref("live_assist", rnd.nextBoolean());
                } else if (r < 97) {
                    pref("show_touches", rnd.nextBoolean());
                } else if (r < 98) {
                    tapButton();
                    Handler.advance(rnd.nextInt(500));
                } else if (r < 99) {
                    pref("trig_enabled", rnd.nextInt(4) != 0);
                    fingerDown = fingerDown && trig() != null;
                } else {
                    if (!fingerDown) {
                        svc.beginTriggerPlacement();
                        Handler.advance(5);
                        TriggerPlacerView pl = SimEnv.wm.find(TriggerPlacerView.class);
                        if (pl != null) {
                            pl.onDraw(new Canvas());
                            int dw = land ? H : W, dh = land ? W : H;
                            float px = 120 + rnd.nextInt(dw - 240), py = 200 + rnd.nextInt(dh - 400);
                            pl.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, px, py, 0, 0, Handler.now));
                            pl.simTouch(new MotionEvent(MotionEvent.ACTION_UP, px, py, 0, 0, Handler.now));
                            if (rnd.nextBoolean()) {
                                float sw = dw / 2f + 24 + 165;
                                pl.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, sw, 147, 0, 0, Handler.now));
                                saved = true;
                            } else {
                                float cw = dw / 2f - 24 - 165;
                                pl.simTouch(new MotionEvent(MotionEvent.ACTION_DOWN, cw, 147, 0, 0, Handler.now));
                            }
                            Handler.advance(5);
                        }
                    }
                }
                if (String.valueOf(seed).equals(System.getProperty("dbg"))) {
                    System.out.println("step " + s + " r=" + r + " fingerDown=" + fingerDown + " inFlight=" + (SimEnv.inFlight != null) + " dispatched=" + SimEnv.dispatched.size() + " badChain=" + SimEnv.badChain + " orphans=" + SimEnv.orphans + " paused=" + Store.b(svc, "assist_paused", false) + " reject=" + SimEnv.rejectDispatch);
                    if (!SimEnv.dispatched.isEmpty()) {
                        Object[] rec = SimEnv.dispatched.get(SimEnv.dispatched.size() - 1);
                        android.accessibilityservice.GestureDescription.StrokeDescription sd = ((android.accessibilityservice.GestureDescription) rec[0]).strokes.get(0);
                        System.out.println("   last piece start=" + (int) sd.startPt()[0] + "," + (int) sd.startPt()[1] + " end=" + (int) sd.endPt()[0] + "," + (int) sd.endPt()[1] + " cont=" + sd.cont + " continuation=" + (sd.prev != null) + " dur=" + sd.dur);
                    }
                }
                // ---- invariants after every step
                Handler.advance(1);
                boolean enabled = Store.b(svc, "trig_enabled", true);
                tv = trig();
                if (enabled != (tv != null)) {
                    ok(false, "seed " + seed + " step " + s + ": trigger presence must follow its switch");
                    break;
                }
                if (tv != null) {
                    int dw = land ? H : W, dh = land ? W : H;
                    float sx = Store.f(svc, TriggerPlacement.keyFx(land), TriggerPlacement.defaultFx(land));
                    float sy = Store.f(svc, TriggerPlacement.keyFy(land), TriggerPlacement.defaultFy(land));
                    int[] want = TriggerPlacement.toPx(sx, sy, dw, dh, 216);
                    int[] a = ap(tv);
                    WindowManager.LayoutParams lp = (WindowManager.LayoutParams) field(svc, "trigLp");
                    if (a[0] != want[0] || a[1] != want[1] || lp.x != want[0] || lp.y != want[1]) {
                        ok(false, "seed " + seed + " step " + s + ": trigger at " + a[0] + "," + a[1] + " but the saved place is " + want[0] + "," + want[1]);
                        break;
                    }
                    boolean shouldTouch = Store.b(svc, "live_assist", true) && !Store.b(svc, "assist_paused", false);
                    LiveSession ls = (LiveSession) field(svc, "session");
                    boolean busy = ls != null && (ls.isDown() || ls.isRelaying());
                    if (!shouldTouch && touchable(tv)) {
                        ok(false, "seed " + seed + " step " + s + ": trigger must pass touches through while assist is off/paused");
                        break;
                    }
                    if (shouldTouch && !busy && !touchable(tv)) {
                        // may be waiting for the safety timer; give it time
                        Handler.advance(4000);
                        if (!touchable(trig())) {
                            ok(false, "seed " + seed + " step " + s + ": trigger stuck untouchable with no touch running");
                            break;
                        }
                    }
                }
                // settings for the trigger place only change when a Save happened
                boolean placeChanged = false;
                for (String k : new String[]{"trig_p_fx", "trig_p_fy", "trig_l_fx", "trig_l_fy"}) {
                    Object o = before.get(k), n = SimEnv.prefs.m.get(k);
                    if (o == null ? n != null : !o.equals(n)) placeChanged = true;
                }
                if (placeChanged && !saved) {
                    ok(false, "seed " + seed + " step " + s + ": trigger place changed without Save");
                    break;
                }
                if (SimEnv.wm.count(RedTriggerView.class) > 1 || SimEnv.wm.count(TouchIndicatorView.class) > 1
                        || SimEnv.wm.count(TriggerPlacerView.class) > 1 || SimEnv.wm.count(AtButtonView.class) > 1) {
                    ok(false, "seed " + seed + " step " + s + ": duplicate overlay windows");
                    break;
                }
                if (SimEnv.overlaps != 0 || SimEnv.badChain != 0 || SimEnv.orphans != 0 || SimEnv.negative != 0
                        || dispatchWithoutFinger != 0 || landedOnTrigger != 0) {
                    ok(false, "seed " + seed + " step " + s + ": overlaps=" + SimEnv.overlaps + " badChain=" + SimEnv.badChain
                            + " orphans=" + SimEnv.orphans + " badArgs=" + SimEnv.negative + " noFinger=" + dispatchWithoutFinger
                            + " onTrigger=" + landedOnTrigger);
                    break;
                }
            }
            ok(SimEnv.overlaps == 0 && SimEnv.badChain == 0 && SimEnv.orphans == 0 && SimEnv.negative == 0
                    && dispatchWithoutFinger == 0 && landedOnTrigger == 0, "seed " + seed + " clean");
            svc.onUnbind(null);
            Handler.advance(5000);
            ok(SimEnv.wm.views.isEmpty(), "seed " + seed + ": shutdown leaves no overlay");
        }
        System.out.println("   (" + steps + " random events)");
    }

    public static void main(String[] args) throws Exception {
        testFixedTrigger();
        testNoAutomaticMotion();
        testAssist();
        testAssistiveTouch();
        testCircles();
        testCancelAndPause();
        testPlacement();
        testSettingsAndCleanup();
        testFuzz();
        System.out.println();
        if (fails == 0) System.out.println("ALL PASSED (" + checks + " checks)");
        else {
            System.out.println(fails + " FAILED of " + checks + " checks");
            System.exit(1);
        }
    }
}
