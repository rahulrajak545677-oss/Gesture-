import re, os, sys
# usage: stubgen2.py OUTDIR spec1 [spec2 ...]   (later specs override classes of earlier ones)
out = sys.argv[1]
classes = {}
for sp in sys.argv[2:]:
    for b in re.split(r'(?m)^== ', open(sp).read())[1:]:
        head, _, body = b.partition('\n')
        classes[head.strip()] = body
member = re.compile(r'((?:\b(?:public|protected|static|final|abstract|synchronized)\b\s+)*)([\w<>\[\].,? ]*?)\b(\w+)\s*\(([^()]*)\)(\s+throws\s+[\w, ]+)?;')
def default_ret(t):
    t = re.sub(r'\b(public|protected|static|final|abstract|synchronized)\b', '', t).strip()
    if t in ('', 'void'): return ''
    if t == 'boolean': return 'return false;'
    if t in ('int','long','float','double','short','byte','char'): return 'return 0;'
    return 'return null;'
def fix(body, is_iface):
    if is_iface: return body
    res = []
    for ln in body.split('\n'):
        if ('abstract' in ln and re.search(r'abstract\s+[\w<>\[\].,? ]+\s+\w+\(', ln)) or 'interface ' in ln:
            res.append(ln); continue
        if '=' in ln and '(' not in ln:
            res.append(ln); continue
        def sub(m):
            return '%s%s %s(%s)%s { %s }' % (m.group(1), m.group(2), m.group(3), m.group(4), m.group(5) or '', default_ret(m.group(2)))
        res.append(member.sub(sub, ln))
    return '\n'.join(res)
pkgs = set(k.rpartition('.')[0] for k in classes)
for fq, body in classes.items():
    pkg, _, name = fq.rpartition('.')
    first = body.strip().split('\n')[0]
    is_iface = ' interface ' in (' ' + first + ' ')
    imps = ''.join('import %s.*;\n' % q for q in sorted(pkgs) if q != pkg)
    src = 'package %s;\n%s%s\n' % (pkg, imps, fix(body, is_iface))
    d = os.path.join(out, *pkg.split('.'))
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, name + '.java'), 'w').write(src)
print("generated", len(classes))
