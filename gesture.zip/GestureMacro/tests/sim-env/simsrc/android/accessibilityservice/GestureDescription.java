package android.accessibilityservice;
import android.graphics.Path;
import java.util.ArrayList;
public final class GestureDescription {
    public static int getMaxStrokeCount() { return 10; }
    public static long getMaxGestureDuration() { return 60000; }
    public final ArrayList<StrokeDescription> strokes = new ArrayList<>();
    public static class StrokeDescription {
        public final Path path; public final long start, dur; public final boolean cont; public StrokeDescription prev;
        public StrokeDescription(Path p, long s, long d) { this(p, s, d, false); }
        public StrokeDescription(Path p, long s, long d, boolean c) {
            if (s < 0 || d <= 0) { android.content.SimEnv.negative++; throw new IllegalArgumentException("bad times"); }
            if (p.points.isEmpty()) throw new IllegalArgumentException("empty path");
            for (int i = 0; i < p.points.size(); i++) { float[] q = p.points.get(i); boolean last = i == p.points.size() - 1;
                boolean bad = q[0] < 0 || q[1] < 0 || (last && (q[0] > android.content.SimEnv.dm.widthPixels || q[1] > android.content.SimEnv.dm.heightPixels));
                if (bad) { android.content.SimEnv.negative++; throw new IllegalArgumentException("Path bounds invalid"); } }
            path = p; start = s; dur = d; cont = c;
        }
        public StrokeDescription continueStroke(Path p, long s, long d, boolean c) {
            if (!cont) throw new IllegalStateException("Cannot continue a stroke that is not continued");
            StrokeDescription n = new StrokeDescription(p, s, d, c); n.prev = this; return n;
        }
        public boolean willContinue() { return cont; }
        public float[] startPt() { return path.points.get(0); }
        public float[] endPt() { return path.points.get(path.points.size() - 1); }
    }
    public static class Builder {
        private final ArrayList<StrokeDescription> l = new ArrayList<>();
        public Builder() { }
        public Builder addStroke(StrokeDescription s) { if (l.size() >= 10) throw new IllegalArgumentException("too many strokes"); l.add(s); return this; }
        public GestureDescription build() { if (l.isEmpty()) throw new IllegalStateException("no strokes"); GestureDescription g = new GestureDescription(); g.strokes.addAll(l); return g; }
    }
}
