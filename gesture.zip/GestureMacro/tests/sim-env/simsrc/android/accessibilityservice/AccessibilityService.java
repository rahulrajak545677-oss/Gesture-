package android.accessibilityservice;
import android.content.*;
import android.os.Handler;
public abstract class AccessibilityService extends android.app.Service {
    public static final int GLOBAL_ACTION_BACK = 1, GLOBAL_ACTION_HOME = 2, GLOBAL_ACTION_RECENTS = 3, GLOBAL_ACTION_NOTIFICATIONS = 4, GLOBAL_ACTION_QUICK_SETTINGS = 5, GLOBAL_ACTION_POWER_DIALOG = 6, GLOBAL_ACTION_LOCK_SCREEN = 8, GLOBAL_ACTION_TAKE_SCREENSHOT = 9;
    public static abstract class GestureResultCallback {
        public void onCompleted(GestureDescription g) { }
        public void onCancelled(GestureDescription g) { }
    }
    protected void onServiceConnected() { }
    public abstract void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e);
    public abstract void onInterrupt();
    public boolean onUnbind(Intent i) { return false; }
    public void onDestroy() { }
    public void onConfigurationChanged(android.content.res.Configuration c) { }
    public final boolean performGlobalAction(int a) { SimEnv.globals.add(a); return true; }
    public final boolean dispatchGesture(GestureDescription g, GestureResultCallback cb, Handler h) {
        if (SimEnv.rejectDispatch) return false;
        if (SimEnv.rejectCount > 0) { SimEnv.rejectCount--; return false; }
        if (SimEnv.onDispatch != null) SimEnv.onDispatch.accept(g);
        if (SimEnv.inFlight != null) { SimEnv.overlaps++; Object[] old = SimEnv.inFlight; SimEnv.inFlight = null; SimEnv.open = null; fire(old, false); }
        for (GestureDescription.StrokeDescription s : g.strokes) {
            if (s.prev != null) {
                float[] pe = s.prev.endPt(), st = s.startPt();
                if (SimEnv.open != s.prev || Math.abs(pe[0] - st[0]) > 0.01f || Math.abs(pe[1] - st[1]) > 0.01f) SimEnv.badChain++;
            } else if (SimEnv.open != null) SimEnv.orphans++;
            SimEnv.open = s.cont ? s : null;
        }
        Object[] rec = {g, cb, h, Handler.now};
        SimEnv.dispatched.add(rec);
        SimEnv.inFlight = rec;
        return true;
    }
    private static void fire(final Object[] rec, final boolean ok) {
        final GestureResultCallback cb = (GestureResultCallback) rec[1];
        if (cb == null) return;
        Runnable r = new Runnable() { public void run() { if (ok) cb.onCompleted((GestureDescription) rec[0]); else cb.onCancelled((GestureDescription) rec[0]); } };
        if (rec[2] != null) ((Handler) rec[2]).post(r); else r.run();
    }
    /** test helper: Android finishes (or cancels) the gesture that is in flight */
    public static void finishInFlight(boolean ok) {
        Object[] rec = SimEnv.inFlight; if (rec == null) return;
        SimEnv.inFlight = null;
        if (!ok) SimEnv.open = null;
        fire(rec, ok);
    }
}
