package android.widget;
public class Toast {
    public static final int LENGTH_SHORT = 0, LENGTH_LONG = 1;
    private String t;
    public static Toast makeText(android.content.Context c, CharSequence t, int d) { Toast x = new Toast(); x.t = String.valueOf(t); return x; }
    public void show() { android.content.SimEnv.toasts.add(t); }
}
