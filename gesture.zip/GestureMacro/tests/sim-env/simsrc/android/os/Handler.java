package android.os;
public class Handler {
    public static long now = 1000;
    private static long seq = 0;
    private static final java.util.ArrayList<Object[]> q = new java.util.ArrayList<>();
    public Handler() { }
    public Handler(Looper l) { }
    public boolean post(Runnable r) { return postDelayed(r, 0); }
    public boolean postDelayed(Runnable r, long d) { q.add(new Object[]{now + Math.max(0, d), seq++, r}); return true; }
    public void removeCallbacks(Runnable r) { for (int i = q.size() - 1; i >= 0; i--) if (q.get(i)[2] == r) q.remove(i); }
    public void removeCallbacksAndMessages(Object t) { q.clear(); }
    public static void advance(long ms) {
        long end = now + ms;
        while (true) {
            Object[] best = null;
            for (Object[] o : q) {
                if ((Long) o[0] > end) continue;
                if (best == null || (Long) o[0] < (Long) best[0] || ((Long) o[0]).equals(best[0]) && (Long) o[1] < (Long) best[1]) best = o;
            }
            if (best == null) break;
            q.remove(best);
            now = Math.max(now, (Long) best[0]);
            ((Runnable) best[2]).run();
        }
        now = end;
    }
    public static void reset() { q.clear(); now = 1000; }
    public static int pending() { return q.size(); }
}
