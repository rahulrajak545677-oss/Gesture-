package android.content;
import android.accessibilityservice.*;
import android.os.Handler;
import java.util.ArrayList;
public class SimEnv {
    public static android.view.SimWm wm;
    public static SimPrefs prefs;
    public static android.util.DisplayMetrics dm;
    public static final ArrayList<String> toasts = new ArrayList<>();
    public static final ArrayList<Intent> started = new ArrayList<>();
    public static final ArrayList<Object[]> dispatched = new ArrayList<>(); // {GestureDescription, callback, handler, timeMs}
    public static final ArrayList<Integer> globals = new ArrayList<>();
    public static boolean rejectDispatch;
    public static int rejectCount;
    public static java.util.function.Consumer<GestureDescription> onDispatch;
    public static int overlaps, badChain, orphans, negative;
    public static Object[] inFlight;
    public static GestureDescription.StrokeDescription open;
    public static void reset(int w, int h) {
        Handler.reset();
        wm = new android.view.SimWm();
        prefs = new SimPrefs();
        dm = new android.util.DisplayMetrics();
        dm.widthPixels = w; dm.heightPixels = h; dm.density = 3f; dm.scaledDensity = 3f;
        toasts.clear(); started.clear(); dispatched.clear(); globals.clear();
        rejectDispatch = false; rejectCount = 0; onDispatch = null; overlaps = badChain = orphans = negative = 0; inFlight = null; open = null;
    }
}
