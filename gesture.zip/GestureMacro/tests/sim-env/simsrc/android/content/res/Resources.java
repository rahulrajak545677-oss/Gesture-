package android.content.res;
public class Resources {
    public android.util.DisplayMetrics getDisplayMetrics() { return android.content.SimEnv.dm; }
    public Configuration getConfiguration() { Configuration c = new Configuration(); c.orientation = android.content.SimEnv.dm.widthPixels > android.content.SimEnv.dm.heightPixels ? 2 : 1; return c; }
    public int getIdentifier(String n, String t, String p) { return 0; }
    public int getDimensionPixelSize(int id) { return 0; }
}
