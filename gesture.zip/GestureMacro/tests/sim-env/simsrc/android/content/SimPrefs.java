package android.content;
import java.util.*;
public class SimPrefs implements SharedPreferences {
    public final HashMap<String, Object> m = new HashMap<>();
    private final ArrayList<OnSharedPreferenceChangeListener> ls = new ArrayList<>();
    public boolean getBoolean(String k, boolean d) { Object o = m.get(k); return o == null ? d : (Boolean) o; }
    public int getInt(String k, int d) { Object o = m.get(k); return o == null ? d : (Integer) o; }
    public float getFloat(String k, float d) { Object o = m.get(k); return o == null ? d : (Float) o; }
    public String getString(String k, String d) { Object o = m.get(k); return o == null ? d : (String) o; }
    public boolean contains(String k) { return m.containsKey(k); }
    public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l) { ls.add(l); }
    public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l) { ls.remove(l); }
    public Editor edit() { return new Ed(); }
    private class Ed implements Editor {
        final LinkedHashMap<String, Object> puts = new LinkedHashMap<>();
        final ArrayList<String> removes = new ArrayList<>();
        boolean clear;
        public Editor putBoolean(String k, boolean v) { puts.put(k, v); return this; }
        public Editor putInt(String k, int v) { puts.put(k, v); return this; }
        public Editor putFloat(String k, float v) { puts.put(k, v); return this; }
        public Editor putString(String k, String v) { puts.put(k, v); return this; }
        public Editor remove(String k) { removes.add(k); return this; }
        public Editor clear() { clear = true; return this; }
        public boolean commit() { apply(); return true; }
        public void apply() {
            ArrayList<String> changed = new ArrayList<>();
            if (clear) { changed.addAll(m.keySet()); m.clear(); }
            for (String k : removes) if (m.remove(k) != null) changed.add(k);
            for (Map.Entry<String, Object> e : puts.entrySet()) {
                Object old = m.get(e.getKey());
                if (old == null || !old.equals(e.getValue())) { m.put(e.getKey(), e.getValue()); changed.add(e.getKey()); }
            }
            for (String k : changed) for (OnSharedPreferenceChangeListener l : new ArrayList<>(ls)) l.onSharedPreferenceChanged(SimPrefs.this, k);
        }
    }
}
