package android.content;
public class ContextWrapper extends Context {
    public Object getSystemService(String n) { return Context.WINDOW_SERVICE.equals(n) ? SimEnv.wm : null; }
    public android.content.res.Resources getResources() { return new android.content.res.Resources(); }
    public Context getApplicationContext() { return this; }
    public SharedPreferences getSharedPreferences(String n, int m) { return SimEnv.prefs; }
    public ContentResolver getContentResolver() { return null; }
    public String getPackageName() { return "sim"; }
    public void startActivity(Intent i) { SimEnv.started.add(i); }
}
