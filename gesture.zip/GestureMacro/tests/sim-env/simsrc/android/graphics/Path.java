package android.graphics;
public class Path {
    public final java.util.ArrayList<float[]> points = new java.util.ArrayList<>();
    public Path() { }
    public void moveTo(float x, float y) { points.add(new float[]{x, y}); }
    public void lineTo(float x, float y) { points.add(new float[]{x, y}); }
    public void quadTo(float a, float b, float c, float d) { points.add(new float[]{c, d}); }
    public void cubicTo(float a, float b, float c, float d, float e, float f) { points.add(new float[]{e, f}); }
    public void arcTo(RectF o, float s, float sw) { }
    public void close() { }
    public void reset() { points.clear(); }
    public void addCircle(float x, float y, float r, Direction d) { }
    public enum Direction { CW, CCW }
}
