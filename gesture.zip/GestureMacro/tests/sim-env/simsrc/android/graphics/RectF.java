package android.graphics;
public class RectF {
    public float left, top, right, bottom;
    public RectF() { }
    public RectF(float l, float t, float r, float b) { set(l, t, r, b); }
    public void set(float l, float t, float r, float b) { left = l; top = t; right = r; bottom = b; }
    public boolean contains(float x, float y) { return left < right && top < bottom && x >= left && x < right && y >= top && y < bottom; }
    public float centerX() { return (left + right) / 2f; }
    public float centerY() { return (top + bottom) / 2f; }
    public float width() { return right - left; }
    public float height() { return bottom - top; }
    public void inset(float dx, float dy) { left += dx; top += dy; right -= dx; bottom -= dy; }
}
