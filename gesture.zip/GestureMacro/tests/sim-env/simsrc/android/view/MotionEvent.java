package android.view;
public final class MotionEvent {
    public static final int ACTION_DOWN = 0, ACTION_UP = 1, ACTION_MOVE = 2, ACTION_CANCEL = 3, ACTION_POINTER_DOWN = 5, ACTION_POINTER_UP = 6, ACTION_MASK = 255, ACTION_OUTSIDE = 4;
    public int action; public float x, y, ox, oy; public long t;
    public final java.util.ArrayList<float[]> hist = new java.util.ArrayList<>(); // {x, y, t} in window coordinates
    public MotionEvent(int action, float x, float y, float ox, float oy, long t) { this.action = action; this.x = x; this.y = y; this.ox = ox; this.oy = oy; this.t = t; }
    public final int getActionMasked() { return action & 255; }
    public final int getAction() { return action; }
    public final int getActionIndex() { return 0; }
    public final int getPointerCount() { return 1; }
    public final int getPointerId(int i) { return 0; }
    public final int findPointerIndex(int id) { return 0; }
    public final float getX() { return x; }
    public final float getY() { return y; }
    public final float getX(int i) { return x; }
    public final float getY(int i) { return y; }
    public final float getRawX() { return x + ox; }
    public final float getRawY() { return y + oy; }
    public final long getEventTime() { return t; }
    public final long getDownTime() { return t; }
    public final int getHistorySize() { return hist.size(); }
    public final float getHistoricalX(int p) { return hist.get(p)[0]; }
    public final float getHistoricalY(int p) { return hist.get(p)[1]; }
    public final float getHistoricalX(int ptr, int p) { return hist.get(p)[0]; }
    public final float getHistoricalY(int ptr, int p) { return hist.get(p)[1]; }
    public final long getHistoricalEventTime(int p) { return (long) hist.get(p)[2]; }
}
