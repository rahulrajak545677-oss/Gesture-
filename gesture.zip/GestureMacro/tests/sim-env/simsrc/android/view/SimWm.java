package android.view;
import java.util.*;
public class SimWm implements WindowManager {
    public final ArrayList<View> views = new ArrayList<>();
    public final HashMap<View, int[]> applied = new HashMap<>(); // x, y, flags, w, h as last applied
    public final ArrayList<String> log = new ArrayList<>();
    public Display getDefaultDisplay() { return new Display(); }
    public void addView(View v, ViewGroup.LayoutParams p) {
        if (views.contains(v)) throw new IllegalStateException("view already added");
        views.add(v); snap(v, p); v.attached = true; log.add("add " + v.getClass().getSimpleName());
    }
    public void updateViewLayout(View v, ViewGroup.LayoutParams p) {
        if (!views.contains(v)) throw new IllegalArgumentException("view not attached");
        snap(v, p); log.add("update " + v.getClass().getSimpleName());
    }
    public void removeView(View v) {
        if (!views.remove(v)) throw new IllegalArgumentException("view not attached");
        applied.remove(v); v.attached = false; log.add("remove " + v.getClass().getSimpleName());
    }
    private void snap(View v, ViewGroup.LayoutParams p) {
        WindowManager.LayoutParams w = (WindowManager.LayoutParams) p;
        int W = android.content.SimEnv.dm.widthPixels, H = android.content.SimEnv.dm.heightPixels;
        v.simW = p.width == -1 ? W : p.width; v.simH = p.height == -1 ? H : p.height;
        applied.put(v, new int[]{w.x, w.y, w.flags, v.simW, v.simH});
    }
    @SuppressWarnings("unchecked")
    public <T> T find(Class<T> c) { for (View v : views) if (c.isInstance(v)) return (T) v; return null; }
    public int count(Class<?> c) { int n = 0; for (View v : views) if (c.isInstance(v)) n++; return n; }
    /** topmost touchable window containing the raw point (what Android would hand a touch to) */
    public View hit(float x, float y) {
        for (int i = views.size() - 1; i >= 0; i--) {
            View v = views.get(i); int[] a = applied.get(v);
            if ((a[2] & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) != 0) continue;
            if (x >= a[0] && x < a[0] + a[3] && y >= a[1] && y < a[1] + a[4]) return v;
        }
        return null;
    }
}
