package android.view;
public class ViewPropertyAnimator {
    private final View v;
    public ViewPropertyAnimator(View v) { this.v = v; }
    public ViewPropertyAnimator alpha(float a) { if (v != null) v.setAlpha(a); return this; }
    public ViewPropertyAnimator setDuration(long d) { return this; }
    public ViewPropertyAnimator scaleX(float s) { return this; }
    public ViewPropertyAnimator scaleY(float s) { return this; }
    public ViewPropertyAnimator translationX(float s) { return this; }
    public ViewPropertyAnimator translationY(float s) { return this; }
    public ViewPropertyAnimator withEndAction(Runnable r) { return this; }
    public void start() { }
    public void cancel() { }
}
