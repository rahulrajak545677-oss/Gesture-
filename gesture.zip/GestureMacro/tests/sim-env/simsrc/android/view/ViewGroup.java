package android.view;
import android.content.Context;
public abstract class ViewGroup extends View {
    public static class LayoutParams {
        public static final int MATCH_PARENT = -1; public static final int WRAP_CONTENT = -2;
        public int width; public int height;
        public LayoutParams(int w, int h) { width = w; height = h; }
        protected LayoutParams() { }
    }
    public static class MarginLayoutParams extends LayoutParams {
        public int topMargin, bottomMargin, leftMargin, rightMargin;
        public MarginLayoutParams(int w, int h) { super(w, h); }
        protected MarginLayoutParams() { }
        public void setMargins(int l, int t, int r, int b) { leftMargin = l; topMargin = t; rightMargin = r; bottomMargin = b; }
    }
    public final java.util.ArrayList<View> kids = new java.util.ArrayList<>();
    public ViewGroup(Context c) { super(c); }
    protected ViewGroup() { }
    public void addView(View v) { kids.add(v); }
    public void addView(View v, int i) { kids.add(v); }
    public void addView(View v, LayoutParams p) { v.lp = p; kids.add(v); }
    public void addView(View v, int i, LayoutParams p) { v.lp = p; kids.add(v); }
    public void removeView(View v) { kids.remove(v); }
    public void removeAllViews() { kids.clear(); }
    public int getChildCount() { return kids.size(); }
    public View getChildAt(int i) { return kids.get(i); }
    public void setClipChildren(boolean b) { }
    public void setClipToPadding(boolean b) { }
}
