package android.view;
public class Display {
    public void getRealMetrics(android.util.DisplayMetrics m) { android.util.DisplayMetrics d = android.content.SimEnv.dm; m.widthPixels = d.widthPixels; m.heightPixels = d.heightPixels; m.density = d.density; m.scaledDensity = d.scaledDensity; }
    public void getMetrics(android.util.DisplayMetrics m) { getRealMetrics(m); }
    public int getRotation() { return 0; }
}
