package org.json;
import java.util.*;
public class JSONArray {
    final ArrayList<Object> l = new ArrayList<>();
    public JSONArray() { }
    public JSONArray(String s) throws JSONException { Object o = new JSONObject.P(s).value(); if (!(o instanceof JSONArray)) throw new JSONException("not array"); l.addAll(((JSONArray) o).l); }
    public int length() { return l.size(); }
    public JSONArray put(Object v) { l.add(v); return this; }
    public JSONArray put(double v) throws JSONException { l.add(v); return this; }
    public JSONArray put(long v) { l.add(v); return this; }
    public Object get(int i) throws JSONException { if (i < 0 || i >= l.size()) throw new JSONException("index"); return l.get(i); }
    public JSONArray getJSONArray(int i) throws JSONException { Object o = get(i); if (o instanceof JSONArray) return (JSONArray) o; throw new JSONException("not array"); }
    public JSONObject getJSONObject(int i) throws JSONException { Object o = get(i); if (o instanceof JSONObject) return (JSONObject) o; throw new JSONException("not object"); }
    public String getString(int i) throws JSONException { return String.valueOf(get(i)); }
    public double getDouble(int i) throws JSONException { return ((Number) get(i)).doubleValue(); }
    public long getLong(int i) throws JSONException { return ((Number) get(i)).longValue(); }
    public int getInt(int i) throws JSONException { return ((Number) get(i)).intValue(); }
    public String optString(int i, String d) { return i >= 0 && i < l.size() ? String.valueOf(l.get(i)) : d; }
    public String toString() { StringBuilder b = new StringBuilder("["); for (int i = 0; i < l.size(); i++) { if (i > 0) b.append(','); JSONObject.w(b, l.get(i)); } return b.append(']').toString(); }
}
