package org.json;
import java.util.*;
public class JSONObject {
    final LinkedHashMap<String, Object> m = new LinkedHashMap<>();
    public JSONObject() { }
    public JSONObject(String s) throws JSONException { Object o = new P(s).value(); if (!(o instanceof JSONObject)) throw new JSONException("not object"); m.putAll(((JSONObject) o).m); }
    public JSONObject put(String k, Object v) throws JSONException { m.put(k, v); return this; }
    public JSONObject put(String k, long v) throws JSONException { m.put(k, v); return this; }
    public JSONObject put(String k, double v) throws JSONException { m.put(k, v); return this; }
    public JSONObject put(String k, boolean v) throws JSONException { m.put(k, v); return this; }
    private Object g(String k) throws JSONException { if (!m.containsKey(k)) throw new JSONException("missing " + k); return m.get(k); }
    public String getString(String k) throws JSONException { return String.valueOf(g(k)); }
    public int getInt(String k) throws JSONException { return ((Number) g(k)).intValue(); }
    public long getLong(String k) throws JSONException { return ((Number) g(k)).longValue(); }
    public double getDouble(String k) throws JSONException { return ((Number) g(k)).doubleValue(); }
    public JSONArray getJSONArray(String k) throws JSONException { return (JSONArray) g(k); }
    public String optString(String k, String d) { return m.containsKey(k) ? String.valueOf(m.get(k)) : d; }
    public int optInt(String k, int d) { return m.containsKey(k) ? ((Number) m.get(k)).intValue() : d; }
    public long optLong(String k, long d) { return m.containsKey(k) ? ((Number) m.get(k)).longValue() : d; }
    public boolean has(String k) { return m.containsKey(k); }
    public String toString() { StringBuilder b = new StringBuilder("{"); boolean f = true; for (Map.Entry<String, Object> e : m.entrySet()) { if (!f) b.append(','); f = false; w(b, e.getKey()); b.append(':'); w(b, e.getValue()); } return b.append('}').toString(); }
    static void w(StringBuilder b, Object o) {
        if (o instanceof String) { b.append('"'); for (char c : ((String) o).toCharArray()) { if (c == '"' || c == '\\') b.append('\\'); b.append(c); } b.append('"'); }
        else b.append(String.valueOf(o));
    }
    static final class P {
        final String s; int i;
        P(String s) { this.s = s; }
        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        Object value() throws JSONException {
            ws(); if (i >= s.length()) throw new JSONException("eof");
            char c = s.charAt(i);
            if (c == '{') { i++; JSONObject o = new JSONObject(); ws(); if (s.charAt(i) == '}') { i++; return o; }
                while (true) { ws(); String k = (String) value(); ws(); if (s.charAt(i++) != ':') throw new JSONException(":"); o.m.put(k, value()); ws(); char d = s.charAt(i++); if (d == '}') return o; if (d != ',') throw new JSONException(","); } }
            if (c == '[') { i++; JSONArray a = new JSONArray(); ws(); if (s.charAt(i) == ']') { i++; return a; }
                while (true) { a.l.add(value()); ws(); char d = s.charAt(i++); if (d == ']') return a; if (d != ',') throw new JSONException(","); } }
            if (c == '"') { i++; StringBuilder b = new StringBuilder(); while (s.charAt(i) != '"') { char d = s.charAt(i++); if (d == '\\') d = s.charAt(i++); b.append(d); } i++; return b.toString(); }
            int st = i; while (i < s.length() && ",]} \n\t\r".indexOf(s.charAt(i)) < 0) i++;
            String t = s.substring(st, i);
            if (t.equals("true")) return Boolean.TRUE; if (t.equals("false")) return Boolean.FALSE; if (t.equals("null")) return null;
            try { if (t.contains(".") || t.contains("e") || t.contains("E")) return Double.parseDouble(t); return Long.parseLong(t); } catch (NumberFormatException e) { throw new JSONException("num " + t); }
        }
    }
}
