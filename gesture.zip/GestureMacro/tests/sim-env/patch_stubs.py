"""Turns the generated Android API stand-ins into ones that remember state (view fields, click listeners,
text, child views), so the real app code can be driven by tests. Usage: patch_stubs.py STUBS_DIR"""
import glob
import os
import re
import sys

root = sys.argv[1]

p = os.path.join(root, 'android/view/View.java')
s = open(p).read()


def patch(name, body):
    global s
    pat = re.compile(r'(\b' + name + r'\s*\([^)]*\)\s*)\{[^}]*\}')
    assert pat.search(s), name
    s = pat.sub(lambda m: m.group(1) + '{ ' + body + ' }', s, count=1)


s = s.replace('public class View {', 'public class View {\n  public Context ctx; public float alpha = 1f; public int visibility = 0, simW, simH; public OnTouchListener touch; public ViewGroup.LayoutParams lp; public boolean attached;\n  public boolean simTouch(MotionEvent e) { if (touch != null && touch.onTouch(this, e)) return true; return onTouchEvent(e); }', 1)
s = re.sub(r'public\s+View\(Context c\)\s*\{[^}]*\}', 'public View(Context c) { ctx = c; }', s, count=1)
patch('getContext', 'return ctx;')
patch('getWidth', 'return simW;')
patch('getHeight', 'return simH;')
patch('getAlpha', 'return alpha;')
patch('setAlpha', 'alpha = a;')
patch('setVisibility', 'visibility = v;')
patch('getVisibility', 'return visibility;')
patch('setOnTouchListener', 'touch = l;')
patch('setLayoutParams', 'lp = p;')
patch('getLayoutParams', 'return lp;')
patch('animate', 'return new ViewPropertyAnimator(this);')
patch('post', 'new android.os.Handler().post(r); return true;')
patch('setOnClickListener', 'clickL = l;')
s = s.replace('public boolean attached;', 'public boolean attached; public OnClickListener clickL;\n  public void simClick() { if (clickL != null) clickL.onClick(this); }', 1)
open(p, 'w').write(s)

t = os.path.join(root, 'android/widget/TextView.java')
x = open(t).read()
x = x.replace('public class TextView extends View {', 'public class TextView extends View {\n  public String txt = "";', 1)
x = re.sub(r'void\s+setText\(CharSequence s\)\s*\{[^}]*\}', 'void setText(CharSequence s) { txt = String.valueOf(s); }', x, count=1)
x = re.sub(r'CharSequence\s+getText\(\)\s*\{[^}]*\}', 'CharSequence getText() { return txt; }', x, count=1)
open(t, 'w').write(x)

for f in glob.glob(os.path.join(root, 'android/widget/*.java')):
    x = open(f).read()
    y = re.sub(r'public\s+(\w+)\(Context c\)\s*\{\s*\}', r'public \1(Context c) { super(c); }', x)
    if y != x:
        open(f, 'w').write(y)
