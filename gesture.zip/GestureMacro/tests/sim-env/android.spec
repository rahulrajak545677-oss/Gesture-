== android.content.Context
public abstract class Context {
  public static final int MODE_PRIVATE = 0;
  public static final String WINDOW_SERVICE = "window";
  public static final String AUDIO_SERVICE = "audio";
  public static final String INPUT_METHOD_SERVICE = "input_method";
  public abstract Object getSystemService(String n);
  public abstract android.content.res.Resources getResources();
  public abstract Context getApplicationContext();
  public abstract SharedPreferences getSharedPreferences(String n, int m);
  public abstract ContentResolver getContentResolver();
  public abstract String getPackageName();
  public abstract void startActivity(Intent i);
  public final String getString(int id);
  public Object getSystemService(Class<?> c);
}
== android.content.ContextWrapper
public class ContextWrapper extends Context {
  public Object getSystemService(String n);
  public android.content.res.Resources getResources();
  public Context getApplicationContext();
  public SharedPreferences getSharedPreferences(String n, int m);
  public ContentResolver getContentResolver();
  public String getPackageName();
  public void startActivity(Intent i);
}
== android.content.ContentResolver
public abstract class ContentResolver { }
== android.content.ComponentName
public final class ComponentName {
  public ComponentName(Context c, Class<?> k);
  public static ComponentName unflattenFromString(String s);
  public boolean equals(Object o);
}
== android.content.DialogInterface
public interface DialogInterface {
  void dismiss();
  public interface OnClickListener { void onClick(DialogInterface d, int which); }
}
== android.content.Intent
public class Intent {
  public static final int FLAG_ACTIVITY_NEW_TASK = 1;
  public static final int FLAG_ACTIVITY_CLEAR_TOP = 2;
  public static final String ACTION_MAIN = "m";
  public Intent(Context c, Class<?> k);
  public Intent(String a);
  public Intent addFlags(int f);
  public Intent setData(android.net.Uri u);
  public Intent putExtra(String k, String v);
}
== android.content.SharedPreferences
public interface SharedPreferences {
  boolean getBoolean(String k, boolean d);
  int getInt(String k, int d);
  float getFloat(String k, float d);
  String getString(String k, String d);
  boolean contains(String k);
  Editor edit();
  void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l);
  void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l);
  public interface OnSharedPreferenceChangeListener { void onSharedPreferenceChanged(SharedPreferences p, String key); }
  public interface Editor {
    Editor putBoolean(String k, boolean v);
    Editor putInt(String k, int v);
    Editor putFloat(String k, float v);
    Editor putString(String k, String v);
    Editor remove(String k);
    Editor clear();
    void apply();
    boolean commit();
  }
}
== android.content.pm.ActivityInfo
public class ActivityInfo {
  public static final int SCREEN_ORIENTATION_UNSPECIFIED = -1;
  public static final int SCREEN_ORIENTATION_PORTRAIT = 1;
  public static final int SCREEN_ORIENTATION_LANDSCAPE = 0;
  public static final int SCREEN_ORIENTATION_SENSOR = 4;
  public static final int SCREEN_ORIENTATION_LOCKED = 14;
}
== android.content.res.ColorStateList
public class ColorStateList {
  public ColorStateList(int[][] s, int[] c);
  public static ColorStateList valueOf(int c);
}
== android.content.res.Configuration
public class Configuration {
  public static final int ORIENTATION_PORTRAIT = 1;
  public static final int ORIENTATION_LANDSCAPE = 2;
  public int orientation;
}
== android.content.res.Resources
public class Resources {
  public android.util.DisplayMetrics getDisplayMetrics();
  public Configuration getConfiguration();
  public int getIdentifier(String n, String t, String p);
  public int getDimensionPixelSize(int id);
}
== android.util.DisplayMetrics
public class DisplayMetrics {
  public int widthPixels; public int heightPixels; public float density; public float scaledDensity;
}
== android.util.SparseArray
public class SparseArray<E> {
  public SparseArray();
  public void put(int k, E v);
  public E get(int k);
  public void remove(int k);
  public int size();
  public int keyAt(int i);
  public E valueAt(int i);
  public void clear();
}
== android.net.Uri
public abstract class Uri { public static Uri parse(String s); }
== android.os.Build
public class Build {
  public static class VERSION { public static final int SDK_INT = 34; }
  public static class VERSION_CODES { public static final int O = 26; public static final int P = 28; public static final int R = 30; public static final int Q = 29; }
}
== android.os.Bundle
public class Bundle { }
== android.os.Handler
public class Handler {
  public Handler();
  public Handler(Looper l);
  public boolean post(Runnable r);
  public boolean postDelayed(Runnable r, long d);
  public void removeCallbacks(Runnable r);
  public void removeCallbacksAndMessages(Object t);
}
== android.os.Looper
public final class Looper { public static Looper getMainLooper(); }
== android.os.SystemClock
public final class SystemClock { public static long uptimeMillis(); public static long elapsedRealtime(); }
== android.provider.Settings
public class Settings {
  public static final String ACTION_ACCESSIBILITY_SETTINGS = "a";
  public static final String ACTION_APPLICATION_DETAILS_SETTINGS = "b";
  public static final String ACTION_MANAGE_OVERLAY_PERMISSION = "c";
  public static class Secure {
    public static final String ENABLED_ACCESSIBILITY_SERVICES = "e";
    public static String getString(android.content.ContentResolver r, String n);
    public static int getInt(android.content.ContentResolver r, String n, int d);
  }
}
== android.text.InputType
public class InputType { public static final int TYPE_CLASS_NUMBER = 2; public static final int TYPE_NUMBER_FLAG_DECIMAL = 8192; public static final int TYPE_CLASS_TEXT = 1; public static final int TYPE_TEXT_FLAG_CAP_WORDS = 8192; }
== android.graphics.Canvas
public class Canvas {
  public void drawCircle(float x, float y, float r, Paint p);
  public void drawRect(float l, float t, float r, float b, Paint p);
  public void drawRect(RectF r, Paint p);
  public void drawRoundRect(RectF r, float rx, float ry, Paint p);
  public void drawRoundRect(float l, float t, float r, float b, float rx, float ry, Paint p);
  public void drawLine(float a, float b, float c, float d, Paint p);
  public void drawText(String s, float x, float y, Paint p);
  public void drawPath(Path p, Paint pt);
  public void drawColor(int c);
  public void drawArc(RectF r, float s, float sw, boolean c, Paint p);
  public void drawOval(RectF r, Paint p);
  public int save();
  public void restore();
  public void translate(float x, float y);
  public void scale(float x, float y);
  public void rotate(float d);
  public void rotate(float d, float x, float y);
  public int getWidth();
  public int getHeight();
}
== android.graphics.Color
public class Color {
  public static final int WHITE = -1; public static final int BLACK = -16777216; public static final int TRANSPARENT = 0;
  public static int parseColor(String s);
  public static int argb(int a, int r, int g, int b);
  public static int rgb(int r, int g, int b);
  public static int alpha(int c);
}
== android.graphics.DashPathEffect
public class DashPathEffect extends PathEffect { public DashPathEffect(float[] i, float p); }
== android.graphics.PathEffect
public class PathEffect { }
== android.graphics.Paint
public class Paint {
  public static final int ANTI_ALIAS_FLAG = 1;
  public enum Style { FILL, STROKE, FILL_AND_STROKE }
  public enum Align { LEFT, CENTER, RIGHT }
  public enum Cap { BUTT, ROUND, SQUARE }
  public enum Join { MITER, ROUND, BEVEL }
  public void setStrokeJoin(Join j);
  public Paint();
  public Paint(int f);
  public void setStyle(Style s);
  public void setColor(int c);
  public void setAlpha(int a);
  public void setStrokeWidth(float w);
  public void setStrokeCap(Cap c);
  public void setAntiAlias(boolean b);
  public void setTextSize(float s);
  public void setTextAlign(Align a);
  public void setTypeface(Typeface t);
  public void setPathEffect(PathEffect e);
  public float measureText(String s);
  public float ascent();
  public float descent();
}
== android.graphics.Path
public class Path {
  public Path();
  public void moveTo(float x, float y);
  public void lineTo(float x, float y);
  public void quadTo(float a, float b, float c, float d);
  public void cubicTo(float a, float b, float c, float d, float e, float f);
  public void arcTo(RectF o, float s, float sw);
  public void close();
  public void reset();
  public void addCircle(float x, float y, float r, Direction d);
  public enum Direction { CW, CCW }
}
== android.graphics.PixelFormat
public class PixelFormat { public static final int TRANSLUCENT = -3; public static final int TRANSPARENT = -2; public static final int OPAQUE = -1; }
== android.graphics.RectF
public class RectF {
  public float left, top, right, bottom;
  public RectF();
  public RectF(float l, float t, float r, float b);
  public void set(float l, float t, float r, float b);
  public boolean contains(float x, float y);
  public float centerX();
  public float centerY();
  public float width();
  public float height();
  public void inset(float dx, float dy);
}
== android.graphics.Typeface
public class Typeface {
  public static final int NORMAL = 0; public static final int BOLD = 1;
  public static final Typeface DEFAULT = null; public static final Typeface DEFAULT_BOLD = null;
  public static Typeface create(Typeface f, int s);
  public static Typeface create(String n, int s);
}
== android.graphics.drawable.Drawable
public abstract class Drawable { }
== android.graphics.drawable.ColorDrawable
public class ColorDrawable extends Drawable { public ColorDrawable(int c); }
== android.graphics.drawable.GradientDrawable
public class GradientDrawable extends Drawable {
  public static final int RECTANGLE = 0; public static final int OVAL = 1;
  public GradientDrawable();
  public void setColor(int c);
  public void setCornerRadius(float r);
  public void setShape(int s);
  public void setStroke(int w, int c);
  public void setSize(int w, int h);
  public void setCornerRadii(float[] r);
}
== android.graphics.drawable.StateListDrawable
public class StateListDrawable extends Drawable {
  public StateListDrawable();
  public void addState(int[] s, Drawable d);
}
== android.media.AudioManager
public class AudioManager {
  public static final int ADJUST_RAISE = 1; public static final int ADJUST_LOWER = -1; public static final int ADJUST_TOGGLE_MUTE = 101;
  public static final int STREAM_MUSIC = 3; public static final int FLAG_SHOW_UI = 1;
  public void adjustStreamVolume(int s, int d, int f);
  public void adjustVolume(int d, int f);
}
== android.view.Gravity
public class Gravity { public static final int TOP = 48; public static final int START = 8388611; public static final int LEFT = 3; public static final int CENTER = 17; public static final int CENTER_VERTICAL = 16; public static final int CENTER_HORIZONTAL = 1; public static final int END = 8388613; public static final int RIGHT = 5; public static final int BOTTOM = 80; }
== android.view.HapticFeedbackConstants
public class HapticFeedbackConstants { public static final int VIRTUAL_KEY = 1; public static final int LONG_PRESS = 0; public static final int KEYBOARD_TAP = 3; }
== android.view.SoundEffectConstants
public class SoundEffectConstants { public static final int CLICK = 0; }
== android.view.MotionEvent
public final class MotionEvent {
  public static final int ACTION_DOWN = 0, ACTION_UP = 1, ACTION_MOVE = 2, ACTION_CANCEL = 3, ACTION_POINTER_DOWN = 5, ACTION_POINTER_UP = 6, ACTION_MASK = 255, ACTION_OUTSIDE = 4;
  public final int getActionMasked();
  public final int getAction();
  public final int getActionIndex();
  public final int getPointerCount();
  public final int getPointerId(int i);
  public final int findPointerIndex(int id);
  public final float getX();
  public final float getY();
  public final float getX(int i);
  public final float getY(int i);
  public final float getRawX();
  public final float getRawY();
  public final long getEventTime();
  public final long getDownTime();
  public final int getHistorySize();
  public final float getHistoricalX(int pos);
  public final float getHistoricalY(int pos);
  public final float getHistoricalX(int ptr, int pos);
  public final float getHistoricalY(int ptr, int pos);
  public final long getHistoricalEventTime(int pos);
}
== android.view.View
public class View {
  public static final int VISIBLE = 0, INVISIBLE = 4, GONE = 8;
  public static final int SYSTEM_UI_FLAG_LAYOUT_STABLE = 256, SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 4096, SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 1024, SYSTEM_UI_FLAG_HIDE_NAVIGATION = 2, SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 512, SYSTEM_UI_FLAG_FULLSCREEN = 4;
  public interface OnFocusChangeListener { void onFocusChange(View v, boolean hasFocus); }
  public interface ViewParent { void requestDisallowInterceptTouchEvent(boolean d); }
  public void setRotation(float r);
  public ViewParent getParent();
  public void setTranslationZ(float z);
  public void setFocusableInTouchMode(boolean b);
  public void clearFocus();
  public void setOnFocusChangeListener(OnFocusChangeListener l);
  public static class MeasureSpec { public static int makeMeasureSpec(int s, int m); public static final int EXACTLY = 1 << 30; public static final int AT_MOST = 1 << 31; public static final int UNSPECIFIED = 0; public static int getSize(int s); public static int getMode(int s); }
  public interface OnTouchListener { boolean onTouch(View v, MotionEvent e); }
  public interface OnClickListener { void onClick(View v); }
  public interface OnLongClickListener { boolean onLongClick(View v); }
  public View(Context c);
  protected View() { }
  public Context getContext();
  public android.content.res.Resources getResources();
  public int getWidth();
  public int getHeight();
  public int getMeasuredWidth();
  public int getMeasuredHeight();
  public int getLeft();
  public int getTop();
  public float getAlpha();
  public void setAlpha(float a);
  public void setVisibility(int v);
  public int getVisibility();
  public void invalidate();
  public void requestLayout();
  public void setOnTouchListener(OnTouchListener l);
  public void setScaleX(float s);
  public void setScaleY(float s);
  public float getScaleX();
  public void setOnClickListener(OnClickListener l);
  public void setOnLongClickListener(OnLongClickListener l);
  public void setBackgroundColor(int c);
  public void setBackground(android.graphics.drawable.Drawable d);
  public void setPadding(int l, int t, int r, int b);
  public void setLayoutParams(ViewGroup.LayoutParams p);
  public ViewGroup.LayoutParams getLayoutParams();
  public ViewPropertyAnimator animate();
  public boolean performHapticFeedback(int c);
  public void playSoundEffect(int e);
  public void getLocationOnScreen(int[] l);
  public void setClickable(boolean b);
  public void setEnabled(boolean b);
  public void setSystemUiVisibility(int v);
  public void setFitsSystemWindows(boolean b);
  public void setOnApplyWindowInsetsListener(OnApplyWindowInsetsListener l);
  public interface OnApplyWindowInsetsListener { WindowInsets onApplyWindowInsets(View v, WindowInsets i); }
  public void setTag(Object t);
  public Object getTag();
  public void setContentDescription(CharSequence c);
  public void setTranslationX(float x);
  public void setTranslationY(float y);
  public void setElevation(float e);
  public boolean post(Runnable r);
  public void setLayerType(int t, android.graphics.Paint p);
  public boolean onTouchEvent(MotionEvent e);
  protected void onDraw(android.graphics.Canvas c);
  protected void onMeasure(int w, int h);
  protected void onSizeChanged(int w, int h, int ow, int oh);
  protected void onLayout(boolean c, int l, int t, int r, int b);
  public void setMinimumHeight(int h);
}
== android.view.ViewPropertyAnimator
public class ViewPropertyAnimator {
  public ViewPropertyAnimator alpha(float a);
  public ViewPropertyAnimator setDuration(long d);
  public ViewPropertyAnimator scaleX(float s);
  public ViewPropertyAnimator scaleY(float s);
  public ViewPropertyAnimator translationX(float s);
  public ViewPropertyAnimator translationY(float s);
  public ViewPropertyAnimator withEndAction(Runnable r);
  public void start();
  public void cancel();
}
== android.view.ViewGroup
public abstract class ViewGroup extends View {
  public static class LayoutParams { public static final int MATCH_PARENT = -1; public static final int WRAP_CONTENT = -2; public int width; public int height; public LayoutParams(int w, int h); protected LayoutParams() { } }
  public static class MarginLayoutParams extends LayoutParams { public int topMargin, bottomMargin, leftMargin, rightMargin; public MarginLayoutParams(int w, int h); protected MarginLayoutParams() { } public void setMargins(int l, int t, int r, int b); }
  public ViewGroup(Context c);
  protected ViewGroup() { }
  public void addView(View v);
  public void addView(View v, int i);
  public void addView(View v, LayoutParams p);
  public void addView(View v, int i, LayoutParams p);
  public void removeView(View v);
  public void removeAllViews();
  public int getChildCount();
  public View getChildAt(int i);
  public void setClipChildren(boolean b);
  public void setClipToPadding(boolean b);
}
== android.view.WindowInsets
public final class WindowInsets {
  public int getSystemWindowInsetTop();
  public int getSystemWindowInsetBottom();
  public int getSystemWindowInsetLeft();
  public int getSystemWindowInsetRight();
}
== android.view.Display
public class Display { public void getRealMetrics(android.util.DisplayMetrics m); public void getMetrics(android.util.DisplayMetrics m); public int getRotation(); }
== android.view.WindowManager
public interface WindowManager {
  Display getDefaultDisplay();
  void addView(View v, ViewGroup.LayoutParams p);
  void updateViewLayout(View v, ViewGroup.LayoutParams p);
  void removeView(View v);
  public static class LayoutParams extends ViewGroup.LayoutParams {
    public static final int TYPE_ACCESSIBILITY_OVERLAY = 2032;
    public static final int FLAG_NOT_FOCUSABLE = 8, FLAG_NOT_TOUCHABLE = 16, FLAG_NOT_TOUCH_MODAL = 32, FLAG_LAYOUT_IN_SCREEN = 256, FLAG_LAYOUT_NO_LIMITS = 512, FLAG_WATCH_OUTSIDE_TOUCH = 262144;
    public static final int LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES = 1;
    public static final int FLAG_KEEP_SCREEN_ON = 128, SOFT_INPUT_STATE_VISIBLE = 4;
    public int screenOrientation; public int softInputMode;
    public int x; public int y; public int type; public int flags; public int gravity; public int format; public int layoutInDisplayCutoutMode; public float alpha;
    public LayoutParams(int w, int h, int type, int flags, int format) { super(w, h); this.type = type; this.flags = flags; this.format = format; }
    public LayoutParams() { }
  }
}
== android.view.accessibility.AccessibilityEvent
public class AccessibilityEvent { }
== android.view.inputmethod.EditorInfo
public class EditorInfo { public static final int IME_ACTION_DONE = 6; }
== android.widget.CompoundButton
public abstract class CompoundButton extends TextView {
  public interface OnCheckedChangeListener { void onCheckedChanged(CompoundButton b, boolean c); }
  public CompoundButton(Context c);
  protected CompoundButton() { }
  public void setChecked(boolean b);
  public boolean isChecked();
  public void setOnCheckedChangeListener(OnCheckedChangeListener l);
}
== android.widget.Switch
public class Switch extends CompoundButton {
  public Switch(Context c);
  public void setThumbTintList(android.content.res.ColorStateList l);
  public void setTrackTintList(android.content.res.ColorStateList l);
}
== android.widget.TextView
public class TextView extends View {
  public interface OnEditorActionListener { boolean onEditorAction(TextView v, int a, android.view.KeyEvent e); }
  public TextView(Context c);
  protected TextView() { }
  public void setText(CharSequence s);
  public CharSequence getText();
  public void setTextColor(int c);
  public void setTextSize(float s);
  public void setTextSize(int unit, float s);
  public void setTypeface(android.graphics.Typeface t);
  public void setTypeface(android.graphics.Typeface t, int s);
  public void setGravity(int g);
  public void setSingleLine(boolean b);
  public void setSingleLine();
  public void setLineSpacing(float a, float m);
  public void setMaxLines(int n);
  public void setInputType(int t);
  public void setImeOptions(int o);
  public void setHint(CharSequence s);
  public void setHintTextColor(int c);
  public void setOnEditorActionListener(OnEditorActionListener l);
  public void setAllCaps(boolean b);
  public void setIncludeFontPadding(boolean b);
  public void setLetterSpacing(float s);
}
== android.view.KeyEvent
public class KeyEvent { }
== android.widget.EditText
public class EditText extends TextView {
  public EditText(Context c);
  public android.text.Editable getText();
  public void setSelection(int i);
  public void setSelection(int a, int b);
  public void selectAll();
  public void requestFocus();
}
== android.text.Editable
public interface Editable extends CharSequence { String toString(); }
== android.widget.FrameLayout
public class FrameLayout extends ViewGroup {
  public static class LayoutParams extends ViewGroup.MarginLayoutParams { public int gravity; public LayoutParams(int w, int h); public LayoutParams(int w, int h, int g); }
  public FrameLayout(Context c);
  protected FrameLayout() { }
}
== android.widget.LinearLayout
public class LinearLayout extends ViewGroup {
  public static final int HORIZONTAL = 0, VERTICAL = 1;
  public static class LayoutParams extends ViewGroup.MarginLayoutParams { public float weight; public int gravity; public LayoutParams(int w, int h); public LayoutParams(int w, int h, float wt); }
  public LinearLayout(Context c);
  public void setOrientation(int o);
  public void setGravity(int g);
  public void setWeightSum(float w);
}
== android.widget.ScrollView
public class ScrollView extends FrameLayout {
  public ScrollView(Context c);
  public int getScrollY();
  public void scrollTo(int x, int y);
  public void setVerticalScrollBarEnabled(boolean b);
  public void setFillViewport(boolean b);
  public void setOverScrollMode(int m);
}
== android.widget.SeekBar
public class SeekBar extends View {
  public interface OnSeekBarChangeListener { void onProgressChanged(SeekBar s, int p, boolean u); void onStartTrackingTouch(SeekBar s); void onStopTrackingTouch(SeekBar s); }
  public SeekBar(Context c);
  public void setMax(int m);
  public void setProgress(int p);
  public int getProgress();
  public void setOnSeekBarChangeListener(OnSeekBarChangeListener l);
  public void setProgressTintList(android.content.res.ColorStateList l);
  public void setThumbTintList(android.content.res.ColorStateList l);
  public void setProgressBackgroundTintList(android.content.res.ColorStateList l);
}
== android.widget.Toast
public class Toast {
  public static final int LENGTH_SHORT = 0, LENGTH_LONG = 1;
  public static Toast makeText(Context c, CharSequence t, int d);
  public void show();
}
== android.app.Activity
public class Activity extends ContextWrapper {
  protected void onCreate(android.os.Bundle b);
  protected void onResume();
  protected void onPause();
  protected void onDestroy();
  public void setContentView(android.view.View v);
  public void finish();
  public void setRequestedOrientation(int o);
  public android.view.Window getWindow();
  public android.view.WindowManager getWindowManager();
  public void onWindowFocusChanged(boolean f);
  public void onBackPressed();
  public boolean moveTaskToBack(boolean n);
  public void runOnUiThread(Runnable r);
  public void onConfigurationChanged(android.content.res.Configuration c);
  public boolean dispatchTouchEvent(android.view.MotionEvent e);
  public android.view.View findViewById(int id);
  public void startActivityForResult(android.content.Intent i, int c);
}
== android.view.Window
public abstract class Window {
  public abstract void setStatusBarColor(int c);
  public abstract void setNavigationBarColor(int c);
  public abstract android.view.View getDecorView();
  public abstract void setBackgroundDrawable(android.graphics.drawable.Drawable d);
  public abstract void addFlags(int f);
  public abstract android.view.WindowManager.LayoutParams getAttributes();
  public abstract void setAttributes(android.view.WindowManager.LayoutParams p);
  public abstract void setSoftInputMode(int m);
}
== android.app.AlertDialog
public class AlertDialog implements android.content.DialogInterface {
  public static class Builder {
    public Builder(android.content.Context c);
    public Builder(android.content.Context c, int theme);
    public Builder setTitle(CharSequence t);
    public Builder setMessage(CharSequence m);
    public Builder setView(android.view.View v);
    public Builder setPositiveButton(CharSequence t, android.content.DialogInterface.OnClickListener l);
    public Builder setNegativeButton(CharSequence t, android.content.DialogInterface.OnClickListener l);
    public Builder setNeutralButton(CharSequence t, android.content.DialogInterface.OnClickListener l);
    public Builder setCancelable(boolean c);
    public AlertDialog create();
    public AlertDialog show();
  }
  public void show();
  public void dismiss();
  public android.widget.Button getButton(int w);
  public android.view.Window getWindow();
  public static final int THEME_DEVICE_DEFAULT_DARK = 4;
}
== android.widget.Button
public class Button extends TextView { public Button(Context c); }
== android.accessibilityservice.GestureDescription
public final class GestureDescription {
  public static int getMaxStrokeCount();
  public static long getMaxGestureDuration();
  public static class StrokeDescription {
    public StrokeDescription(android.graphics.Path p, long start, long dur);
    public StrokeDescription(android.graphics.Path p, long start, long dur, boolean willContinue);
    public StrokeDescription continueStroke(android.graphics.Path p, long start, long dur, boolean willContinue);
    public boolean willContinue();
  }
  public static class Builder {
    public Builder();
    public Builder addStroke(StrokeDescription s);
    public GestureDescription build();
  }
}
== android.accessibilityservice.AccessibilityService
public abstract class AccessibilityService extends android.app.Service {
  public static final int GLOBAL_ACTION_BACK = 1, GLOBAL_ACTION_HOME = 2, GLOBAL_ACTION_RECENTS = 3, GLOBAL_ACTION_NOTIFICATIONS = 4, GLOBAL_ACTION_QUICK_SETTINGS = 5, GLOBAL_ACTION_POWER_DIALOG = 6, GLOBAL_ACTION_LOCK_SCREEN = 8, GLOBAL_ACTION_TAKE_SCREENSHOT = 9;
  public static abstract class GestureResultCallback { public void onCompleted(GestureDescription g) { } public void onCancelled(GestureDescription g) { } }
  protected void onServiceConnected();
  public abstract void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e);
  public abstract void onInterrupt();
  public boolean onUnbind(android.content.Intent i);
  public void onDestroy();
  public void onConfigurationChanged(android.content.res.Configuration c);
  public final boolean performGlobalAction(int a);
  public final boolean dispatchGesture(GestureDescription g, GestureResultCallback cb, android.os.Handler h);
}
== android.app.Service
public abstract class Service extends ContextWrapper {
  public void onDestroy();
  public boolean onUnbind(android.content.Intent i);
  public void onConfigurationChanged(android.content.res.Configuration c);
}
== org.json.JSONException
public class JSONException extends Exception { public JSONException(String m); }
== org.json.JSONObject
public class JSONObject {
  public JSONObject();
  public JSONObject(String s) throws JSONException;
  public JSONObject put(String k, Object v) throws JSONException;
  public JSONObject put(String k, long v) throws JSONException;
  public JSONObject put(String k, double v) throws JSONException;
  public JSONObject put(String k, boolean v) throws JSONException;
  public String getString(String k) throws JSONException;
  public int getInt(String k) throws JSONException;
  public long getLong(String k) throws JSONException;
  public double getDouble(String k) throws JSONException;
  public JSONArray getJSONArray(String k) throws JSONException;
  public String optString(String k, String d);
  public int optInt(String k, int d);
  public long optLong(String k, long d);
  public boolean has(String k);
}
== org.json.JSONArray
public class JSONArray {
  public JSONArray();
  public JSONArray(String s) throws JSONException;
  public int length();
  public JSONArray put(Object v);
  public JSONArray getJSONArray(int i) throws JSONException;
  public JSONArray put(double v) throws JSONException;
  public JSONArray put(long v);
  public Object get(int i) throws JSONException;
  public JSONObject getJSONObject(int i) throws JSONException;
  public String getString(int i) throws JSONException;
  public double getDouble(int i) throws JSONException;
  public long getLong(int i) throws JSONException;
  public int getInt(int i) throws JSONException;
  public String optString(int i, String d);
}
== android.view.InputDevice
public class InputDevice {
  public static final int SOURCE_MOUSE = 8194, SOURCE_TOUCHPAD = 1048584, SOURCE_TRACKBALL = 65540;
  public static int[] getDeviceIds();
  public static InputDevice getDevice(int id);
  public int getSources();
  public String getName();
  public boolean isVirtual();
}
== android.R
public final class R { public static final class attr { public static final int state_pressed = 16842919; public static final int state_checked = 16842912; public static final int state_enabled = 16842910; public static final int state_selected = 16842913; } }
