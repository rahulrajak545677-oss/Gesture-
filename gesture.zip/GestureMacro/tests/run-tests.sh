#!/bin/bash
# Runs both test suites on a computer with Java 11+ and Python 3 (no Android SDK needed).
set -e
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
APP=app/src/main/java/com/gesturemacro/app

echo "== 1. pure logic tests"
javac -nowarn -d "$OUT/pure" $APP/TouchStats.java $APP/LiveAssist.java $APP/StrokeRelay.java \
  $APP/LiveSession.java $APP/TriggerPlacement.java tests/com/gesturemacro/app/LiveLogicTests.java
java -cp "$OUT/pure" com.gesturemacro.app.LiveLogicTests

echo "== 2. simulated-phone tests (real GestureService against a simulated Android)"
python3 -I tests/sim-env/stubgen2.py "$OUT/stubs" tests/sim-env/android.spec
(cd tests/sim-env/simsrc && cp -r . "$OUT/stubs/")
python3 -I tests/sim-env/patch_stubs.py "$OUT/stubs"
javac -nowarn -d "$OUT/cls" $(find "$OUT/stubs" -name '*.java') $APP/*.java
javac -nowarn -cp "$OUT/cls" -d "$OUT/tests" tests/sim/com/gesturemacro/app/SimTests.java
java -cp "$OUT/cls:$OUT/tests" com.gesturemacro.app.SimTests
