package com.gesturemacro.app;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Tests of the live-assist logic on a normal computer (no phone, no Android).
 * Run:  javac -d out $(find app/src/main/java/com/gesturemacro/app -name 'TouchStats.java' -o -name 'LiveAssist.java'
 *        -o -name 'StrokeRelay.java' -o -name 'LiveSession.java' -o -name 'TriggerPlacement.java') tests/.../LiveLogicTests.java
 *       java -cp out com.gesturemacro.app.LiveLogicTests
 */
public class LiveLogicTests {
    static int passed = 0;

    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError("FAILED: " + what);
        passed++;
    }

    static boolean near(float a, float b, float tol) {
        return Math.abs(a - b) <= tol;
    }

    // ------------------------------------------------------------------ fakes

    static class Call {
        float x0, y0, x1, y1;
        long dur;
        boolean first, willContinue;
    }

    static class FakeSink implements StrokeRelay.Sink {
        final List<Call> calls = new ArrayList<>();
        final ArrayDeque<StrokeRelay.Done> pending = new ArrayDeque<>();
        boolean autoComplete;
        boolean refuse;

        @Override
        public boolean send(float x0, float y0, float x1, float y1, long dur, boolean first, boolean wc, StrokeRelay.Done d) {
            if (refuse) return false;
            Call c = new Call();
            c.x0 = x0; c.y0 = y0; c.x1 = x1; c.y1 = y1; c.dur = dur; c.first = first; c.willContinue = wc;
            calls.add(c);
            if (autoComplete) d.completed();
            else pending.add(d);
            return true;
        }

        void completeOne() {
            StrokeRelay.Done d = pending.poll();
            if (d != null) d.completed();
        }

        void cancelOne() {
            StrokeRelay.Done d = pending.poll();
            if (d != null) d.cancelled();
        }
    }

    static class Clock implements StrokeRelay.Clock {
        long t;

        @Override
        public long now() {
            return t;
        }
    }

    static class FakeHost implements LiveSession.Host {
        final List<float[]> circles = new ArrayList<>();
        int ended;
        boolean touchable = true;
        int touchableFlips;
        String paused;
        final Map<String, Integer> counts = new HashMap<>();
        int flushes;

        @Override public void showCircles(float[] xy) { circles.add(xy); }
        @Override public void endCircles() { ended++; }
        @Override public void setTriggerTouchable(boolean t) { if (t != touchable) touchableFlips++; touchable = t; }
        @Override public void pauseAssist(String reason) { paused = reason; }
        @Override public void count(String key) { counts.merge(key, 1, Integer::sum); }
        @Override public void flushCounts() { flushes++; }

        int n(String k) { return counts.getOrDefault(k, 0); }
    }

    static List<float[]> upLine() {
        List<float[]> l = new ArrayList<>();
        l.add(new float[]{500, 800, 0});
        l.add(new float[]{500, 600, 100});
        l.add(new float[]{500, 300, 200});
        return l;
    }

    // ------------------------------------------------------------------ tests

    static void testStats() {
        TouchStats s = new TouchStats();
        s.begin(100, 500, 1000);
        for (int i = 1; i <= 10; i++) s.move(100, 500 - i * 20, 1000 + i * 10);
        s.end();
        check(near(s.distance(), 200, 0.01f), "stats: distance 200");
        check(near(s.angleDeg(), 90, 0.01f), "stats: dragging up = 90 degrees");
        check(s.durationMs() == 100, "stats: duration 100 ms");
        check(near(s.speed, 2000, 1), "stats: speed 2000 px/s");
        check(near(s.pathLength, 200, 0.01f), "stats: path length 200");
        TouchStats r = new TouchStats();
        r.begin(0, 0, 0);
        r.move(50, 0, 50);
        check(near(r.angleDeg(), 0, 0.01f), "stats: dragging right = 0 degrees");
        r.move(0, 0, 100);
        r.move(-50, 0, 150);
        check(near(r.angleDeg(), 180, 0.01f), "stats: dragging left = 180 degrees");
        TouchStats idle = new TouchStats();
        idle.move(5, 5, 5);
        check(idle.samples == 0 && !idle.active, "stats: moves before begin are ignored");
    }

    static void testAssist() {
        LiveAssist a = new LiveAssist(20f);
        check(!a.setReferenceFromPoints(new ArrayList<float[]>()), "assist: no points = no reference");
        List<float[]> same = new ArrayList<>();
        same.add(new float[]{1, 1, 0});
        same.add(new float[]{1, 1, 5});
        check(!a.setReferenceFromPoints(same), "assist: zero-length gesture = no reference");
        check(a.setReferenceFromPoints(upLine()), "assist: reference accepted");
        float[] d = a.referenceDirection();
        check(near(d[0], 0, 1e-4f) && near(d[1], -1, 1e-4f), "assist: reference points up");

        // strength 0: always the finger's own position
        a.setStrength(0f);
        a.begin(500, 900);
        float[] p = a.apply(540, 700);
        check(p[0] == 540 && p[1] == 700, "assist: strength 0 leaves the finger alone");

        // strength 1: sideways wobble is removed once the finger leads the way
        a.setStrength(1f);
        a.begin(500, 900);
        float[] q = a.finish(540, 700);
        check(near(q[0], 500, 0.01f) && near(q[1], 700, 0.01f), "assist: finish locks onto the saved direction at strength 1");
        a.setStrength(0.5f);
        q = a.finish(540, 700);
        check(near(q[0], 520, 0.01f), "assist: half strength keeps half the wobble");

        // below the slop distance: untouched
        a.setStrength(1f);
        a.begin(500, 900);
        q = a.apply(508, 890);
        check(q[0] == 508 && q[1] == 890, "assist: tiny movement is untouched");

        // dragging a different way (right): untouched, the user stays in control
        a.begin(500, 900);
        q = a.apply(800, 880);
        check(q[0] == 800 && q[1] == 880, "assist: sideways drag is untouched");
        // dragging the opposite way (down): untouched
        a.begin(500, 900);
        q = a.apply(500, 1200);
        check(q[0] == 500 && q[1] == 1200, "assist: opposite drag is untouched");

        // smoothing follows, and lags behind the finger instead of jumping
        a.setStrength(1f);
        a.begin(500, 900);
        float[] last = null;
        for (int i = 1; i <= 20; i++) last = a.apply(500 + (i % 2 == 0 ? 30 : -30), 900 - i * 30);
        check(near(last[0], 500, 12f), "assist: jittery path is pulled toward the straight saved direction");

        // no reference: untouched
        LiveAssist none = new LiveAssist(20f);
        none.setStrength(1f);
        none.begin(0, 0);
        q = none.apply(40, 400);
        check(q[0] == 40 && q[1] == 400, "assist: without a saved gesture nothing is changed");
    }

    static void testRelayNoSendWithoutFinger() {
        FakeSink sink = new FakeSink();
        Clock clk = new Clock();
        FakeHost host = new FakeHost();
        LiveSession s = new LiveSession(host, sink, clk, 20f);
        for (int i = 0; i < 500; i++) {
            clk.t += 16;
            sink.completeOne();
        }
        check(sink.calls.isEmpty(), "relay: time passing with no finger sends nothing");
        s.onMove(10, 10, 1);
        s.onUp(10, 10, 2);
        s.onCancel(3);
        check(sink.calls.isEmpty(), "relay: move/up/cancel without a down send nothing");
        check(!s.isDown() && !s.isRelaying(), "relay: idle stays idle");
    }

    static void testRelayFlow() {
        FakeSink sink = new FakeSink();
        Clock clk = new Clock();
        FakeHost host = new FakeHost();
        LiveSession s = new LiveSession(host, sink, clk, 20f);
        s.assist.setStrength(0f);

        s.onDown(1700, 800, 0);
        check(sink.calls.size() == 1 && sink.calls.get(0).first && sink.calls.get(0).willContinue, "flow: first piece goes out on touch down");
        check(sink.calls.get(0).x0 == 1700 && sink.calls.get(0).y0 == 800, "flow: first piece is at the finger");
        check(!host.touchable, "flow: trigger lets the injected touch through while relaying");

        // finger moves while the first piece is in flight: nothing more is sent yet, targets are merged
        clk.t = 20; s.onMove(1700, 780, 20);
        clk.t = 40; s.onMove(1700, 740, 40);
        check(sink.calls.size() == 1, "flow: moves are held back while a piece is in flight");
        sink.completeOne();
        check(sink.calls.size() == 2, "flow: next piece goes out when the previous one completes");
        Call c = sink.calls.get(1);
        check(!c.first && c.willContinue && c.x0 == 1700 && c.y0 == 800 && c.x1 == 1700 && c.y1 == 740,
                "flow: pieces chain from the previous end point to the newest finger position");
        check(c.dur >= StrokeRelay.MIN_MS && c.dur <= StrokeRelay.MAX_MS, "flow: piece duration is clamped");

        // finger stays still: nothing is sent while holding
        sink.completeOne();
        int n = sink.calls.size();
        for (int i = 0; i < 200; i++) { clk.t += 16; sink.completeOne(); }
        check(sink.calls.size() == n, "flow: holding still sends nothing");

        // lift
        clk.t += 30;
        s.onUp(1700, 700, clk.t);
        check(sink.calls.size() == n + 1, "flow: lift sends the final piece");
        Call last = sink.calls.get(sink.calls.size() - 1);
        check(!last.willContinue && last.y1 == 700, "flow: final piece lifts the injected finger at the final position");
        check(host.n("relay_ok") == 0, "flow: not finished until the last piece completes");
        sink.completeOne();
        check(host.n("relay_ok") == 1 && host.touchable && !s.isRelaying(), "flow: trigger is touchable again after the lift");
        check(host.ended == 1, "flow: red circles are told to end once");
        int after = sink.calls.size();
        for (int i = 0; i < 200; i++) { clk.t += 16; sink.completeOne(); }
        check(sink.calls.size() == after, "flow: nothing is sent after the finger lifted");
    }

    static void testUpWhileInFlight() {
        FakeSink sink = new FakeSink();
        Clock clk = new Clock();
        FakeHost host = new FakeHost();
        LiveSession s = new LiveSession(host, sink, clk, 20f);
        s.assist.setStrength(0f);
        s.onDown(100, 100, 0);
        clk.t = 10;
        s.onUp(100, 100, 10); // lifts before the first piece completed (a quick tap)
        check(sink.calls.size() == 1, "tap: lift while the first piece is in flight waits");
        sink.completeOne();
        check(sink.calls.size() == 2 && !sink.calls.get(1).willContinue, "tap: then the finger is lifted");
        sink.completeOne();
        check(!s.isRelaying() && host.n("relay_ok") == 1, "tap: finished cleanly");
    }

    static void testStaleCallbacks() {
        FakeSink sink = new FakeSink();
        Clock clk = new Clock();
        FakeHost host = new FakeHost();
        LiveSession s = new LiveSession(host, sink, clk, 20f);
        s.assist.setStrength(0f);
        s.onDown(100, 100, 0);
        StrokeRelay.Done old = sink.pending.peek();
        sink.cancelOne();                 // Android cancels the first piece
        s.onUp(100, 100, 5);
        s.onDown(300, 300, 50);           // a new touch starts
        check(sink.calls.size() == 2, "stale: new touch sends its own first piece");
        old.completed();                  // a late answer for the OLD piece must be ignored
        s.onMove(300, 250, 60);
        check(sink.calls.size() == 2, "stale: late answer of an old piece does not release the new touch");
        sink.completeOne();
        check(sink.calls.size() == 3, "stale: the new piece's own answer does");
    }

    static void testTriggerGateAndPause() {
        FakeSink sink = new FakeSink();
        Clock clk = new Clock();
        FakeHost host = new FakeHost();
        LiveSession s = new LiveSession(host, sink, clk, 20f);

        // two touches in a row that Android cancels right away: live assist pauses itself
        s.onDown(10, 10, 0);
        sink.cancelOne();
        check(host.n("relay_lost") == 1 && host.paused == null, "pause: first early loss only counts");
        s.onUp(10, 10, 5);
        s.onDown(10, 10, 100);
        sink.cancelOne();
        check(host.paused != null, "pause: second early loss pauses live assist");
        check(host.touchable, "pause: trigger is touchable-state restored (service then makes it pass-through)");

        // a good touch resets the counter
        FakeSink sink2 = new FakeSink();
        sink2.autoComplete = true;
        FakeHost host2 = new FakeHost();
        LiveSession s2 = new LiveSession(host2, sink2, clk, 20f);
        s2.onDown(10, 10, 0);
        s2.onUp(10, 10, 5);
        check(host2.n("relay_ok") == 1 && host2.paused == null, "pause: successful touch does not pause");

        // the real finger cancelled by the system counts as an early loss
        FakeSink sink3 = new FakeSink();
        FakeHost host3 = new FakeHost();
        LiveSession s3 = new LiveSession(host3, sink3, clk, 20f);
        s3.onDown(10, 10, 0);
        s3.onCancel(1);
        check(host3.n("real_cancel") == 1 && host3.touchable && !s3.isDown(), "cancel: real cancel is counted and the trigger restored");
        sink3.completeOne();
        check(sink3.calls.size() == 2 && !sink3.calls.get(1).willContinue, "cancel: the injected finger is lifted, never left pressed");
        s3.onDown(10, 10, 50);
        s3.onCancel(51);
        check(host3.paused != null, "cancel: two real cancels in a row pause live assist");

        // the realistic order: Android cancels the real finger, the injected finger is then lifted and that
        // lift completes fine. A completed lift must not erase the "cancelled" count.
        FakeSink sink5 = new FakeSink();
        FakeHost host5 = new FakeHost();
        LiveSession s5 = new LiveSession(host5, sink5, clk, 20f);
        for (int round = 0; round < 2; round++) {
            check(host5.paused == null, "cancel+lift: not paused before round " + round);
            s5.onDown(10, 10, round * 100);
            sink5.completeOne();            // touch-down piece done
            s5.onCancel(round * 100 + 5);   // Android takes the real finger away
            sink5.completeOne();            // the injected finger is lifted fine
        }
        check(host5.paused != null, "cancel+lift: two cancelled touches in a row pause live assist even though each lift completed");
        FakeSink sink6 = new FakeSink();
        FakeHost host6 = new FakeHost();
        LiveSession s6 = new LiveSession(host6, sink6, clk, 20f);
        s6.onDown(10, 10, 0);
        sink6.completeOne();
        s6.onCancel(5);
        sink6.completeOne();
        s6.onDown(10, 10, 100);
        sink6.completeOne();
        s6.onUp(10, 10, 110);
        sink6.completeOne();
        s6.onDown(10, 10, 200);
        sink6.completeOne();
        s6.onCancel(205);
        sink6.completeOne();
        check(host6.paused == null, "cancel+lift: a good touch in between resets the count");

        // sink refuses: trigger is never left untouchable
        FakeSink sink4 = new FakeSink();
        sink4.refuse = true;
        FakeHost host4 = new FakeHost();
        LiveSession s4 = new LiveSession(host4, sink4, clk, 20f);
        s4.onDown(10, 10, 0);
        check(host4.touchable && host4.n("send_failed") == 1, "refuse: trigger stays touchable when Android refuses");
    }

    static void testCirclesFollowFinger() {
        FakeSink sink = new FakeSink();
        sink.autoComplete = true;
        Clock clk = new Clock();
        FakeHost host = new FakeHost();
        LiveSession s = new LiveSession(host, sink, clk, 20f);
        s.assist.setReferenceFromPoints(upLine());
        s.assist.setStrength(1f);
        s.onDown(500, 900, 0);
        check(host.circles.size() == 1 && host.circles.get(0).length == 2, "circles: one circle at touch down");
        for (int i = 1; i <= 10; i++) {
            clk.t = i * 16;
            s.onMove(500 + 40, 900 - i * 40, clk.t);
        }
        float[] lastC = host.circles.get(host.circles.size() - 1);
        check(lastC.length == 4, "circles: finger and assisted point are both shown when they differ");
        check(lastC[0] == 540 && lastC[1] == 500, "circles: first circle is exactly the real finger");
        check(lastC[2] < 540 && lastC[2] >= 500, "circles: second circle is the assisted point, closer to the saved direction");
        check(s.stats.distance() > 0 && near(s.stats.angleDeg(), 90, 6), "circles: finger movement is tracked while drawing");
        Call sent = sink.calls.get(sink.calls.size() - 1);
        check(sent.x1 < 540 && sent.x1 >= 500 && near(sent.x1, lastC[2], 0.01f),
                "assist reaches the game: the piece that is sent is the assisted point, not the raw finger");
    }

    static void testPlacement() {
        int size = 160;
        int[] px = TriggerPlacement.toPx(0.86f, 0.62f, 2400, 1080, size);
        float[] f = TriggerPlacement.toFrac(px[0], px[1], 2400, 1080, size);
        check(near(f[0], 0.86f, 0.001f) && near(f[1], 0.62f, 0.001f), "placement: pixel/fraction round trip");
        int[] a = TriggerPlacement.toPx(0.5f, 0.5f, 2400, 1080, size);
        int[] b = TriggerPlacement.toPx(0.5f, 0.5f, 2400, 1080, size);
        check(a[0] == b[0] && a[1] == b[1], "placement: same input gives same place (nothing else moves it)");
        int[] clamp = TriggerPlacement.toPx(5f, -3f, 2400, 1080, size);
        check(clamp[0] == 2400 - size && clamp[1] == 0, "placement: always stays on screen");
        check(!TriggerPlacement.keyFx(true).equals(TriggerPlacement.keyFx(false)), "placement: portrait and landscape are stored separately");
    }

    static void testFuzz() {
        Random rnd = new Random(12345);
        for (int round = 0; round < 40; round++) {
            FakeSink sink = new FakeSink();
            sink.autoComplete = rnd.nextInt(4) == 0;
            Clock clk = new Clock();
            FakeHost host = new FakeHost();
            LiveSession s = new LiveSession(host, sink, clk, 20f);
            s.assist.setReferenceFromPoints(upLine());
            s.assist.setStrength(rnd.nextFloat());
            for (int step = 0; step < 4000; step++) {
                clk.t += rnd.nextInt(30);
                boolean idle = !s.isDown() && !s.isRelaying();
                int before = sink.calls.size();
                int op = rnd.nextInt(9);
                float x = rnd.nextInt(2400), y = rnd.nextInt(1080);
                boolean isDown = false;
                switch (op) {
                    case 0: s.onDown(x, y, clk.t); isDown = true; break;
                    case 1: case 2: case 3: s.onMove(x, y, clk.t); break;
                    case 4: s.onUp(x, y, clk.t); break;
                    case 5: s.onCancel(clk.t); break;
                    case 6: sink.completeOne(); break;
                    case 7: if (rnd.nextInt(6) == 0) sink.cancelOne(); else sink.completeOne(); break;
                    default: if (rnd.nextInt(50) == 0) s.reset(); break;
                }
                if (idle && !isDown) {
                    check(sink.calls.size() == before, "fuzz: nothing is sent while idle (round " + round + " step " + step + ")");
                }
                for (Call c : sink.calls) {
                    if (c.x1 < 0 || c.y1 < 0) throw new AssertionError("fuzz: negative coordinate");
                }
            }
            s.reset();
            while (!sink.pending.isEmpty()) sink.completeOne();
            check(!s.isRelaying(), "fuzz: everything ends cleanly (round " + round + ")");
            check(host.touchable, "fuzz: trigger is touchable again once everything ended (round " + round + ")");
        }
    }

    public static void main(String[] args) {
        testStats();
        testAssist();
        testRelayNoSendWithoutFinger();
        testRelayFlow();
        testUpWhileInFlight();
        testStaleCallbacks();
        testTriggerGateAndPause();
        testCirclesFollowFinger();
        testPlacement();
        testFuzz();
        System.out.println("ALL PASSED (" + passed + " checks)");
    }
}
